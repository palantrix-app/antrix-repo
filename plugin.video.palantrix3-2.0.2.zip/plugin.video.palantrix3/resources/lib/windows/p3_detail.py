# -*- coding: utf-8 -*-
"""
	PalAntriX 2.0.0 — FICHA (p3_detail), piel negro/azul.

	REPASO §3: fanart de fondo, título GRANDE, línea de datos
	(año · tipo · géneros · nota), sinopsis, portada a la derecha.
	Botones SOLO: Reproducir, Temporadas (solo series), Mi lista, Más.
	Sin Relacionados. Barra inferior: últimos capítulos (series) o
	actores (películas) SOLO si el dato sale sin coste extra; si no,
	la barra no se pinta.

	Reproducir película — PREVALENCIA de la Colección: si el tmdb está
	en el catálogo con enlaces, play_vault(); si devuelve False, se cae
	a la búsqueda en vivo (RunPlugin play_Item bingie=1).
	Reproducir serie — abre Temporadas (bingie_launcher.open_seasons_window);
	el «siguiente episodio directo» vive en esa ventana, no aquí.

	«Más» es un desplegable PROPIO dentro de esta ventana (panel en el
	XML, ids 41xx), no el menú de Kodi: Enlaces (acción p3_enlaces, la
	ventana la construye otro frente), Marcar como visto / no visto
	(playcount/trakt del motor) y Ver tráiler (play_Trailer del motor).

	«Mi lista»: toggle sobre la watchlist de Trakt con las mismas
	llamadas que usa modules/trakt.py manager() (getTrakt a
	/sync/watchlist y /sync/watchlist/remove + sync_watch_list), y el
	estado se lee de traktsync.fetch_watch_list en cada apertura.

	Adaptador: acepta dicts del motor (filas en vivo) y filas del
	catálogo de la Colección (titulo/poster/fondo/fecha/rating/genero/
	sinopsis) vía normalize_item().
"""

from urllib.parse import quote_plus
from json import dumps as jsdumps

from resources.lib.modules import control
from resources.lib.windows.base import BaseDialog

ADDON = 'plugin://plugin.video.palantrix3/'

BTN_PLAY = 4001
BTN_SEASONS = 4002
BTN_WATCHLIST = 4003
BTN_MAS = 4004
MAS_ENLACES = 4101
MAS_VISTO = 4102
MAS_NOVISTO = 4103
MAS_TRAILER = 4104
BOTTOM_LIST = 6100


def normalize_item(raw, kind_hint=None):
	"""Motor dict o fila de catálogo -> dict común de la ficha."""
	raw = raw or {}
	if 'titulo' in raw or 'sinopsis' in raw:
		kind = raw.get('kind') or kind_hint or 'pelicula'
		fecha = str(raw.get('fecha') or '')
		return {
			'title': raw.get('titulo') or '', 'tvshowtitle': raw.get('titulo') or '',
			'year': fecha[:4], 'premiered': fecha,
			'genre': raw.get('genero') or '', 'plot': raw.get('sinopsis') or '',
			'poster': raw.get('poster') or '', 'fanart': raw.get('fondo') or '',
			'rating': raw.get('rating') or '', 'imdb': raw.get('imdb') or '',
			'tmdb': raw.get('tmdb') or '', 'tvdb': raw.get('tvdb') or '',
			'_p3_media': 'tvshow' if kind == 'serie' else 'movie',
			'_p3_kind': kind, '_from_coleccion': True,
		}
	item = dict(raw)
	media = item.get('_p3_media') or item.get('mediatype') or ''
	if media not in ('movie', 'tvshow'):
		media = 'tvshow' if (item.get('tvshowtitle') and not item.get('title')) or kind_hint == 'serie' else 'movie'
	item['_p3_media'] = media
	item['_p3_kind'] = 'serie' if media == 'tvshow' else 'pelicula'
	if media == 'tvshow' and not item.get('title'):
		item['title'] = item.get('tvshowtitle') or ''
	return item


def _meta_line(item):
	parts = []
	if item.get('year'):
		parts.append(str(item['year']))
	parts.append('Serie' if item['_p3_media'] == 'tvshow' else 'Película')
	genre = item.get('genre')
	if genre and str(genre) != 'NA':
		if isinstance(genre, (list, tuple)):
			genre = ' / '.join(genre)
		try:
			from resources.lib.modules import cleangenre
			genre = cleangenre.lang(genre, control.apiLanguage()['trakt'])
		except Exception:
			pass
		parts.append(str(genre))
	try:
		rating = float(item.get('rating') or 0)
		if rating > 0:
			parts.append('★ %.1f' % rating)
	except Exception:
		pass
	return '   •   '.join(parts)


def _in_watchlist(item):
	try:
		from resources.lib.database import traktsync
		table = 'shows_watchlist' if item['_p3_media'] == 'tvshow' else 'movies_watchlist'
		for row in traktsync.fetch_watch_list(table) or []:
			if item.get('imdb') and row.get('imdb') == item['imdb']:
				return True
			if item.get('tmdb') and str(row.get('tmdb')) == str(item['tmdb']):
				return True
	except Exception:
		pass
	return False


class P3DetailXML(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, args)
		self.item = normalize_item(kwargs.get('item') or {}, kwargs.get('kind_hint'))
		self._inited = False
		self._bottom = []   # episodios o actores de la barra inferior
		self._wl = False

	def onInit(self):
		if self._inited:
			return
		self._inited = True
		i = self.item
		self.setProperty('p3.title', i.get('title') or '')
		self.setProperty('p3.meta_line', _meta_line(i))
		self.setProperty('p3.plot', i.get('plot') or '')
		self.setProperty('p3.poster', i.get('poster') or control.addonPoster())
		fanart = i.get('fanart') or i.get('fanart2') or i.get('fanart3') or control.addonFanart()
		self.setProperty('p3.fanart', fanart)
		self.setProperty('p3.is_series', '1' if i['_p3_media'] == 'tvshow' else '')
		self._wl = _in_watchlist(i)
		self._refresh_watchlist_label()
		self._load_bottom()
		try:
			self.setFocusId(BTN_PLAY)
		except Exception:
			pass

	def _refresh_watchlist_label(self):
		self.setProperty('p3.watchlist_label', '✓ En mi lista' if self._wl else '+ Mi lista')

	# — barra inferior sin coste extra —
	def _load_bottom(self):
		"""Series: últimos capítulos de la última temporada (menus del
		motor, create_directory=False). Películas: reparto SOLO si el
		dict ya trae 'cast'. Si no hay dato, la barra no se pinta."""
		i = self.item
		try:
			if i['_p3_media'] == 'tvshow':
				from resources.lib.menus import seasons as seasons_menu
				from resources.lib.menus import episodes as episodes_menu
				art = jsdumps({'poster': i.get('poster', ''), 'fanart': i.get('fanart', ''),
							   'icon': i.get('poster', ''), 'thumb': i.get('poster', '')})
				seasons = seasons_menu.Seasons().get(
					i.get('tvshowtitle') or i.get('title', ''), i.get('year', ''),
					i.get('imdb', ''), i.get('tmdb', ''), i.get('tvdb', ''),
					art, create_directory=False) or []
				seasons = [s for s in seasons if str(s.get('season')) not in ('0',)]
				if not seasons:
					return
				last = seasons[-1]
				eps = episodes_menu.Episodes().get(
					i.get('tvshowtitle') or i.get('title', ''), i.get('year', ''),
					i.get('imdb', ''), i.get('tmdb', ''), i.get('tvdb', ''),
					jsdumps(last), season=last.get('season'), create_directory=False) or []
				for e in reversed(eps[-10:]):
					self._bottom.append(('episode', e))
				if self._bottom:
					self.setProperty('p3.bottom_title', 'Últimos capítulos')
			else:
				cast = i.get('cast') or i.get('castandrole') or []
				for c in cast[:12]:
					if isinstance(c, dict) and c.get('name'):
						self._bottom.append(('cast', c))
				if self._bottom:
					self.setProperty('p3.bottom_title', 'Reparto')
			if not self._bottom:
				return
			self.setProperty('p3.has_bottom', '1')
			lis = []
			for kind, data in self._bottom:
				if kind == 'episode':
					try:
						lbl = 'T%d E%d · %s' % (int(data.get('season') or 0),
												int(data.get('episode') or 0),
												data.get('title') or '')
					except Exception:
						lbl = data.get('title') or ''
					thumb = data.get('thumb') or (data.get('art') or {}).get('thumb') or i.get('fanart') or ''
				else:
					lbl = data.get('name') or ''
					thumb = data.get('thumbnail') or data.get('thumb') or ''
				li = control.item(label=lbl, offscreen=True)
				li.setArt({'thumb': thumb, 'poster': thumb, 'fanart': i.get('fanart') or ''})
				lis.append(li)
			ctrl = self.getControl(BOTTOM_LIST)
			ctrl.reset()
			ctrl.addItems(lis)
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()
			self._bottom = []
			self.clearProperty('p3.has_bottom')

	# — acciones —
	def onClick(self, controlId):
		if controlId == BTN_PLAY:
			self._play()
		elif controlId == BTN_SEASONS:
			self._open_seasons()
		elif controlId == BTN_WATCHLIST:
			self._toggle_watchlist()
		elif controlId == BTN_MAS:
			self._toggle_mas(True)
		elif controlId == MAS_ENLACES:
			self._toggle_mas(False)
			self._open_enlaces()
		elif controlId == MAS_VISTO:
			self._toggle_mas(False)
			self._set_watched(True)
		elif controlId == MAS_NOVISTO:
			self._toggle_mas(False)
			self._set_watched(False)
		elif controlId == MAS_TRAILER:
			self._toggle_mas(False)
			self._play_trailer()
		elif controlId == BOTTOM_LIST:
			self._click_bottom()

	def onAction(self, action):
		try:
			if action.getId() in self.closing_actions:
				if self.getProperty('p3.mas_open'):
					self._toggle_mas(False)
					return
				return self.close()
		except Exception:
			pass

	def _toggle_mas(self, open_it):
		if open_it:
			self.setProperty('p3.mas_open', '1')
			try:
				self.setFocusId(MAS_ENLACES)
			except Exception:
				pass
		else:
			self.clearProperty('p3.mas_open')
			try:
				self.setFocusId(BTN_MAS)
			except Exception:
				pass

	def _play(self):
		i = self.item
		if i['_p3_media'] == 'tvshow':
			self._open_seasons()
			return
		# PREVALENCIA: primero la bóveda de la Colección.
		try:
			if i.get('tmdb'):
				from resources.lib.modules import coleccion_runtime
				if coleccion_runtime.in_catalog('pelicula', i['tmdb']) and \
						coleccion_runtime.has_links('pelicula', i['tmdb']):
					if coleccion_runtime.play_vault('pelicula', i['tmdb']):
						return
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()
		self._play_live_movie(i)

	def _play_live_movie(self, i):
		try:
			cmd = ('RunPlugin(%s?action=play_Item&title=%s&year=%s&imdb=%s&tmdb=%s&meta=%s&bingie=1)'
				   % (ADDON, quote_plus(i.get('title', '')), i.get('year', ''),
					  i.get('imdb', ''), i.get('tmdb', ''), quote_plus(jsdumps(i))))
			control.execute(cmd)
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def _open_seasons(self):
		try:
			from resources.lib.modules import bingie_launcher
			bingie_launcher.open_seasons_window(self.item)
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def _open_enlaces(self):
		"""Solo lanza la acción; la ventana de Enlaces es de otro frente."""
		i = self.item
		cmd = ('RunPlugin(%s?action=p3_enlaces&kind=%s&tmdb=%s)'
			   % (ADDON, i['_p3_kind'], i.get('tmdb', '')))
		control.execute(cmd)

	def _set_watched(self, watched):
		i = self.item
		try:
			from resources.lib.modules import playcount
			name = i.get('title', '')
			if i['_p3_media'] == 'tvshow':
				playcount.tvshows(name, i.get('imdb', ''), i.get('tvdb', ''), None, 5 if watched else 4)
			else:
				playcount.movies(name, i.get('imdb', ''), 5 if watched else 4)
			control.notification(title=name, message='Marcado como visto' if watched else 'Marcado como no visto')
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def _play_trailer(self):
		i = self.item
		try:
			typ = 'tv' if i['_p3_media'] == 'tvshow' else 'movie'
			name = '%s (%s)' % (i.get('title', ''), i.get('year', '')) if i.get('year') else i.get('title', '')
			cmd = ('PlayMedia(%s?action=play_Trailer&type=%s&name=%s&year=%s&imdb=%s&tmdb=%s)'
				   % (ADDON, typ, quote_plus(name), i.get('year', ''),
					  i.get('imdb', ''), i.get('tmdb', '')))
			control.execute(cmd)
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def _toggle_watchlist(self):
		i = self.item
		try:
			from resources.lib.modules import trakt as trakt_mod
			if i['_p3_media'] == 'tvshow':
				post_ids = {'tvdb': i.get('tvdb', '')} if i.get('tvdb') else {'tmdb': i.get('tmdb', '')}
				post = {'shows': [{'ids': post_ids}]}
				typ = 'shows'
			else:
				post_ids = {'imdb': i.get('imdb', '')} if i.get('imdb') else {'tmdb': i.get('tmdb', '')}
				post = {'movies': [{'ids': post_ids}]}
				typ = 'movies'
			if self._wl:
				trakt_mod.getTrakt('/sync/watchlist/remove', post=post)
			else:
				trakt_mod.getTrakt('/sync/watchlist', post=post)
			try:
				trakt_mod.sync_watch_list(forced=True)
			except Exception:
				pass
			self._wl = not self._wl
			self._refresh_watchlist_label()
			control.notification(title=i.get('title', ''),
								 message='Quitado de Mi lista' if not self._wl else 'Añadido a Mi lista')
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def _click_bottom(self):
		try:
			pos = self.get_position(BOTTOM_LIST)
			if not (0 <= pos < len(self._bottom)):
				return
			kind, data = self._bottom[pos]
			if kind != 'episode':
				return
			i = self.item
			season, episode = data.get('season'), data.get('episode')
			# Prevalencia también por capítulo.
			try:
				if i.get('tmdb'):
					from resources.lib.modules import coleccion_runtime
					if coleccion_runtime.has_links('serie', i['tmdb'], season, episode):
						if coleccion_runtime.play_vault('serie', i['tmdb'], season, episode):
							return
			except Exception:
				pass
			cmd = ('RunPlugin(%s?action=play_Item&title=%s&year=%s&imdb=%s&tmdb=%s&tvdb=%s'
				   '&season=%s&episode=%s&tvshowtitle=%s&premiered=%s&meta=%s&bingie=1)'
				   % (ADDON, quote_plus(data.get('title', '')), i.get('year', ''),
					  i.get('imdb', ''), i.get('tmdb', ''), i.get('tvdb', ''),
					  season, episode, quote_plus(i.get('tvshowtitle') or i.get('title', '')),
					  quote_plus(str(data.get('premiered', '') or '')),
					  quote_plus(jsdumps(data))))
			control.execute(cmd)
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def run(self):
		self.doModal()
		self.clearProperties()
		return None


def show_detail(item, kind_hint=None):
	window = P3DetailXML('p3_detail.xml', control.addonPath(control.addonId()),
						 item=item, kind_hint=kind_hint)
	window.run()
	del window
