# -*- coding: utf-8 -*-
"""
	PalAntriX 2.0.0 — Buscador propio (piel negro/azul).

	Entrada de texto con el TECLADO COMPLETO de Kodi
	(xbmcgui.Dialog().input con INPUT_ALPHANUM: minúsculas y todas
	las opciones; requisito expreso de Àngel, sin recortes).

	Resultados en la misma ventana, con PREVALENCIA de la Colección:
	primero los del catálogo/bóveda (coleccion_runtime.search_catalog,
	marcados «Colección») y después los en vivo de TMDB (la vía real
	del motor: indexers/tmdb.py, clase TMDb y su get_request).

	Clic en resultado de la Colección -> play_vault (película) o
	Temporadas/Episodios de la Colección (serie).
	Clic en resultado en vivo -> RunPlugin play_Item (película) o
	bingie_launcher.open_seasons_window (serie).

	Sin búsqueda por voz: aparcada por decisión de Àngel (P5); no se
	implementa ni se pinta el botón.
"""

from json import dumps as jsdumps
from urllib.parse import quote_plus

import xbmc
import xbmcgui

from resources.lib.modules import control
from resources.lib.modules import coleccion_runtime
from resources.lib.modules import log_utils
from resources.lib.windows.base import BaseDialog
from resources.lib.windows import coleccion_ui

ADDON_ID = 'plugin.video.palantrix3'

BTN_BUSCAR = 400
LBL_QUERY = 402
LIST_RESULTADOS = 401
LBL_ESTADO = 403


def search_live_tmdb(query, limit=20):
	"""Búsqueda en vivo contra TMDB con el indexer del motor
	(indexers/tmdb.py: TMDb.get_request, su clave y su idioma).
	Devuelve dicts con la forma que consumen play_Item y
	bingie_launcher.open_seasons_window."""
	out = []
	try:
		from resources.lib.indexers.tmdb import TMDb
		t = TMDb()
		lang = getattr(t, 'lang', '') or 'es-ES'
		url = ('https://api.themoviedb.org/3/search/multi?api_key=%s'
			   '&language=%s&query=%s&page=1&include_adult=false'
			   % (t.API_key, lang, quote_plus(query)))
		res = t.get_request(url)
		if not res or not isinstance(res, dict):
			return out
		for item in res.get('results') or []:
			mt = item.get('media_type')
			if mt not in ('movie', 'tv'):
				continue
			tmdb_id = item.get('id')
			if not tmdb_id:
				continue
			title = item.get('title') or item.get('name') or ''
			if not title:
				continue
			fecha = item.get('release_date') or item.get('first_air_date') or ''
			poster = item.get('poster_path') or ''
			fanart = item.get('backdrop_path') or ''
			d = {
				'title': title,
				'tvshowtitle': title if mt == 'tv' else '',
				'year': (fecha or '')[:4],
				'imdb': '',
				'tmdb': str(tmdb_id),
				'tvdb': '',
				'poster': ('https://image.tmdb.org/t/p/w500' + poster) if poster else '',
				'poster2': ('https://image.tmdb.org/t/p/w500' + poster) if poster else '',
				'poster3': ('https://image.tmdb.org/t/p/w500' + poster) if poster else '',
				'fanart': ('https://image.tmdb.org/t/p/w1280' + fanart) if fanart else '',
				'fanart2': ('https://image.tmdb.org/t/p/w1280' + fanart) if fanart else '',
				'fanart3': ('https://image.tmdb.org/t/p/w1280' + fanart) if fanart else '',
				'plot': item.get('overview') or '',
				'premiered': fecha,
				'mediatype': 'movie' if mt == 'movie' else 'tvshow',
				'_kind': 'pelicula' if mt == 'movie' else 'serie',
				'_vivo': True,
			}
			out.append(d)
			if len(out) >= limit:
				break
	except Exception:
		log_utils.error()
	return out


def _ask_query(actual=''):
	"""Teclado COMPLETO de Kodi (INPUT_ALPHANUM, sin recortes)."""
	dlg = xbmcgui.Dialog()
	return dlg.input('Buscar en PalAntriX', defaultt=actual or '',
					 type=xbmcgui.INPUT_ALPHANUM)


class SearchWindow(BaseDialog):
	"""Buscador: pide el texto (o lo recibe por kwargs['query']) y
	muestra Colección primero y TMDB en vivo después."""

	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, args)
		self.query = kwargs.get('query') or ''
		self.results = []      # dicts con '_origen': 'coleccion'|'vivo'
		self._inited = False
		self._searched = False

	def onInit(self):
		coleccion_ui.sidebar_init(self, 'search')
		try:
			self.getControl(coleccion_ui.LBL_STATUS).setLabel(coleccion_ui.status_text())
		except Exception:
			pass
		if self._inited:
			return
		self._inited = True
		if not self.query:
			q = _ask_query()
			if q:
				self.query = q.strip()
		if self.query:
			self._do_search()
		else:
			try:
				self.getControl(LBL_ESTADO).setLabel(
					'Pulsa «Nueva búsqueda» y escribe un título.')
			except Exception:
				pass
			self.setFocusId(BTN_BUSCAR)

	def _do_search(self):
		self._searched = True
		try:
			self.getControl(LBL_QUERY).setLabel('«%s»' % self.query)
			self.getControl(LBL_ESTADO).setLabel('Cargando…')
		except Exception:
			pass
		self.results = []
		# 1) Colección primero (prevalencia = ORDEN, no exclusión)
		try:
			coleccion_runtime.ensure_data()
			for row in coleccion_runtime.search_catalog(self.query):
				row = dict(row)
				row['_origen'] = 'coleccion'
				self.results.append(row)
		except Exception:
			log_utils.error()
		# 2) En vivo (TMDB) detrás, TAMBIÉN los que están en la
		# Colección: son el respaldo de luc alcanzable desde aquí si
		# la bóveda no tiene enlaces de ese título o fallan (P3).
		for item in search_live_tmdb(self.query):
			item['_origen'] = 'vivo'
			self.results.append(item)
		lst = self.getControl(LIST_RESULTADOS)
		lst.reset()
		items = []
		for r in self.results:
			if r.get('_origen') == 'coleccion':
				kind = r.get('kind') or 'pelicula'
				li = xbmcgui.ListItem(label=r.get('titulo') or '')
				poster = coleccion_ui._img(r.get('poster'))
				li.setArt({'poster': poster, 'thumb': poster,
						   'fanart': coleccion_ui._img(r.get('fondo'), 'w1280')})
				partes = ['Colección',
						  'Película' if kind == 'pelicula' else 'Serie']
				if r.get('fecha'):
					partes.append(str(r.get('fecha'))[:4])
				li.setLabel2(' · '.join(partes))
			else:
				li = xbmcgui.ListItem(label=r.get('title') or '')
				li.setArt({'poster': r.get('poster') or '',
						   'thumb': r.get('poster') or '',
						   'fanart': r.get('fanart') or ''})
				partes = ['En vivo',
						  'Película' if r.get('_kind') == 'pelicula' else 'Serie']
				if r.get('year'):
					partes.append(str(r.get('year')))
				li.setLabel2(' · '.join(partes))
			items.append(li)
		lst.addItems(items)
		try:
			self.getControl(LBL_ESTADO).setLabel(
				'%d resultados · primero la Colección' % len(self.results)
				if self.results else
				'Sin resultados para «%s».' % self.query)
		except Exception:
			pass
		self.setFocusId(LIST_RESULTADOS if self.results else BTN_BUSCAR)

	def onClick(self, control_id):
		if coleccion_ui.sidebar_click(self, control_id, 'search'):
			return
		if control_id == BTN_BUSCAR:
			q = _ask_query(self.query)
			if q and q.strip() != self.query:
				self.query = q.strip()
				self._do_search()
			return
		if control_id != LIST_RESULTADOS:
			return
		pos = self.getControl(LIST_RESULTADOS).getSelectedPosition()
		if not (0 <= pos < len(self.results)):
			return
		r = self.results[pos]
		if r.get('_origen') == 'coleccion':
			coleccion_ui.open_title(r)
			return
		# En vivo: película -> play_Item; serie -> temporadas de luc
		if r.get('_kind') == 'pelicula':
			cmd = ('RunPlugin(plugin://%s/?action=play_Item&title=%s&year=%s'
				   '&imdb=%s&tmdb=%s&meta=%s&bingie=1)' % (
					   ADDON_ID, quote_plus(r.get('title') or ''),
					   r.get('year') or '', r.get('imdb') or '',
					   r.get('tmdb') or '', quote_plus(jsdumps(r))))
			control.execute(cmd)
		else:
			from resources.lib.modules import bingie_launcher
			bingie_launcher.open_seasons_window(r)


def show_search(query=''):
	w = SearchWindow('p3_search.xml', coleccion_ui._addon_path(),
					 'Default', '1080i', query=query)
	w.doModal()
	del w
