# -*- coding: utf-8 -*-
"""
	PalAntriX Add-on — Menú visual de sección (1.2.0)

	Todos los menús del addon en el mismo estilo visual de la
	portada: fondo con fanart, menú en texto que se ilumina al pasar
	por encima y, a la derecha, una rejilla de 10 miniaturas del
	apartado enfocado (TMDB). La rejilla es navegable: con → desde
	el menú se entra en ella, con ← desde la primera columna se
	vuelve al menú, y al clicar una miniatura se actúa sobre ese
	título (película: reproducir; serie: abrir sus temporadas).

	Secciones: Películas, Series, Trakt (películas y series),
	Buscar, Herramientas y Servicios Premium. Los apartados sin
	contenido TMDB (Géneros, Años, los de Trakt/Herramientas/…)
	abren su listado o pantalla clásica al clicar, pero el menú en
	sí ya es visual. «Atrás» vuelve a la portada.
"""

import json
from threading import Thread
from urllib.parse import quote_plus
from urllib.request import Request, urlopen

from resources.lib.modules import control
from resources.lib.modules import log_utils
from resources.lib.windows.base import BaseDialog

homeWindow = control.homeWindow

BTN_BASE = 2001  # botones del menú: 2001..2008
GRID_IMG = 4010  # imágenes de la rejilla: 4010..4019 (5 columnas x 2 filas)
GRID_BTN = 4030  # botones de la rejilla: 4030..4039
GRID_COLS = 5
MAX_POSTERS = 10

BASE_URL = 'plugin://plugin.video.palantrix3/?action=%s'
TMDB_API = 'https://api.themoviedb.org/3%s?api_key=%s&language=es-ES'
TMDB_POSTER = 'https://image.tmdb.org/t/p/w342%s'
TMDB_BACKDROP = 'https://image.tmdb.org/t/p/w1280%s'
TMDB_KEY_FALLBACK = 'f2e500501d9fa3bd1637bfd00f11583a'

ACTION_MOVE_LEFT = 1
ACTION_MOVE_RIGHT = 2

# (etiqueta, acción clásica al clicar, endpoint TMDB del contenido)
SECTIONS = {
	'movies': ('Películas', 'movie', [
		('Tendencias', 'movies&url=trakttrending', '/trending/movie/week'),
		('Populares', 'movies&url=traktpopular', '/movie/popular'),
		('En cartelera', 'tmdbmovies&url=tmdb_nowplaying', '/movie/now_playing'),
		('Mejor valoradas', 'tmdbmovies&url=tmdb_toprated', '/movie/top_rated'),
		('Próximamente', 'tmdbmovies&url=tmdb_upcoming', '/movie/upcoming'),
		('Géneros', 'movieGenres&url=tmdb_genre', None),
		('Años', 'movieYears&url=tmdb_year', None),
		('Buscar', 'movieSearch', None),
	]),
	'tv': ('Series', 'tv', [
		('Tendencias', 'tvshows&url=trakttrending', '/trending/tv/week'),
		('Populares', 'tvshows&url=traktpopular', '/tv/popular'),
		('Mejor valoradas', 'tmdbTvshows&url=tmdb_toprated', '/tv/top_rated'),
		('En emisión', 'tmdbTvshows&url=tmdb_ontheair', '/tv/on_the_air'),
		('Se emiten hoy', 'tmdbTvshows&url=tmdb_airingtoday', '/tv/airing_today'),
		('Géneros', 'tvGenres&url=tmdb_genre', None),
		('Años', 'tvYears&url=tmdb_year', None),
		('Buscar', 'tvSearch', None),
	]),
	'traktmovies': ('Trakt · Películas', None, [
		('Terminar de ver', 'moviesUnfinished&url=traktunfinished', None),
		('Historial', 'movies&url=trakthistory', None),
		('Lista de seguimiento', 'movies&url=traktwatchlist', None),
		('Colección', 'movies&url=traktcollection', None),
		('Listas de películas', 'movieUserlists', None),
		('Listas que me gustan', 'movies_LikedLists', None),
	]),
	'trakttv': ('Trakt · Series', None, [
		('Progreso', 'calendar&url=progress', None),
		('Terminar de ver', 'episodesUnfinished&url=traktunfinished', None),
		('Próximos episodios', 'calendar&url=mycalendarUpcoming', None),
		('Episodios recientes', 'calendar&url=mycalendarRecent', None),
		('Estrenos de temporada', 'calendar&url=mycalendarPremiers', None),
		('Lista de seguimiento', 'tvshows&url=traktwatchlist', None),
		('Colección', 'tvshows&url=traktcollection', None),
		('Listas de series', 'tvUserlists', None),
	]),
	'search': ('Buscar', None, [
		('Búsqueda IA', 'aiSearch', None),
		('Búsqueda IA · Películas', 'aiSearchMovies', None),
		('Búsqueda IA · Series', 'aiSearchTvshows', None),
		('Buscar películas...', 'movieSearch', None),
		('Buscar series...', 'tvSearch', None),
	]),
	'tools': ('Herramientas', None, [
		('Gestión de Trakt', 'tools_traktToolsNavigator', None),
		('Funciones de caché', 'cache_Navigator', None),
		('Actualizar catálogo', 'tools_updateCatalog', None),
		('Herramientas de registro', 'tools_loggingNavigator', None),
		('Limpiar ajustes', 'tools_cleanSettings', None),
		('Ajustes', 'tools_openSettings&query=0.0', None),
		('Biblioteca', 'library_Navigator', None),
		('Tipos de vista', 'tools_viewsNavigator', None),
	]),
	'premium': ('Servicios Premium', None, [
		('Debrid Hub', 'tools_debridHub', None),
		('Real-Debrid', 'rd_ServiceNavigator', None),
		('Premiumize', 'pm_ServiceNavigator', None),
		('AllDebrid', 'ad_ServiceNavigator', None),
		('TorBox', 'tb_ServiceNavigator', None),
		('Furk.net', 'furk_ServiceNavigator', None),
	]),
}

_CONTENT_CACHE = {}


def _tmdb_key():
	return control.setting('tmdb.api.key') or TMDB_KEY_FALLBACK


def _tmdb_get(path):
	req = Request('https://api.themoviedb.org/3%s' % path,
				  headers={'User-Agent': 'Kodi PalAntriX', 'Accept': 'application/json'})
	with urlopen(req, timeout=8) as resp:
		return json.loads(resp.read().decode('utf-8'))


def _fetch_content(endpoint, media):
	"""Contenido de un apartado desde TMDB: hasta 10 títulos con
	póster, fondo, año e id de TMDB."""
	data = _tmdb_get('%s?api_key=%s&language=es-ES' % (endpoint, _tmdb_key()))
	items = []
	for row in (data.get('results') or []):
		if not row.get('poster_path'):
			continue
		date = row.get('release_date') or row.get('first_air_date') or ''
		items.append({
			'title': row.get('title') or row.get('name') or '',
			'year': date[:4],
			'poster': TMDB_POSTER % row['poster_path'],
			'backdrop': (TMDB_BACKDROP % row['backdrop_path']) if row.get('backdrop_path') else '',
			'tmdb': row.get('id'),
			'media': media,
		})
		if len(items) >= MAX_POSTERS:
			break
	return items


def _external_ids(media, tmdb_id):
	data = _tmdb_get('/%s/%s/external_ids?api_key=%s' % (media, tmdb_id, _tmdb_key()))
	return data.get('imdb_id') or '', str(data.get('tvdb_id') or '')


class PalantrixSectionXML(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, args)
		self.section = kwargs.get('section', 'tv')
		self.title, self.media, self.items = SECTIONS.get(self.section, SECTIONS['tv'])
		self.navigated = False
		self.closed = False
		self.focus_idx = 0
		self.contents = {}  # idx de apartado -> lista de títulos TMDB

	def onInit(self):
		try:
			self.setProperty('palantrix.section.title', self.title)
			for idx, (label, _action, _ep) in enumerate(self.items):
				self.setProperty('palantrix.section.label%d' % idx, label)
			for idx in range(len(self.items), 8):
				try:
					self.getControl(BTN_BASE + idx).setVisible(False)
				except Exception:
					pass
			self.setProperty('palantrix.section.fanart', control.addonFanart())
			self.setProperty('palantrix.section.itemtitle', '')
			thread = Thread(target=self._load_contents)
			thread.daemon = True
			thread.start()
			self._apply_focus(0)
		except Exception:
			log_utils.error()

	def _load_contents(self):
		for idx, (_label, _action, endpoint) in enumerate(self.items):
			if self.closed or endpoint is None:
				continue
			try:
				if endpoint in _CONTENT_CACHE:
					self.contents[idx] = _CONTENT_CACHE[endpoint]
				else:
					self.contents[idx] = _fetch_content(endpoint, self.media)
					_CONTENT_CACHE[endpoint] = self.contents[idx]
			except Exception:
				self.contents[idx] = []
			if not self.closed and idx == self.focus_idx:
				try:
					self._apply_focus(idx)
				except Exception:
					pass

	def _content(self, idx):
		return self.contents.get(idx) or []

	def _apply_focus(self, idx):
		items = self._content(idx)
		if not items:
			# Sin contenido TMDB (Géneros, Años, Trakt, Herramientas…
			# o fallo de red): sin rejilla y fondo del addon.
			self.setProperty('palantrix.section.thumbs', '')
			if idx in self.contents:
				self.setProperty('palantrix.section.fanart', control.addonFanart())
				self.setProperty('palantrix.section.itemtitle', '')
			return
		first = items[0]
		if first.get('backdrop'):
			self.setProperty('palantrix.section.fanart', first['backdrop'])
		self._set_itemtitle(first)
		for j in range(MAX_POSTERS):
			try:
				img = self.getControl(GRID_IMG + j)
				if j < len(items):
					img.setImage(items[j]['poster'])
					img.setVisible(True)
				else:
					img.setVisible(False)
			except Exception:
				pass
		self.setProperty('palantrix.section.thumbs', '1')

	def _set_itemtitle(self, item):
		title = item.get('title') or ''
		if item.get('year'):
			title = '%s (%s)' % (title, item['year'])
		self.setProperty('palantrix.section.itemtitle', title)

	def _apply_grid_focus(self, j):
		items = self._content(self.focus_idx)
		if 0 <= j < len(items):
			item = items[j]
			if item.get('backdrop'):
				self.setProperty('palantrix.section.fanart', item['backdrop'])
			self._set_itemtitle(item)

	def onFocus(self, control_id):
		try:
			idx = control_id - BTN_BASE
			if 0 <= idx < len(self.items):
				self.focus_idx = idx
				self._apply_focus(idx)
				return
			j = control_id - GRID_BTN
			if 0 <= j < MAX_POSTERS:
				self._apply_grid_focus(j)
		except Exception:
			pass

	def onAction(self, action):
		try:
			if action in self.closing_actions:
				self.doClose()
				return
			# ← desde la primera columna de la rejilla: volver al
			# apartado del menú que está activo (la navegación XML de
			# esos botones apunta a sí misma para no saltar a ciegas).
			if action.getId() == ACTION_MOVE_LEFT:
				focused = self.getFocusId()
				j = focused - GRID_BTN
				if 0 <= j < MAX_POSTERS and j % GRID_COLS == 0:
					self.setFocus(self.getControl(BTN_BASE + self.focus_idx))
		except Exception:
			pass

	def onClick(self, control_id):
		try:
			idx = control_id - BTN_BASE
			if 0 <= idx < len(self.items):
				self.navigated = True
				control.execute('Container.Update(%s)' % (BASE_URL % self.items[idx][1]))
				self.doClose()
				return
			j = control_id - GRID_BTN
			if 0 <= j < MAX_POSTERS:
				items = self._content(self.focus_idx)
				if j < len(items):
					self._open_item(items[j])
		except Exception:
			log_utils.error()

	def _open_item(self, item):
		"""Clic en una miniatura: película → reproducir (patrón
		Bingie, play_Item); serie → abrir sus temporadas con la
		misma URL que genera el listado clásico. Si TMDB no da el
		IMDb, se abre el listado clásico del apartado."""
		try:
			imdb, tvdb = _external_ids(item['media'], item['tmdb'])
		except Exception:
			imdb, tvdb = '', ''
		if not imdb:
			self.navigated = True
			control.execute('Container.Update(%s)' % (BASE_URL % self.items[self.focus_idx][1]))
			self.doClose()
			return
		self.navigated = True
		if item['media'] == 'movie':
			url = ('plugin://plugin.video.palantrix3/?action=play_Item'
				   '&title=%s&year=%s&imdb=%s&tmdb=%s&select=1&bingie=1'
				   % (quote_plus(item['title']), item['year'], imdb, item['tmdb']))
			control.execute('RunPlugin(%s)' % url)
		else:
			art = {'poster': item['poster'], 'tvshow.poster': item['poster'],
				   'fanart': item['backdrop'], 'icon': item['poster'],
				   'thumb': item['poster'], 'banner': '', 'clearlogo': '',
				   'tvshow.clearlogo': '', 'clearart': '', 'tvshow.clearart': '',
				   'landscape': item['backdrop']}
			url = ('plugin://plugin.video.palantrix3/?action=seasons'
				   '&tvshowtitle=%s&year=%s&imdb=%s&tmdb=%s&tvdb=%s&art=%s'
				   % (quote_plus(item['title']), item['year'], imdb,
					  item['tmdb'], tvdb, quote_plus(json.dumps(art))))
			control.execute('Container.Update(%s)' % url)
		self.doClose()

	def doClose(self):
		self.closed = True
		self.close()
