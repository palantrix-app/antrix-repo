# -*- coding: utf-8 -*-
"""
	PalAntriX 2.0.0 — Ventanas de la «Colección» (apartado Palantir).

	ColeccionHome · ColeccionMenuWindow · ColeccionGrid ·
	ColeccionEpisodios · EnlacesWindow, con la piel aprobada
	(negro, acento azul FF2171FF, barra lateral fija).

	Sin lógica de motor: los datos vienen de coleccion_runtime
	(Catalog.spec_rows/spec_count, Vault.seasons/episodes/links_meta)
	y la reproducción de coleccion_runtime.play_vault (bóveda ->
	AllDebrid.unrestrict_link -> Player de luc).

	Las especificaciones de contenido (qué filas y qué menús) son las
	de palantrix2 (menus.py: _root/_mas/_peliculas/_series/
	_telenovelas/_musica/_categoria y los dinámicos de «Buscar por»),
	portadas aquí COMO DATOS, sin sus ventanas.
"""

import json

import xbmc
import xbmcgui

from resources.lib.modules import control
from resources.lib.modules import coleccion_runtime
from resources.lib.modules import log_utils
from resources.lib.windows.base import BaseDialog

ADDON_ID = 'plugin.video.palantrix3'

# ───────────────────────── barra lateral (compartida) ─────────────────────
SIDEBAR = [
	(1101, 'Inicio', 'home'),
	(1102, 'Películas', 'movies'),
	(1103, 'Series', 'tvshows'),
	(1104, 'Colección', 'coleccion'),
	(1105, 'Mi lista', 'milista'),
	(1106, 'Buscar', 'search'),
	(1107, 'Ajustes', 'settings'),
]
LBL_STATUS = 1190

_SIDEBAR_ACTIONS = {
	'home': 'p3_home',
	'movies': 'p3_peliculas',
	'tvshows': 'p3_series',
	'coleccion': 'p3_coleccion',
	'milista': 'p3_milista',
	'search': 'p3_search',
	'settings': 'p3_settings',
}


def _addon_path():
	return control.addonPath(ADDON_ID)


def sidebar_init(win, active):
	"""Pinta la barra lateral y marca la sección activa en azul."""
	for cid, label, key in SIDEBAR:
		try:
			btn = win.getControl(cid)
			if key == active:
				btn.setLabel('[COLOR FF2171FF][B]%s[/B][/COLOR]' % label)
			else:
				btn.setLabel(label)
		except Exception:
			pass


def sidebar_click(win, control_id, active):
	"""Gestiona un clic en la barra lateral. True si era de la barra."""
	for cid, _label, key in SIDEBAR:
		if control_id != cid:
			continue
		if key == active:
			return True
		action = _SIDEBAR_ACTIONS.get(key)
		if action:
			win.close()
			control.execute('RunPlugin(plugin://%s/?action=%s)' % (ADDON_ID, action))
		return True
	return False


def status_text():
	"""Línea de estado al pie de la barra: datos de la Colección."""
	try:
		if not coleccion_runtime.data_ready():
			return 'Colección · sin datos todavía'
		from coleccion import update as col_update
		ver = col_update.local_version(coleccion_runtime._profile()) or '—'
		txt = 'Colección · datos %s' % ver
		v = coleccion_runtime.get_vault()
		if v is not None:
			try:
				txt += ' · %s enlaces' % '{:,}'.format(v.total_links()).replace(',', '.')
			except Exception:
				pass
		return txt
	except Exception:
		return 'Colección'


def _img(path, size='w500'):
	try:
		from coleccion.db import img
		return img(path, size)
	except Exception:
		return path or ''


def _fmt_num(n):
	return '{:,}'.format(int(n or 0)).replace(',', '.')


def audio_label(audio):
	"""Etiqueta de audio en castellano: Castellano / Latino / tal cual."""
	a = (audio or '').strip()
	low = a.lower()
	toks = set(t for t in __import__('re').split(r'[^a-z]+', low) if t)
	if 'esp' in toks or 'spa' in toks or 'castellano' in low:
		return 'Castellano'
	if 'lat' in toks:
		return 'Latino'
	return a


def _play_live_fallback(kind, tmdb, season=None, episode=None):
	"""Respaldo en vivo (luc) cuando la bóveda no tiene el contenido
	o ningún enlace suyo resuelve — prevalencia P3: la bóveda va
	primero, luc detrás; nunca un callejón sin salida. Se lanza el
	play_Item del motor con nocollection=1 para no reintentar la
	bóveda en el gancho del router. Devuelve True si se lanzó."""
	try:
		from urllib.parse import quote_plus as _qp
		detail = coleccion_runtime.get_catalog().detail(kind, int(tmdb))
		if detail is None:
			return False
		meta = coleccion_runtime.build_meta(kind, detail, season, episode)
		title = meta.get('title') or ''
		metaj = _qp(json.dumps(meta))
		if kind == 'pelicula':
			cmd = ('RunPlugin(plugin://plugin.video.palantrix3/?action=play_Item'
				   '&title=%s&year=%s&imdb=%s&tmdb=%s&meta=%s&bingie=1'
				   '&nocollection=1)'
				   % (_qp(title), meta.get('year') or '',
					  meta.get('imdb') or '', tmdb, metaj))
		else:
			cmd = ('RunPlugin(plugin://plugin.video.palantrix3/?action=play_Item'
				   '&title=%s&year=%s&imdb=%s&tmdb=%s&tvdb=%s&season=%s'
				   '&episode=%s&tvshowtitle=%s&premiered=%s&meta=%s&bingie=1'
				   '&nocollection=1)'
				   % (_qp(title), meta.get('year') or '',
					  meta.get('imdb') or '', tmdb, '', season, episode,
					  _qp(title), _qp(str(meta.get('premiered') or '')), metaj))
		control.execute(cmd)
		return True
	except Exception:
		log_utils.error()
		return False


def play_or_notify(kind, tmdb, season=None, episode=None, link_rowid=None):
	"""Reproduce desde la bóveda; si la bóveda no lo tiene o ningún
	enlace responde, cae a la búsqueda en vivo de luc (respaldo P3).
	Solo cuando el usuario eligió UN enlace concreto a mano
	(link_rowid) y ese falla, se avisa en pantalla sin cambiar de
	vía: fue su elección expresa."""
	ok = False
	try:
		ok = coleccion_runtime.play_vault(kind, tmdb, season, episode, link_rowid)
	except Exception:
		log_utils.error()
	if not ok and link_rowid is None:
		ok = _play_live_fallback(kind, tmdb, season, episode)
	if not ok:
		xbmcgui.Dialog().ok(
			'Colección',
			'Ningún enlace de la bóveda ha respondido para este título.\n'
			'Comprueba que AllDebrid está vinculado en Ajustes.')
	return ok


# ════════════════ SPECS DE CONTENIDO (portadas de palantrix2) ═════════════
LETRAS = [chr(c) for c in range(ord('A'), ord('Z') + 1)] + ['Ñ', '0-9']


def _n(id_, titulo, dest, grupo=None, **kw):
	d = {'id': id_, 'titulo': titulo, 'dest': dest, 'grupo': grupo}
	d.update(kw)
	return d


def _grid(id_, titulo, spec, grupo=None, unidad='títulos', **kw):
	return _n(id_, titulo, 'grid', grupo, spec=spec, unidad=unidad, **kw)


def _spec(kind, order='updated', **filtros):
	s = {'tipo': 'grid', 'kind': kind, 'order': order}
	s.update(filtros)
	return s


def _cats_peli(cat):
	return [cat, 'Ducumental'] if cat == 'Documental' else [cat]


def _root():
	return 'Colección', [
		_n('peliculas', 'Películas', 'hub', kind='pelicula',
		   sample=_spec('pelicula', 'fecha', novedad=True)),
		_n('series', 'Series', 'hub', kind='serie',
		   sample=_spec('serie', 'updated')),
		_n('mas', 'Más', 'menu', menu='mas',
		   sample={'tipo': 'novedades'}),
	]


def _mas():
	return 'Más', [
		_grid('mi_lista', 'Mi lista', {'tipo': 'favoritos'},
			  unidad='títulos', siempre=True),
		_grid('novedades', 'Novedades', {'tipo': 'novedades'},
			  unidad='títulos', siempre=True),
		_n('telenovelas', 'Telenovelas', 'menu', menu='telenovelas',
		   sample=_spec('serie', categorias=['Novela'])),
		_n('documentales', 'Documentales', 'menu', menu='cat:Documental',
		   sample=_spec('pelicula', categorias=_cats_peli('Documental'))),
		_n('dibujos', 'Dibujos', 'menu', menu='cat:Dibujo',
		   sample=_spec('pelicula', categorias=['Dibujo'])),
		_n('anime', 'Anime', 'menu', menu='cat:Anime',
		   sample=_spec('pelicula', categorias=['Anime'])),
		_n('musica', 'Música', 'menu', menu='musica',
		   sample=_spec('pelicula', categorias=['Música'])),
		_n('buscar', 'Buscar por título', 'search', amb=None),
		_n('servicios', 'Servicios', 'servicios'),
	]


def _peliculas():
	g1, g2, g3 = 'Descubrir', 'Explorar', 'Buscar por'
	return 'Películas', [
		_grid('pel:novedades', 'Novedades', _spec('pelicula', 'fecha', novedad=True), g1),
		_grid('pel:anadidas', 'Últimas añadidas', _spec('pelicula', 'updated'), g1),
		_grid('pel:recomendadas', 'Recomendadas', _spec('pelicula', 'recomendadas'), g1),
		_grid('pel:populares', 'Populares', _spec('pelicula', 'populares'), g1),
		_grid('pel:populares_mes', 'Populares este mes',
			  _spec('pelicula', 'populares', novedad=True), g1),
		_grid('pel:sagas', 'Por sagas', {'tipo': 'colecciones'}, g2, unidad='sagas'),
		_grid('pel:especial', 'Especial', {'tipo': 'colecciones', 'especiales': True},
			  g2, unidad='sagas'),
		_n('pel:titulo', 'Título', 'search', g3, amb='pelicula'),
		_n('pel:generos', 'Géneros', 'menu', g3, menu='generos',
		   params={'titulo': 'Géneros · Películas', 'base': {'kind': 'pelicula'}}),
		_n('pel:az', 'Orden alfabético (A–Z)', 'menu', g3, menu='letras',
		   params={'titulo': 'A–Z · Películas', 'base': {'kind': 'pelicula'}}),
		_n('pel:ano', 'Año', 'menu', g3, menu='anos',
		   params={'titulo': 'Año · Películas', 'base': {'kind': 'pelicula'}}),
		_n('pel:calidad', 'Calidad', 'menu', g3, menu='calidades',
		   params={'titulo': 'Calidad · Películas', 'base': {'kind': 'pelicula'}}),
	]


def _series():
	g1, g2, g3 = 'Descubrir', 'Explorar', 'Buscar por'
	return 'Series', [
		_grid('ser:actualizaciones', 'Últimas actualizaciones', _spec('serie', 'updated'), g1),
		_grid('ser:nuevas', 'Series nuevas', _spec('serie', 'fecha', novedad=True), g1),
		_grid('ser:seguimiento', 'En seguimiento', {'tipo': 'seguimiento'}, g1,
			  unidad='series'),
		_grid('ser:recomendadas', 'Recomendadas', _spec('serie', 'recomendadas'), g1),
		_grid('ser:populares', 'Populares', _spec('serie', 'populares'), g1),
		_grid('ser:populares_mes', 'Populares este mes',
			  _spec('serie', 'populares', novedad=True), g1),
		_grid('ser:clasicas', 'Clásicas', _spec('serie', 'updated', categorias=['Retro']), g2),
		_grid('ser:reality', 'Reality', _spec('serie', 'updated', categorias=['Reality']), g2),
		_n('ser:titulo', 'Título', 'search', g3, amb='serie'),
		_n('ser:generos', 'Géneros', 'menu', g3, menu='generos',
		   params={'titulo': 'Géneros · Series', 'base': {'kind': 'serie'}}),
		_n('ser:ano', 'Año', 'menu', g3, menu='anos',
		   params={'titulo': 'Año · Series', 'base': {'kind': 'serie'}}),
		_n('ser:az', 'Orden alfabético (A–Z)', 'menu', g3, menu='letras',
		   params={'titulo': 'A–Z · Series', 'base': {'kind': 'serie'}}),
		_n('ser:calidad', 'Calidad', 'menu', g3, menu='calidades',
		   params={'titulo': 'Calidad · Series', 'base': {'kind': 'serie'}}),
	]


def _telenovelas():
	base = {'kind': 'serie', 'categorias': ['Novela']}
	return 'Telenovelas', [
		_grid('tel:actualizaciones', 'Últimas actualizaciones',
			  _spec('serie', 'updated', categorias=['Novela'])),
		_grid('tel:nuevas', 'Series nuevas',
			  _spec('serie', 'fecha', categorias=['Novela'], novedad=True)),
		_n('tel:titulo', 'Buscar por título', 'search', amb='serie'),
		_n('tel:az', 'Orden alfabético (A–Z)', 'menu', menu='letras',
		   params={'titulo': 'A–Z · Telenovelas', 'base': base}),
	]


def _musica():
	return 'Música', [
		_grid('mus:novedades', 'Novedades',
			  _spec('pelicula', 'fecha', categorias=['Música'], novedad=True)),
		_grid('mus:anadidas', 'Últimas añadidas',
			  _spec('pelicula', 'updated', categorias=['Música'])),
		_n('mus:titulo', 'Buscar por título', 'search', amb='pelicula'),
	]


def _categoria(cat):
	titulo = {'Dibujo': 'Dibujos', 'Anime': 'Anime',
			  'Documental': 'Documentales'}[cat]
	cats_p = _cats_peli(cat)
	gp, gs = 'Películas', 'Series'
	cid = 'cat' + cat
	return titulo, [
		_grid(cid + ':p_novedades', 'Novedades',
			  _spec('pelicula', 'fecha', categorias=cats_p, novedad=True), gp),
		_grid(cid + ':p_anadidas', 'Últimas añadidas',
			  _spec('pelicula', 'updated', categorias=cats_p), gp),
		_grid(cid + ':p_sagas', 'Por sagas', {'tipo': 'colecciones'}, gp, unidad='sagas'),
		_grid(cid + ':p_especial', 'Especial',
			  {'tipo': 'colecciones', 'especiales': True}, gp, unidad='sagas'),
		_n(cid + ':p_titulo', 'Buscar por título', 'search', gp, amb='pelicula'),
		_n(cid + ':p_calidad', 'Por calidad', 'menu', gp, menu='calidades',
		   params={'titulo': 'Calidad · %s' % titulo,
				   'base': {'kind': 'pelicula', 'categorias': cats_p}}),
		_n(cid + ':p_az', 'Orden alfabético (A–Z)', 'menu', gp, menu='letras',
		   params={'titulo': 'A–Z · %s' % titulo,
				   'base': {'kind': 'pelicula', 'categorias': cats_p}}),
		_grid(cid + ':s_actualizaciones', 'Últimas actualizaciones',
			  _spec('serie', 'updated', categorias=[cat]), gs),
		_grid(cid + ':s_nuevas', 'Series nuevas',
			  _spec('serie', 'fecha', categorias=[cat], novedad=True), gs),
		_n(cid + ':s_titulo', 'Buscar por título', 'search', gs, amb='serie'),
		_n(cid + ':s_az', 'Orden alfabético (A–Z)', 'menu', gs, menu='letras',
		   params={'titulo': 'A–Z · %s' % titulo,
				   'base': {'kind': 'serie', 'categorias': [cat]}}),
	]


def _dyn_letras(catalog, params):
	base = params.get('base') or {}
	conteos = catalog.letras_con_conteo(base.get('kind', 'pelicula'),
										base.get('categorias'))
	nodes = []
	for letra in LETRAS:
		n = conteos.get(letra, 0)
		if not n:
			continue
		spec = {'tipo': 'grid', 'kind': base.get('kind', 'pelicula'),
				'order': 'titulo', 'letra': letra}
		if base.get('categorias'):
			spec['categorias'] = base['categorias']
		nodes.append(_grid('letra:' + letra, letra, spec,
						   nota='%s títulos' % _fmt_num(n), contado=True))
	return params.get('titulo', 'A–Z'), nodes


def _dyn_generos(catalog, params):
	base = params.get('base') or {}
	conteos = catalog.generos_con_conteo(base.get('kind', 'pelicula'),
										 base.get('categorias'))
	nodes = []
	for genero in sorted(conteos):
		spec = {'tipo': 'grid', 'kind': base.get('kind', 'pelicula'),
				'order': 'updated', 'genero': genero}
		if base.get('categorias'):
			spec['categorias'] = base['categorias']
		nodes.append(_grid('genero:' + genero, genero, spec,
						   nota='%s títulos' % _fmt_num(conteos[genero]), contado=True))
	return params.get('titulo', 'Géneros'), nodes


def _dyn_anos(catalog, params):
	base = params.get('base') or {}
	nodes = []
	for year, n in catalog.anos_con_conteo(base.get('kind', 'pelicula'),
										   base.get('categorias')):
		spec = {'tipo': 'grid', 'kind': base.get('kind', 'pelicula'),
				'order': 'fecha', 'year': year}
		if base.get('categorias'):
			spec['categorias'] = base['categorias']
		nodes.append(_grid('ano:' + str(year), str(year), spec,
						   nota='%s títulos' % _fmt_num(n), contado=True))
	return params.get('titulo', 'Año'), nodes


def _dyn_calidades(catalog, params):
	base = params.get('base') or {}
	kind = base.get('kind', 'pelicula')
	conteos = catalog.calidades_con_conteo(kind)
	nodes = []
	for cubo in ('DV', '4K', '1080p', 'HD', 'SD'):
		n = conteos.get(cubo, 0)
		if not n:
			continue
		spec = {'tipo': 'grid', 'kind': kind, 'order': 'updated', 'calidad': cubo}
		if base.get('categorias'):
			spec['categorias'] = base['categorias']
		nodes.append(_grid('calidad:' + cubo, cubo, spec,
						   nota='%s títulos' % _fmt_num(n), contado=True))
	return params.get('titulo', 'Calidad'), nodes


_BUILDERS = {
	'root': lambda cat, params: _root(),
	'mas': lambda cat, params: _mas(),
	'peliculas': lambda cat, params: _peliculas(),
	'series': lambda cat, params: _series(),
	'telenovelas': lambda cat, params: _telenovelas(),
	'musica': lambda cat, params: _musica(),
	'letras': lambda cat, params: _dyn_letras(cat, params or {}),
	'generos': lambda cat, params: _dyn_generos(cat, params or {}),
	'anos': lambda cat, params: _dyn_anos(cat, params or {}),
	'calidades': lambda cat, params: _dyn_calidades(cat, params or {}),
}


def build_menu(menu_id, catalog, params=None):
	if menu_id.startswith('cat:'):
		return _categoria(menu_id[4:])
	builder = _BUILDERS.get(menu_id)
	if builder is None:
		return '', []
	return builder(catalog, params)


def visible_nodes(nodes, catalog):
	"""Regla del mapa: una rejilla sin contenido no se pinta (salvo
	«siempre»/«contado»); un grupo vacío pierde su encabezado."""
	out = []
	for node in nodes:
		if node.get('dest') == 'grid' and node.get('spec') is not None:
			if node.get('contado') or node.get('siempre'):
				out.append(node)
				continue
			if node['spec'].get('tipo') == 'colecciones':
				out.append(node)
				continue
			try:
				n = catalog.spec_count(node['spec'])
			except Exception:
				n = 1
			if n <= 0:
				continue
			node = dict(node)
			if not node.get('nota'):
				node['nota'] = '%s %s' % (_fmt_num(n), node.get('unidad', 'títulos'))
		out.append(node)
	display = []
	grupos_vistos = set()
	for node in out:
		g = node.get('grupo')
		if g and g not in grupos_vistos:
			display.append({'id': '__h__' + g, 'titulo': g.upper(),
							'dest': 'header', 'grupo': g})
			grupos_vistos.add(g)
		display.append(node)
	return display


# ════════════════ apertura de títulos (compartida) ════════════════
def open_title(row):
	"""Clic en un póster de la Colección: película -> bóveda directa;
	serie -> Temporadas/Episodios; saga -> su rejilla."""
	if row.get('_coleccion'):
		w = ColeccionGrid('p3_coleccion_grid.xml', _addon_path(), 'Default', '1080i',
						  spec={'tipo': 'coleccion', 'coleccion': row.get('id')},
						  titulo=row.get('titulo') or 'Saga')
		w.doModal()
		del w
		return
	kind = row.get('kind') or 'pelicula'
	tmdb = row.get('tmdb')
	if tmdb is None:
		return
	if kind == 'pelicula':
		play_or_notify('pelicula', tmdb)
	else:
		open_episodios(tmdb, row.get('titulo') or '')


def open_episodios(tmdb, titulo=''):
	w = ColeccionEpisodios('p3_coleccion_episodios.xml', _addon_path(),
						   'Default', '1080i', tmdb=int(tmdb), titulo=titulo)
	w.doModal()
	del w


def open_enlaces(kind, tmdb, season=None, episode=None, titulo=''):
	w = EnlacesWindow('p3_enlaces.xml', _addon_path(), 'Default', '1080i',
					  kind=kind, tmdb=int(tmdb), season=season,
					  episode=episode, titulo=titulo)
	w.doModal()
	del w


def open_node(win, node):
	dest = node.get('dest')
	if dest == 'menu':
		w = ColeccionMenuWindow('p3_coleccion_menu.xml', _addon_path(),
								'Default', '1080i', menu_id=node.get('menu'),
								params=node.get('params'))
		w.doModal()
		del w
	elif dest == 'hub':
		menu_id = 'peliculas' if node.get('kind') == 'pelicula' else 'series'
		w = ColeccionMenuWindow('p3_coleccion_menu.xml', _addon_path(),
								'Default', '1080i', menu_id=menu_id)
		w.doModal()
		del w
	elif dest == 'grid':
		w = ColeccionGrid('p3_coleccion_grid.xml', _addon_path(), 'Default', '1080i',
						  spec=node.get('spec'), titulo=node.get('titulo') or '')
		w.doModal()
		del w
	elif dest == 'search':
		from resources.lib.windows import p3_search
		w = p3_search.SearchWindow('p3_search.xml', _addon_path(), 'Default', '1080i')
		w.doModal()
		del w
	elif dest == 'servicios':
		from resources.lib.windows import p3_settings
		w = p3_settings.SettingsWindow('p3_settings.xml', _addon_path(),
									   'Default', '1080i')
		w.doModal()
		del w


def _poster_item(row, catalog=None):
	"""ListItem de póster con título legible y marca NUEVO en azul."""
	li = xbmcgui.ListItem(label=row.get('titulo') or '')
	poster = _img(row.get('poster'))
	fanart = _img(row.get('fondo'), 'w1280')
	li.setArt({'poster': poster, 'fanart': fanart, 'thumb': poster})
	meta = []
	if row.get('fecha'):
		meta.append(str(row.get('fecha'))[:4])
	if row.get('rating'):
		meta.append('★ %s' % str(row.get('rating')).split('/')[0])
	if row.get('_coleccion') and row.get('num'):
		meta.append('%s películas' % row.get('num'))
	li.setLabel2(' · '.join(meta))
	nuevo = bool(row.get('nuevo'))
	if not nuevo and catalog is not None and row.get('tmdb') is not None \
			and not row.get('_coleccion'):
		try:
			nuevo = catalog.es_nuevo(row.get('kind') or 'pelicula', row.get('tmdb'))
		except Exception:
			nuevo = False
	li.setProperty('p3_nuevo', '1' if nuevo else '')
	return li


# ════════════════ ColeccionHome ════════════════
ROW_LIST0 = 6000
ROW_LABEL0 = 6500
MAX_ROWS = 8

HOME_ROWS = [
	('Novedades', {'tipo': 'novedades'}),
	('Películas · Novedades', _spec('pelicula', 'fecha', novedad=True)),
	('Películas · Últimas añadidas', _spec('pelicula', 'updated')),
	('Películas · Populares', _spec('pelicula', 'populares')),
	('Series · Últimas actualizaciones', _spec('serie', 'updated')),
	('Series · Nuevas', _spec('serie', 'fecha', novedad=True)),
	('Series · Populares', _spec('serie', 'populares')),
	('Mi lista', {'tipo': 'favoritos'}),
]


class ColeccionHome(BaseDialog):
	"""Raíz de la Colección: carcasa de la Principal (barra lateral
	con «Colección» activa), una fila de entradas de texto y las
	filas del catálogo alimentadas por Catalog.spec_rows."""

	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, args)
		self._rows = {}        # {índice de fila (HOME_ROWS): [filas]}
		self._entries = []     # nodos de la fila «Explorar» (lista 5999)
		self._inited = False

	def onInit(self):
		sidebar_init(self, 'coleccion')
		try:
			self.getControl(LBL_STATUS).setLabel(status_text())
		except Exception:
			pass
		if self._inited:
			return
		self._inited = True
		coleccion_runtime.ensure_data()
		if not coleccion_runtime.data_ready():
			xbmcgui.Dialog().ok('Colección',
								'La Colección aún no tiene datos en este aparato.\n'
								'Se descargarán automáticamente; vuelve a entrar en un momento.')
			return
		catalog = coleccion_runtime.get_catalog()
		# Fila de entradas (Explorar): raíz + cajón «Más» sin servicios.
		_root_t, root_nodes = _root()
		_mas_t, mas_nodes = _mas()
		self._entries = root_nodes + [n for n in mas_nodes
									  if n.get('dest') in ('menu', 'grid')
									  and n.get('id') not in ('mi_lista', 'novedades')]
		lst = self.getControl(5999)
		lst.reset()
		items = []
		for node in self._entries:
			li = xbmcgui.ListItem(label=node.get('titulo') or '')
			items.append(li)
		lst.addItems(items)
		# Filas de pósters
		for i, (titulo, spec) in enumerate(HOME_ROWS[:MAX_ROWS]):
			try:
				rows = catalog.spec_rows(spec, 0, 14)
			except Exception:
				log_utils.error()
				rows = []
			if not rows:
				self.setProperty('p3.row%d' % i, '')
				continue
			self.setProperty('p3.row%d' % i, '1')
			self._rows[i] = rows
			try:
				self.getControl(ROW_LABEL0 + i).setLabel(titulo)
				lst = self.getControl(ROW_LIST0 + i)
				lst.reset()
				lst.addItems([_poster_item(r, catalog) for r in rows])
			except Exception:
				log_utils.error()
		try:
			self.setFocusId(5999)
		except Exception:
			pass

	def onClick(self, control_id):
		if sidebar_click(self, control_id, 'coleccion'):
			return
		if control_id == 5999:
			pos = self.getControl(5999).getSelectedPosition()
			if 0 <= pos < len(self._entries):
				open_node(self, self._entries[pos])
			return
		if ROW_LIST0 <= control_id < ROW_LIST0 + MAX_ROWS:
			# El id de la lista ES el índice en HOME_ROWS; las filas
			# sin contenido están ocultas y su lista queda vacía.
			rows = self._rows.get(control_id - ROW_LIST0) or []
			pos = self.getControl(control_id).getSelectedPosition()
			if 0 <= pos < len(rows):
				open_title(rows[pos])

	def onAction(self, action):
		if action.getId() in (101, 117):  # contexto / menú: «Enlaces»
			focus = self.getFocusId()
			if ROW_LIST0 <= focus < ROW_LIST0 + MAX_ROWS:
				rows = self._rows.get(focus - ROW_LIST0) or []
				pos = self.getControl(focus).getSelectedPosition()
				if 0 <= pos < len(rows):
					row = rows[pos]
					if not row.get('_coleccion') and row.get('tmdb') is not None:
						kind = row.get('kind') or 'pelicula'
						if kind == 'pelicula':
							open_enlaces(kind, row['tmdb'],
										 titulo=row.get('titulo') or '')
						else:
							open_episodios(row['tmdb'], row.get('titulo') or '')
				return
		BaseDialog.onAction(self, action)


# ════════════════ ColeccionMenuWindow (entradas con conteo) ════════════════
MENU_LIST = 500
MENU_TITULO = 501


class ColeccionMenuWindow(BaseDialog):
	"""Lista vertical de entradas con conteo (géneros, A–Z, años,
	calidades y los menús Descubrir/Explorar/Buscar por)."""

	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, args)
		self.menu_id = kwargs.get('menu_id') or 'root'
		self.params = kwargs.get('params')
		self.titulo = ''
		self.display = []
		self._inited = False

	def onInit(self):
		sidebar_init(self, 'coleccion')
		try:
			self.getControl(LBL_STATUS).setLabel(status_text())
		except Exception:
			pass
		if self._inited:
			return
		self._inited = True
		coleccion_runtime.ensure_data()
		catalog = coleccion_runtime.get_catalog()
		self.titulo, nodes = build_menu(self.menu_id, catalog, self.params)
		self.display = visible_nodes(nodes, catalog)
		try:
			self.getControl(MENU_TITULO).setLabel(self.titulo)
		except Exception:
			pass
		lst = self.getControl(MENU_LIST)
		lst.reset()
		items = []
		for node in self.display:
			li = xbmcgui.ListItem(label=node.get('titulo') or '')
			if node.get('dest') == 'header':
				li.setProperty('header', '1')
			else:
				li.setLabel2(node.get('nota') or '')
			items.append(li)
		lst.addItems(items)
		self.setFocusId(MENU_LIST)

	def onAction(self, action):
		# Salto de encabezados de grupo (no son destinos)
		try:
			lst = self.getControl(MENU_LIST)
			pos = lst.getSelectedPosition()
			if 0 <= pos < len(self.display) and self.display[pos].get('dest') == 'header':
				step = 1 if action.getId() != 3 else -1
				nxt = pos + step
				while 0 <= nxt < len(self.display) and self.display[nxt].get('dest') == 'header':
					nxt += step
				if 0 <= nxt < len(self.display):
					lst.selectItem(nxt)
		except Exception:
			pass
		BaseDialog.onAction(self, action)

	def onClick(self, control_id):
		if sidebar_click(self, control_id, 'coleccion'):
			return
		if control_id != MENU_LIST:
			return
		lst = self.getControl(MENU_LIST)
		pos = lst.getSelectedPosition()
		if not (0 <= pos < len(self.display)):
			return
		node = self.display[pos]
		if node.get('dest') == 'header':
			return
		open_node(self, node)


# ════════════════ ColeccionGrid (rejilla paginada) ════════════════
GRID_ID = 600
GRID_TITULO = 601
GRID_CONTEO = 602
PAGE = 60


class ColeccionGrid(BaseDialog):
	"""Rejilla visual paginada por offset (lotes de 60) para una
	spec/categoría del catálogo."""

	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, args)
		self.spec = kwargs.get('spec') or {'tipo': 'novedades'}
		self.titulo = kwargs.get('titulo') or 'Colección'
		self.rows = []
		self.total = 0
		self._inited = False
		self._loading = False

	def onInit(self):
		sidebar_init(self, 'coleccion')
		try:
			self.getControl(LBL_STATUS).setLabel(status_text())
		except Exception:
			pass
		if self._inited:
			return
		self._inited = True
		coleccion_runtime.ensure_data()
		catalog = coleccion_runtime.get_catalog()
		try:
			self.total = catalog.spec_count(self.spec)
		except Exception:
			self.total = 0
		try:
			self.getControl(GRID_TITULO).setLabel(self.titulo)
		except Exception:
			pass
		self._load_page()
		self.setFocusId(GRID_ID)

	def _load_page(self):
		if self._loading:
			return
		self._loading = True
		try:
			catalog = coleccion_runtime.get_catalog()
			new = catalog.spec_rows(self.spec, len(self.rows), PAGE)
			lst = self.getControl(GRID_ID)
			items = []
			for r in new:
				li = _poster_item(r, catalog)
				if r.get('label2'):
					li.setLabel2(r.get('label2'))
				items.append(li)
			# Quitar el centinela anterior antes de añadir el lote
			if self.rows and lst.size() > len(self.rows):
				lst.removeItem(lst.size() - 1)
			self.rows.extend(new)
			if items:
				lst.addItems(items)
			if len(self.rows) < self.total:
				more = xbmcgui.ListItem(label='Cargar más')
				more.setProperty('p3_more', '1')
				lst.addItem(more)
			try:
				self.getControl(GRID_CONTEO).setLabel(
					'%s de %s títulos' % (_fmt_num(len(self.rows)), _fmt_num(self.total)))
			except Exception:
				pass
		except Exception:
			log_utils.error()
		finally:
			self._loading = False

	def onAction(self, action):
		try:
			if self.getFocusId() == GRID_ID:
				lst = self.getControl(GRID_ID)
				pos = lst.getSelectedPosition()
				if pos >= len(self.rows) and len(self.rows) < self.total:
					self._load_page()
		except Exception:
			pass
		BaseDialog.onAction(self, action)

	def onClick(self, control_id):
		if sidebar_click(self, control_id, 'coleccion'):
			return
		if control_id != GRID_ID:
			return
		lst = self.getControl(GRID_ID)
		pos = lst.getSelectedPosition()
		if pos >= len(self.rows):
			if len(self.rows) < self.total:
				self._load_page()
			return
		open_title(self.rows[pos])


# ════════════════ ColeccionEpisodios (Temporadas/Episodios) ════════════════
EP_TITULO = 1200
EP_TEMP_LIST = 700
EP_EP_LIST = 701
EP_BTN_ENLACES = 703


class ColeccionEpisodios(BaseDialog):
	"""Temporadas y episodios de una serie de la Colección, desde la
	estructura de la bóveda (Vault.seasons/episodes)."""

	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, args)
		self.tmdb = kwargs.get('tmdb')
		self.titulo = kwargs.get('titulo') or ''
		self.seasons = []
		self.episodes = []
		self._season = None
		self._inited = False

	def onInit(self):
		sidebar_init(self, 'coleccion')
		try:
			self.getControl(LBL_STATUS).setLabel(status_text())
		except Exception:
			pass
		if self._inited:
			self._reload_episodes()
			return
		self._inited = True
		try:
			self.getControl(EP_TITULO).setLabel(self.titulo)
		except Exception:
			pass
		vault = coleccion_runtime.get_vault()
		if vault is None:
			xbmcgui.Dialog().ok('Colección',
								'La bóveda no está disponible en este aparato.')
			self.close()
			return
		try:
			self.seasons = vault.seasons(self.tmdb)
		except Exception:
			log_utils.error()
			self.seasons = []
		lst = self.getControl(EP_TEMP_LIST)
		lst.reset()
		items = []
		for s in self.seasons:
			li = xbmcgui.ListItem(label='Temporada %s' % s.get('temporada'))
			li.setLabel2('%s episodios' % s.get('episodios'))
			items.append(li)
		lst.addItems(items)
		if self.seasons:
			lst.selectItem(0)
			self._season = self.seasons[0].get('temporada')
			self._reload_episodes()
		self.setFocusId(EP_EP_LIST if self.episodes else EP_TEMP_LIST)

	def _reload_episodes(self):
		vault = coleccion_runtime.get_vault()
		if vault is None or self._season is None:
			return
		try:
			self.episodes = vault.episodes(self.tmdb, self._season)
		except Exception:
			log_utils.error()
			self.episodes = []
		catalog = coleccion_runtime.get_catalog()
		lst = self.getControl(EP_EP_LIST)
		lst.reset()
		items = []
		for e in self.episodes:
			ep = e.get('episodio')
			li = xbmcgui.ListItem(label='%sx%02d' % (self._season, ep or 0))
			nuevo = False
			try:
				nuevo = catalog.episodio_nuevo(self.tmdb, self._season, ep)
			except Exception:
				nuevo = False
			li.setProperty('p3_nuevo', '1' if nuevo else '')
			if nuevo:
				li.setLabel2('Nuevo')
			items.append(li)
		lst.addItems(items)

	def onAction(self, action):
		try:
			if self.getFocusId() == EP_TEMP_LIST and self.seasons:
				pos = self.getControl(EP_TEMP_LIST).getSelectedPosition()
				if 0 <= pos < len(self.seasons):
					temp = self.seasons[pos].get('temporada')
					if temp != self._season:
						self._season = temp
						self._reload_episodes()
		except Exception:
			pass
		BaseDialog.onAction(self, action)

	def onClick(self, control_id):
		if sidebar_click(self, control_id, 'coleccion'):
			return
		if control_id == EP_TEMP_LIST:
			pos = self.getControl(EP_TEMP_LIST).getSelectedPosition()
			if 0 <= pos < len(self.seasons):
				self._season = self.seasons[pos].get('temporada')
				self._reload_episodes()
				self.setFocusId(EP_EP_LIST)
			return
		if control_id == EP_EP_LIST:
			pos = self.getControl(EP_EP_LIST).getSelectedPosition()
			if 0 <= pos < len(self.episodes):
				ep = self.episodes[pos].get('episodio')
				play_or_notify('serie', self.tmdb, self._season, ep)
			return
		if control_id == EP_BTN_ENLACES:
			pos = self.getControl(EP_EP_LIST).getSelectedPosition()
			if 0 <= pos < len(self.episodes):
				ep = self.episodes[pos].get('episodio')
				open_enlaces('serie', self.tmdb, self._season, ep,
							 titulo='%s · %sx%02d' % (self.titulo, self._season, ep or 0))


# ════════════════ EnlacesWindow (acción p3_enlaces) ════════════════
ENL_LIST = 800
ENL_TITULO = 801


class EnlacesWindow(BaseDialog):
	"""«Enlaces · N» de la bóveda para un título/episodio, en el
	orden de calidad de la bóveda (Vault.links_meta ya ordena por
	quality_rank). Clic -> play_vault con ese enlace concreto."""

	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, args)
		self.kind = kwargs.get('kind') or 'pelicula'
		self.tmdb = kwargs.get('tmdb')
		self.season = kwargs.get('season')
		self.episode = kwargs.get('episode')
		self.titulo = kwargs.get('titulo') or ''
		self.links = []
		self._inited = False

	def onInit(self):
		if self._inited:
			return
		self._inited = True
		vault = coleccion_runtime.get_vault()
		if vault is not None:
			try:
				self.links = vault.links_meta(self.kind, self.tmdb,
											  self.season, self.episode)
			except Exception:
				log_utils.error()
				self.links = []
		try:
			self.getControl(ENL_TITULO).setLabel('Enlaces · %d' % len(self.links))
		except Exception:
			pass
		lst = self.getControl(ENL_LIST)
		lst.reset()
		items = []
		for link in self.links:
			calidad = link.get('calidad') or '—'
			audio = audio_label(link.get('audio'))
			info = (link.get('info') or '').strip()
			li = xbmcgui.ListItem(label=calidad)
			parts = [p for p in (audio, info) if p]
			li.setLabel2(' · '.join(parts))
			items.append(li)
		lst.addItems(items)
		if not self.links:
			xbmcgui.Dialog().ok('Colección',
								'Este título no tiene enlaces en la bóveda.')
			self.close()
			return
		self.setFocusId(ENL_LIST)

	def onClick(self, control_id):
		if control_id != ENL_LIST:
			return
		pos = self.getControl(ENL_LIST).getSelectedPosition()
		if 0 <= pos < len(self.links):
			rowid = self.links[pos].get('rowid')
			if play_or_notify(self.kind, self.tmdb, self.season,
							  self.episode, link_rowid=rowid):
				self.close()
