# -*- coding: utf-8 -*-
"""
	PalAntriX 2.0.0 — PIEL EN VIVO (ventanas propias negro/azul).

	P3HomeXML: Principal / Películas / Series / Más sobre la mecánica de
	BingieSectionHomeXML (filas horizontales 6000+, héroe que se refresca
	con el foco, paginación con tarjeta «Página siguiente»), con la piel
	nueva: barra lateral fija, héroe a la derecha y clic en un póster que
	abre la FICHA (p3_detail) en vez de reproducir directo.

	Regla de oro (PLAN §3.2): la línea de estado de la barra lateral
	(AllDebrid · Trakt · Colección) se REEVALÚA en cada onInit, también
	cuando la ventana recupera el foco; nunca se cachea de la primera
	apertura.

	El motor no se toca: los datos vienen de los fetchers del launcher
	bingie (Movies().get/getTMDb, TVshows().get/getTMDb) y de traktsync
	para «Seguimiento» (patrón _load_items de palantrix_home.py).
"""

from urllib.parse import quote_plus

from resources.lib.modules import control
from resources.lib.windows.bingie_section_home import BingieSectionHomeXML, ROW_BASE_ID, MAX_ROWS

ADDON = 'plugin://plugin.video.palantrix3/'

# Barra lateral: (id de control, etiqueta, acción p3_*, clave de sección)
SIDEBAR = [
	(3000, 'Inicio', 'p3_home', 'principal'),
	(3001, 'Películas', 'p3_peliculas', 'peliculas'),
	(3002, 'Series', 'p3_series', 'series'),
	(3003, 'Colección', 'p3_coleccion', 'coleccion'),
	(3004, 'Mi lista', 'p3_milista', 'milista'),
	(3005, 'Buscar', 'p3_search', 'buscar'),
	(3006, 'Ajustes', 'p3_settings', 'ajustes'),
	(3007, 'Más', 'p3_mas', 'mas'),
]
SIDEBAR_BY_ID = dict((c, (a, s)) for c, _l, a, s in SIDEBAR)
SIDEBAR_BY_SECTION = dict((s, c) for c, _l, _a, s in SIDEBAR)

# 2.0.1 (defecto 3): la Principal ya NO muestra indicadores de
# estado de AllDebrid/Trakt/Colección bajo el menú — petición expresa
# de Àngel: nada en su lugar. El estado de cada servicio se ve en
# Ajustes, que es su sitio.


# ─────────────────────── fetchers por fila ───────────────────────

def _fetch_movies(url, tmdb=False):
	from resources.lib.modules import bingie_section_launcher
	return bingie_section_launcher._fetch_movies(url, tmdb)


def _fetch_tvshows(url, tmdb=False):
	from resources.lib.modules import bingie_section_launcher
	return bingie_section_launcher._fetch_tvshows(url, tmdb)


def _fetch_seguimiento(url, tmdb=False):
	"""«Seguimiento»: series/películas con marcador en traktsync
	(patrón _load_items de windows/palantrix_home.py), lo último
	visto arriba.

	2.0.2 (defectos vistos por Àngel en su proyector): la fila se
	PAGINA en local — antes todo lo que pasaba de la primera vista
	se perdía, sin tarjeta de «Página siguiente» — y cada página se
	ENRIQUECE desde TMDB/metacaché: los marcadores de Trakt solo
	traen ids, así que las tarjetas salían con el icono del addon
	en vez de con sus pósters; ahora traen póster/fanart reales y
	el título en castellano cuando TMDB lo tiene."""
	from resources.lib.windows.bingie_section_home import ROW_PREVIEW
	offset = 0
	if url and '#' in url:
		try:
			offset = int(url.rsplit('#', 1)[1])
		except Exception:
			offset = 0
	items, seen = [], set()
	try:
		from resources.lib.database import traktsync
		rows = []
		for ret_type in ('episodes', 'movies'):
			try:
				part = traktsync.fetch_bookmarks('', ret_all=True, ret_type=ret_type) or []
			except Exception:
				part = []
			for r in part:
				r['_bm_movie'] = (ret_type == 'movies')
			rows += part
		rows.sort(key=lambda r: r.get('paused_at') or '', reverse=True)
		for row in rows:
			tmdb = row.get('tmdb') or ''
			imdb = row.get('imdb') or ''
			key = tmdb or imdb
			if not key or key in seen:
				continue
			title = row.get('tvshowtitle') or row.get('title') or ''
			if not title:
				continue
			seen.add(key)
			items.append({
				'title': title, 'tvshowtitle': title,
				'year': row.get('year') or '', 'imdb': imdb, 'tmdb': tmdb,
				'tvdb': row.get('tvdb') or '', 'mediatype': 'tvshow',
				'plot': '', '_p3_media': 'tvshow',
				'_bm_movie': bool(row.get('_bm_movie')),
			})
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()
		return []
	page = items[offset:offset + ROW_PREVIEW]
	if page and offset + ROW_PREVIEW < len(items):
		page[-1]['next'] = 'p3_seguimiento#%d' % (offset + ROW_PREVIEW)
	_enrich_seguimiento(page)
	return page


def _enrich_seguimiento(page):
	"""Rellena la página de «Seguimiento» con la meta de TMDB (vía
	metacaché primero; lo que falte se pide y se cachea): póster,
	fanart, trama, nota y título localizado. Si algo falla, la
	tarjeta se queda con el arte del addon, como antes."""
	if not page:
		return
	try:
		from resources.lib.indexers import tmdb as _tmdb_idx
		from resources.lib.database import metacache
		movies_idx = _tmdb_idx.Movies()
		lang, user = movies_idx.lang, movies_idx.user
		try:
			metacache.fetch(page, lang, user)
		except Exception:
			pass
		shows_idx = None
		fresh = []
		for it in page:
			# título localizado ya presente (metacaché): se sincroniza
			if it.get('_bm_movie'):
				if it.get('title'):
					it['tvshowtitle'] = it['title']
			elif it.get('tvshowtitle'):
				it['title'] = it['tvshowtitle']
			if it.get('poster'):
				continue
			tid = it.get('tmdb') or ''
			if not tid:
				continue
			meta = None
			try:
				if it.get('_bm_movie'):
					meta = movies_idx.get_movie_meta(tid, it.get('imdb') or None)
				else:
					if shows_idx is None:
						shows_idx = _tmdb_idx.TVshows()
					meta = shows_idx.get_showSeasons_meta(tid)
			except Exception:
				meta = None
			if not meta:
				continue
			for k in ('poster', 'fanart', 'plot', 'rating', 'genre', 'premiered'):
				if meta.get(k):
					it[k] = meta[k]
			if it.get('_bm_movie'):
				if meta.get('title'):
					it['title'] = meta['title']
					it['tvshowtitle'] = meta['title']
			elif meta.get('tvshowtitle'):
				it['tvshowtitle'] = meta['tvshowtitle']
				it['title'] = meta['tvshowtitle']
			if meta.get('premiered') and not it.get('year'):
				it['year'] = str(meta['premiered'])[:4]
			fresh.append({'imdb': it.get('imdb', ''), 'tmdb': tid,
						  'tvdb': it.get('tvdb', ''), 'lang': lang,
						  'user': user, 'item': meta})
		if fresh:
			try:
				metacache.insert(fresh)
			except Exception:
				pass
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()


def _genre_url(movies_cls, genre_id):
	"""URL discover de género EXACTAMENTE como la construye el menú de
	géneros del motor (menus/movies.py y menus/tvshows.py: genres()):
	tmdb_genre_link % ('%s', genre_id). Sin claves escritas a mano."""
	try:
		m = movies_cls()
		return m.tmdb_genre_link % ('%s', str(genre_id))
	except Exception:
		return ''


def _mas_entries():
	"""Entradas de «Más»: tarjetas de texto. Cada una abre una ruta
	VISUAL existente del motor (rejilla bingie o gestor de Trakt) vía
	RunPlugin; ninguna cae en un directorio clásico."""
	from resources.lib.menus import movies as movies_menu
	from resources.lib.menus import tvshows as tvshows_menu
	def grid(action, url, tmdb=False):
		return 'RunPlugin(%s?action=%s&url=%s%s)' % (
			ADDON, action, quote_plus(url), '&tmdb=1' if tmdb else '')
	entries = [
		('Mi lista', 'RunPlugin(%s?action=p3_milista)' % ADDON),
		('Novedades', grid('bingie_gridMovies', 'tmdb_nowplaying', tmdb=True)),
		('Telenovelas', grid('bingie_gridTVShows', _genre_url(tvshows_menu.TVshows, 10766), tmdb=True)),
		('Documentales', grid('bingie_gridMovies', _genre_url(movies_menu.Movies, 99), tmdb=True)),
		('Dibujos', grid('bingie_gridMovies', _genre_url(movies_menu.Movies, 16), tmdb=True)),
		('Anime', grid('bingie_gridMovies', 'anime')),
		('Música', grid('bingie_gridMovies', _genre_url(movies_menu.Movies, 10402), tmdb=True)),
		('Listas de Trakt', 'RunPlugin(%s?action=tools_traktLikedListManager)' % ADDON),
	]
	return [{'title': lbl, '_p3_entry': cmd, '_p3_media': 'entry', 'mediatype': 'entry'}
			for (lbl, cmd) in entries if cmd]


def _fetch_entries(url, tmdb=False):
	return _mas_entries()


_FETCHERS = {
	'movie': _fetch_movies,
	'tvshow': _fetch_tvshows,
	'seguimiento': _fetch_seguimiento,
	'entry': _fetch_entries,
}


def _fetch_mixed_tendencias(url, tmdb=False):
	"""Tendencias de la Principal: películas y series de Trakt
	entrelazadas (1 película, 1 serie…), cada ítem etiquetado con su
	media para que la ficha sepa qué es."""
	try:
		movies = _fetch_movies('trakttrending', False)
		shows = _fetch_tvshows('trakttrending', False)
	except Exception:
		movies, shows = [], []
	out = []
	for i in range(max(len(movies), len(shows))):
		if i < len(movies):
			m = dict(movies[i]); m['_p3_media'] = 'movie'; out.append(m)
		if i < len(shows):
			s = dict(shows[i]); s['_p3_media'] = 'tvshow'; out.append(s)
	return out


def _row_fetch(row, url):
	"""Despacha el fetch de una fila según su 'media'. Para páginas
	siguientes, la URL ya es la URL real de siguiente página."""
	media = row.get('media') or 'movie'
	if url == row.get('url'):
		# primera carga: tokens especiales
		if media == 'mixed':
			return _fetch_mixed_tendencias(url, row.get('tmdb', False))
		if media in _FETCHERS:
			return _FETCHERS[media](url, row.get('tmdb', False))
		return _FETCHERS.get(media, _fetch_movies)(url, row.get('tmdb', False))
	# paginación: en filas mixtas la URL de Trakt dice /movies/ o /shows/
	if media == 'mixed':
		fn = _fetch_tvshows if '/shows/' in url else _fetch_movies
		items = fn(url, row.get('tmdb', False))
		tag = 'tvshow' if fn is _fetch_tvshows else 'movie'
		for it in items:
			it['_p3_media'] = tag
		return items
	fn = _FETCHERS.get(media, _fetch_movies)
	return fn(url, row.get('tmdb', False))


# ─────────────────────── la ventana ───────────────────────

class P3HomeXML(BingieSectionHomeXML):
	def __init__(self, *args, **kwargs):
		self.section = kwargs.get('section') or 'principal'
		# La clase base lee rows/section_title/media_type/fetch_fn de
		# kwargs; media_type global solo es un respaldo: cada fila trae
		# su 'media' y cada ítem queda etiquetado con '_p3_media'.
		kwargs.setdefault('media_type', 'movie')
		kwargs['fetch_fn'] = kwargs.get('fetch_fn') or _fetch_movies
		BingieSectionHomeXML.__init__(self, *args, **kwargs)
		# Todo el texto visible en castellano (R2): la base elige la
		# etiqueta de la tarjeta de paginacion segun el idioma de Kodi;
		# aqui se fija siempre en castellano.
		self._lbl_next = 'P\u00e1gina siguiente'

	# — estado SIEMPRE reevaluado (regla de oro) —
	def onInit(self):
		try:
			self.setProperty('p3.section', self.section)
			self.setProperty('p3.section_title', self.section_title)
		except Exception:
			pass
		BingieSectionHomeXML.onInit(self)

	# — carga de filas con fetch por fila (media propia) —
	def _load_row(self, idx):
		if idx >= len(self.rows) or self._row_loaded[idx]:
			return
		row = self.rows[idx]
		try:
			items = _row_fetch(row, row['url']) or []
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()
			items = []
		for it in items:
			if isinstance(it, dict):
				it.setdefault('_p3_media', row.get('media') or self.media_type)
		st = self._row_state[idx]
		from resources.lib.windows.bingie_section_home import ROW_PREVIEW, _next_url
		st['items'] = items[:ROW_PREVIEW]
		st['next'] = _next_url(items)
		self._row_loaded[idx] = True

	def _load_next_page(self, row_idx):
		try:
			st = self._row_state[row_idx]
			nxt = st.get('next')
			if not nxt:
				return
			row = self.rows[row_idx]
			self.setProperty('luc_kodi.row_loading.%d' % row_idx, '1')
			new_items = _row_fetch(row, nxt) or []
			if not new_items:
				st['next'] = None
				self.clearProperty('luc_kodi.row_loading.%d' % row_idx)
				return
			from resources.lib.windows.bingie_section_home import ROW_PREVIEW, _next_url
			try:
				leaving_pos = self.get_position(ROW_BASE_ID + row_idx)
			except Exception:
				leaving_pos = 0
			st['history'].append({'items': st['items'], 'next': st.get('next'), 'pos': leaving_pos})
			st['page'] = st.get('page', 0) + 1
			st['items'] = new_items[:ROW_PREVIEW]
			st['next'] = _next_url(new_items)
			self._render_row(row_idx)
			try:
				self.setFocusId(ROW_BASE_ID + row_idx)
			except Exception:
				pass
			self._active_row = row_idx
			self._refresh_hero()
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()
			self.clearProperty('luc_kodi.row_loading.%d' % row_idx)

	# — tarjetas: media por ítem + marca NUEVO solo si el dato viene —
	def _make_li(self, i):
		if (i.get('_p3_media') or i.get('mediatype')) == 'entry' or i.get('_p3_entry'):
			try:
				li = control.item(label=i.get('title') or '', offscreen=True)
				li.setArt({'poster': self._addonPoster, 'thumb': self._addonPoster,
						   'fanart': self._addonFanart})
				li.setProperty('luc_entry', '1')
				return li
			except Exception:
				return None
		# mediatype correcto por ítem (la base usa el de la ventana)
		saved = self.media_type
		media = i.get('_p3_media') or saved
		self.media_type = 'tvshow' if media == 'tvshow' else 'movie'
		try:
			li = BingieSectionHomeXML._make_li(self, i)
		finally:
			self.media_type = saved
		if li is not None:
			# «NUEVO» SOLO si el ítem trae la marca en los datos; en vivo
			# el motor no la trae, así que normalmente no se pinta nada.
			try:
				if i.get('is_new') or i.get('nuevo') or i.get('_is_new'):
					li.setProperty('luc_new', '1')
			except Exception:
				pass
		return li

	def _refresh_hero(self):
		BingieSectionHomeXML._refresh_hero(self)
		# Título/tipo legibles para el héroe de la piel (la sinopsis y el
		# fanart salen del ListItem enfocado vía $INFO en el XML).
		try:
			row_idx = self._active_row
			st = self._row_state[row_idx] if row_idx < len(self._row_state) else None
			if not st:
				return
			pos = self.get_position(ROW_BASE_ID + row_idx)
			if pos == st.get('card_pos') or not (0 <= pos < len(st['items'])):
				self.setProperty('p3.hero_kind', '')
				return
			i = st['items'][pos]
			media = i.get('_p3_media') or self.media_type
			self.setProperty('p3.hero_kind', 'Serie' if media == 'tvshow' else 'Película')
			rating = self._fmt(i.get('rating'))
			self.setProperty('p3.hero_rating', rating)
		except Exception:
			pass

	# — cambio de sección EN SITIO (una sola ventana-carcasa) —
	def switch_section(self, section):
		"""La barra lateral cambia el contenido de ESTA ventana, sin
		cerrarla: «atrás» sale de la app una sola vez y nunca se cae a
		la ventana de vídeo de Kodi entre secciones."""
		if section == self.section:
			try:
				self.setFocusId(ROW_BASE_ID)
			except Exception:
				pass
			return
		from resources.lib.windows.bingie_section_home import MAX_ROWS
		title, rows, media_type = _section_spec(section)
		self.section = section
		self.section_title = title
		self.media_type = media_type
		self.rows = rows
		self._active_row = 0
		self._row_state = [{'items': [], 'next': None, 'card_pos': -1,
							'page': 0, 'history': []} for _ in rows]
		self._row_loaded = [False for _ in rows]
		self._row_rendered = [False for _ in rows]
		try:
			self.setProperty('luc_kodi.section_title', title)
			self.setProperty('p3.section', section)
			self.setProperty('p3.section_title', title)
		except Exception:
			pass
		for idx in range(MAX_ROWS):
			try:
				self.setProperty('luc_kodi.row_label.%d' % idx,
								 rows[idx].get('label', '') if idx < len(rows) else '')
				self.clearProperty('luc_kodi.row_loading.%d' % idx)
			except Exception:
				pass
			try:
				self.getControl(ROW_BASE_ID + idx).reset()
			except Exception:
				pass
		for idx in range(min(len(rows), MAX_ROWS)):
			try:
				self.setProperty('luc_kodi.row_loading.%d' % idx, '1')
			except Exception:
				pass
			self._load_row(idx)
			self._render_row(idx)
			self._row_rendered[idx] = True
		if rows and self._row_state and self._row_state[0]['items']:
			try:
				self.setFocusId(ROW_BASE_ID)
			except Exception:
				pass
		self._refresh_hero()

	# — clics: barra lateral + filas —
	def onClick(self, controlId):
		if controlId in SIDEBAR_BY_ID:
			action, section = SIDEBAR_BY_ID[controlId]
			if section in ('principal', 'peliculas', 'series', 'mas'):
				self.switch_section(section)
				return
			# Colección / Mi lista / Buscar / Ajustes: ventanas propias
			# que se abren ENCIMA; al cerrarlas se vuelve aquí (la
			# ventana NO se cierra, el estado se reevalúa en onInit).
			control.execute('RunPlugin(%s?action=%s)' % (ADDON, action))
			return
		BingieSectionHomeXML.onClick(self, controlId)

	def _select(self, row_idx):
		try:
			if self._paging:
				return
			self._active_row = row_idx
			st = self._row_state[row_idx]
			pos = self.get_position(ROW_BASE_ID + row_idx)
			if pos == st.get('card_pos'):
				self._paging = True
				try:
					self._load_next_page(row_idx)
				finally:
					import xbmc
					xbmc.sleep(150)
					self._paging = False
				return
			items = st['items']
			if not (0 <= pos < len(items)):
				return
			chosen = items[pos]
			if chosen.get('_p3_entry'):
				# Las entradas abren otra ventana/ruta ENCIMA; al
				# cerrarla se vuelve a esta (que no se cierra).
				control.execute(chosen['_p3_entry'])
				return
			# Clic en póster = FICHA (no reproduce directo).
			self._save_resume_position()
			from resources.lib.windows import p3_detail
			p3_detail.show_detail(chosen)
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()


# ─────────────────────── constructores de sección ───────────────────────

def _open(section, section_title, rows, media_type='movie'):
	window = P3HomeXML('p3_home.xml', control.addonPath(control.addonId()),
					   rows=rows, section_title=section_title,
					   media_type=media_type, section=section)
	window.run()
	del window


def _row(label, url, kind, media):
	return {'label': label, 'url': url, 'tmdb': (kind == 'tmdb'), 'media': media}


def _section_spec(section):
	"""(título, filas, media_type) de cada sección de la carcasa."""
	if section == 'peliculas':
		return ('Películas', [
			_row('Novedades', 'tmdb_nowplaying', 'tmdb', 'movie'),
			_row('Populares', 'traktpopular', 'trakt', 'movie'),
			_row('Mejor valoradas', 'tmdb_toprated', 'tmdb', 'movie'),
			_row('Próximamente', 'tmdb_upcoming', 'tmdb', 'movie'),
		], 'movie')
	if section == 'series':
		return ('Series', [
			_row('Últimas actualizaciones', 'tmdb_ontheair', 'tmdb', 'tvshow'),
			_row('Series nuevas', 'tmdb_airingtoday', 'tmdb', 'tvshow'),
			_row('Seguimiento', 'p3_seguimiento', 'local', 'seguimiento'),
			_row('Recomendadas', 'traktrecommendations', 'trakt', 'tvshow'),
			_row('Populares', 'traktpopular', 'trakt', 'tvshow'),
		], 'tvshow')
	if section == 'mas':
		return ('Más', [_row('Más', 'p3_entries', 'local', 'entry')], 'movie')
	return ('Inicio', [
		_row('Tendencias', 'p3_tendencias', 'trakt', 'mixed'),
		_row('Novedades en películas', 'tmdb_nowplaying', 'tmdb', 'movie'),
		_row('Novedades en series', 'tmdb_airingtoday', 'tmdb', 'tvshow'),
	], 'movie')


def show_principal():
	title, rows, media_type = _section_spec('principal')
	_open('principal', title, rows, media_type=media_type)


def show_peliculas():
	title, rows, media_type = _section_spec('peliculas')
	_open('peliculas', title, rows, media_type=media_type)


def show_series():
	title, rows, media_type = _section_spec('series')
	_open('series', title, rows, media_type=media_type)


def show_mas():
	title, rows, media_type = _section_spec('mas')
	_open('mas', title, rows, media_type=media_type)
