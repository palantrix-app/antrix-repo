# -*- coding: utf-8 -*-
"""Respaldo criptográfico en Python puro (solo biblioteca estándar).

Motivo: en algunos aparatos — confirmado en el Android TV del usuario
(Kodi 21.3) — el módulo pycryptodome no puede cargar (el paquete
oficial no trae binarios utilizables para esa plataforma y la
dependencia ni siquiera llega a instalarse), y la bóveda debe
funcionar igual. Este módulo implementa, con la MISMA interfaz mínima
que la app pide a pycryptodome y el MISMO formato en disco, las tres
piezas que la bóveda y los accesos remotos utilizan:

  * AES-GCM (cifrado de bloque AES en Python por tablas + GHASH en
    GF(2^128)): nonce de 12 B, etiqueta de 16 B. El formato sellado
    (ct + tag) es idéntico al de pycryptodome: un sobre sellado con
    un proveedor se abre con el otro.
  * scrypt vía hashlib.scrypt (OpenSSL, parte de la librería
    estándar), con los mismos parámetros que guarda cada envoltura
    (N=32768, r=8, p=1, clave de 32 B). Sin `maxmem` explícito,
    OpenSSL rechaza esos parámetros por su límite de memoria por
    defecto (~32 MiB y la derivación necesita algo más): se calcula
    un tope con margen.
  * get_random_bytes = os.urandom.

Solo se usa si pycryptodome no importa (vault._crypto lo resuelve);
con pycryptodome sano, este módulo ni se importa.
"""
import hashlib
import hmac as _hmac
import os

__all__ = ["AES", "scrypt", "get_random_bytes"]


# ---------------------------------------------------------------------------
# AES (solo dirección de cifrado: GCM es CTR + GHASH, nunca necesita
# descifrar bloques) — tablas generadas, sin literales de 256 entradas.
# ---------------------------------------------------------------------------
def _mul8(a, b):
    """Multiplicación en GF(2^8) con el polinomio de AES (0x11B)."""
    r = 0
    for _ in range(8):
        if b & 1:
            r ^= a
        a = ((a << 1) ^ 0x1B) & 0xFF if a & 0x80 else (a << 1) & 0xFF
        b >>= 1
    return r


def _inv8(a):
    if a == 0:
        return 0
    r, base, e = 1, a, 254
    while e:
        if e & 1:
            r = _mul8(r, base)
        base = _mul8(base, base)
        e >>= 1
    return r


def _sbox_val(a):
    inv = _inv8(a)
    s = inv
    for i in (1, 2, 3, 4):
        s ^= ((inv << i) | (inv >> (8 - i))) & 0xFF
    return (s ^ 0x63) & 0xFF


_SBOX = [_sbox_val(i) for i in range(256)]
_MUL2 = [_mul8(i, 2) for i in range(256)]
_MUL3 = [_mul8(i, 3) for i in range(256)]
_RCON = (0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40,
         0x80, 0x1B, 0x36, 0x6C, 0xD8, 0xAB, 0x4D)


class _AesCore(object):
    """Expansión de clave + cifrado de un bloque de 16 B (AES-128/192/256)."""

    def __init__(self, key):
        if len(key) not in (16, 24, 32):
            raise ValueError("longitud de clave AES no válida")
        nk = len(key) // 4
        self._nr = nk + 6
        w = [list(key[4 * i:4 * i + 4]) for i in range(nk)]
        for i in range(nk, 4 * (self._nr + 1)):
            t = list(w[i - 1])
            if i % nk == 0:
                t = [_SBOX[t[1]] ^ _RCON[i // nk - 1], _SBOX[t[2]],
                     _SBOX[t[3]], _SBOX[t[0]]]
            elif nk > 6 and i % nk == 4:
                t = [_SBOX[b] for b in t]
            w.append([w[i - nk][j] ^ t[j] for j in range(4)])
        # Claves de ronda aplanadas en el mismo orden que el estado
        # (columna mayor: el byte r + 4c es la fila r, columna c).
        self._rk = []
        for rnd in range(self._nr + 1):
            rk = []
            for c in range(4):
                rk.extend(w[4 * rnd + c])
            self._rk.append(rk)

    def encrypt_block(self, block):
        if len(block) != 16:
            raise ValueError("el bloque AES es de 16 bytes")
        s = [block[i] ^ self._rk[0][i] for i in range(16)]
        for rnd in range(1, self._nr):
            s = self._round(s, self._rk[rnd], True)
        return bytes(self._round(s, self._rk[self._nr], False))

    @staticmethod
    def _round(s, rk, mix):
        # SubBytes + ShiftRows (la fila r rota r columnas a la izquierda)
        t = [0] * 16
        for r in range(4):
            for c in range(4):
                t[r + 4 * c] = _SBOX[s[r + 4 * ((c + r) % 4)]]
        if mix:
            for c in range(4):
                a0, a1, a2, a3 = t[4 * c:4 * c + 4]
                t[4 * c + 0] = _MUL2[a0] ^ _MUL3[a1] ^ a2 ^ a3
                t[4 * c + 1] = a0 ^ _MUL2[a1] ^ _MUL3[a2] ^ a3
                t[4 * c + 2] = a0 ^ a1 ^ _MUL2[a2] ^ _MUL3[a3]
                t[4 * c + 3] = _MUL3[a0] ^ a1 ^ a2 ^ _MUL2[a3]
        return [t[i] ^ rk[i] for i in range(16)]


# ---------------------------------------------------------------------------
# GHASH / GCM
# ---------------------------------------------------------------------------
_GHASH_R = 0xE1000000000000000000000000000000


def _gf_mul(x, y):
    """Multiplicación en GF(2^128) según el algoritmo de la
    especificación GCM (bits de x de más a menos significativo)."""
    z = 0
    v = y
    for i in range(128):
        if (x >> (127 - i)) & 1:
            z ^= v
        if v & 1:
            v = (v >> 1) ^ _GHASH_R
        else:
            v >>= 1
    return z


def _ghash(h, aad, data):
    y = 0
    for chunk in (aad, data):
        for off in range(0, len(chunk), 16):
            block = chunk[off:off + 16]
            if len(block) < 16:
                block = block + b"\x00" * (16 - len(block))
            y = _gf_mul(y ^ int.from_bytes(block, "big"), h)
    lens = (len(aad) * 8).to_bytes(8, "big") + \
        (len(data) * 8).to_bytes(8, "big")
    return _gf_mul(y ^ int.from_bytes(lens, "big"), h)


class _GcmCipher(object):
    """AES-GCM con la interfaz que usa la app de pycryptodome:
    encrypt_and_digest / decrypt_and_verify (y update/encrypt/
    decrypt/digest/verify por completitud)."""

    def __init__(self, key, nonce, mac_len=16):
        self._core = _AesCore(key)
        self._mac_len = mac_len
        self.nonce = nonce
        self._h = int.from_bytes(
            self._core.encrypt_block(b"\x00" * 16), "big")
        if len(nonce) == 12:
            self._j0 = nonce + b"\x00\x00\x00\x01"
        else:
            self._j0 = _ghash(self._h, b"", nonce).to_bytes(16, "big")
        self._ctr = int.from_bytes(self._j0, "big")
        self._aad = bytearray()
        self._ct = bytearray()

    def update(self, aad):
        self._aad += aad
        return self

    def _ctr_crypt(self, data):
        out = bytearray()
        for off in range(0, len(data), 16):
            ctr = (self._ctr & ~0xFFFFFFFF) | \
                ((self._ctr + 1) & 0xFFFFFFFF)
            self._ctr = ctr
            ks = self._core.encrypt_block(ctr.to_bytes(16, "big"))
            chunk = data[off:off + 16]
            out += bytes(b ^ k for b, k in zip(chunk, ks))
        return bytes(out)

    def encrypt(self, data):
        ct = self._ctr_crypt(data)
        self._ct += ct
        return ct

    def decrypt(self, data):
        # En descifrado, lo que entra ES el texto cifrado: es lo que
        # come GHASH. La salida es el texto en claro.
        self._ct += data
        return self._ctr_crypt(data)

    def _tag(self):
        s = _ghash(self._h, bytes(self._aad), bytes(self._ct))
        e_j0 = int.from_bytes(self._core.encrypt_block(self._j0), "big")
        return (s ^ e_j0).to_bytes(16, "big")[:self._mac_len]

    def digest(self):
        return self._tag()

    def verify(self, mac):
        if not _hmac.compare_digest(bytes(mac), self._tag()):
            raise ValueError("MAC check failed")

    def encrypt_and_digest(self, data):
        return self.encrypt(data), self.digest()

    def decrypt_and_verify(self, data, mac):
        pt = self.decrypt(data)
        self.verify(mac)
        return pt


class _AesModule(object):
    """Imita el objeto módulo Crypto.Cipher.AES para la app."""

    MODE_GCM = 11  # mismo valor que en pycryptodome
    block_size = 16

    def new(self, key, mode, nonce=None, **kwargs):
        if mode != self.MODE_GCM:
            raise ValueError("el respaldo solo implementa MODE_GCM")
        if nonce is None:
            nonce = os.urandom(12)
        return _GcmCipher(key, nonce,
                          mac_len=kwargs.get("mac_len", 16))


AES = _AesModule()


# ---------------------------------------------------------------------------
# scrypt (hashlib / OpenSSL) y aleatoriedad (os.urandom)
# ---------------------------------------------------------------------------
def scrypt(password, salt, key_len, N=None, r=None, p=None, num_keys=1):
    """Misma firma y mismos resultados que Crypto.Protocol.KDF.scrypt
    para num_keys=1. `maxmem` explícito: con el defecto de OpenSSL,
    N=32768/r=8 supera el límite de memoria y la llamada falla."""
    if num_keys != 1:
        raise ValueError("el respaldo solo admite num_keys=1")
    if N is None:
        N = 16384
    if r is None:
        r = 8
    if p is None:
        p = 1
    need = 128 * r * (N + p + 2)
    maxmem = max(64 * 1024 * 1024, 2 * need)
    return hashlib.scrypt(password, salt=salt, n=N, r=r, p=p,
                          maxmem=maxmem, dklen=key_len)


def get_random_bytes(n):
    return os.urandom(n)
