"""
	PalAntriX Add-on
"""

from resources.lib.modules.control import addonPath, addonVersion, joinPath, existsPath
from resources.lib.windows.textviewer import TextViewerXML


def get(name):
	# PalAntriX tiene un único registro de novedades: el suyo, en
	# español. Se acepta cualquier nombre heredado en la llamada
	# ('luc_kodi' incluido) y siempre se muestra el de PalAntriX.
	addon_path = addonPath('plugin.video.palantrix3')
	addon_version = addonVersion('plugin.video.palantrix3')
	changelog_file = joinPath(addon_path, 'changelog.txt')
	if not existsPath(changelog_file):
		from resources.lib.modules.control import notification
		return notification(message='Archivo de novedades no encontrado.')
	f = open(changelog_file, 'r', encoding='utf-8', errors='ignore')
	text = f.read()
	f.close()
	heading = '[B]PalAntriX -  v%s - Novedades[/B]' % (addon_version)
	windows = TextViewerXML('textviewer.xml', addonPath('plugin.video.palantrix3'), heading=heading, text=text)
	windows.run()
	del windows
