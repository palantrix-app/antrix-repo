# -*- coding: utf-8 -*-
"""Bóveda de enlaces (SPEC §10).

Cada enlace vive cifrado con AES-256-GCM bajo una DEK aleatoria que solo
existe envuelta por ranuras (maestra / instalación / PIN de familiar).
Se descifra enlace a enlace, en memoria, solo al reproducir. Nada descifrado
toca el disco. La estructura (temporadas, episodios, calidades) se puede
consultar sin desbloquear; las direcciones, jamás.
"""
import hashlib
import hmac
import sqlite3

from db import quality_rank

_SCRYPT = dict(N=32768, r=8, p=1)


class CryptoUnavailable(Exception):
    """Ningún proveedor de cifrado se puede cargar en este aparato
    (ni pycryptodome ni el respaldo en Python puro). La bóveda no
    está disponible, pero la app debe abrir y navegar el catálogo
    igualmente: por eso el cifrado se carga de forma perezosa
    (corrección 0.4.0-C1: importarlo en cabecera mataba la app
    entera tras cargar los datos en el Android del usuario)."""


_CRYPTO = None


def _crypto():
    """Resuelve el proveedor de cifrado la primera vez que hace
    falta de verdad (al desbloquear o descifrar) y lo cachea:

    1. pycryptodome (nativo, rápido) si importa bien.
    2. pycrypto_fallback: AES-256-GCM en Python puro + scrypt de
       hashlib, con el mismo formato — en el Android TV del usuario
       (Kodi 21.3) pycryptodome no carga y la bóveda debe funcionar
       igual. Lo sellado por un proveedor lo abre el otro.

    Si ninguno de los dos está, lanza CryptoUnavailable en vez de
    romper la importación del módulo."""
    global _CRYPTO
    if _CRYPTO is None:
        try:
            from Crypto.Cipher import AES
            from Crypto.Protocol.KDF import scrypt
            from Crypto.Random import get_random_bytes
            _sonda(AES, scrypt)
            _CRYPTO = {"AES": AES, "scrypt": scrypt,
                       "grb": get_random_bytes}
        except Exception:
            pass
        if _CRYPTO is None:
            try:
                import pycrypto_fallback as _fb
                _sonda(_fb.AES, _fb.scrypt)
            except Exception as e:
                raise CryptoUnavailable(str(e))
            _CRYPTO = {"AES": _fb.AES, "scrypt": _fb.scrypt,
                       "grb": _fb.get_random_bytes}
    return _CRYPTO


def _sonda(AES, scrypt):
    """Prueba mínima pero REAL del proveedor antes de aceptarlo:
    una derivación scrypt con los parámetros de la bóveda y un
    sellado/apertura AES-GCM. Hay plataformas donde el módulo
    importa sin error pero falla al usarlo (binario incompatible,
    hashlib sin scrypt, parámetros rechazados): sin la sonda, ese
    fallo estallaría en mitad del desbloqueo en vez de pasar al
    respaldo o al aviso claro."""
    kek = scrypt(b"sonda", b"\x00" * 16, 32, **_SCRYPT)
    c = AES.new(kek, AES.MODE_GCM, nonce=b"\x00" * 12)
    ct, tag = c.encrypt_and_digest(b"palantrix")
    c2 = AES.new(kek, AES.MODE_GCM, nonce=b"\x00" * 12)
    if c2.decrypt_and_verify(ct, tag) != b"palantrix":
        raise CryptoUnavailable("sonda de cifrado fallida")


def _wrap(secret, dek_bytes):
    salt = _crypto()["grb"](16)
    kek = _crypto()["scrypt"](secret.encode("utf-8"), salt, 32, **_SCRYPT)
    nonce = _crypto()["grb"](12)
    c = _crypto()["AES"].new(kek, _crypto()["AES"].MODE_GCM, nonce=nonce)
    ct, tag = c.encrypt_and_digest(dek_bytes)
    return salt, _SCRYPT["N"], _SCRYPT["r"], _SCRYPT["p"], nonce, ct + tag


class Vault(object):
    def __init__(self, path):
        # check_same_thread=False: la cadena de reproducción (Fase 4) usa
        # la bóveda desde su hilo de trabajo. Solo conexión, sin tocar la
        # criptografía.
        self.con = sqlite3.connect(path, check_same_thread=False, timeout=30)
        self.con.row_factory = sqlite3.Row
        self._dek = None        # bytearray solo en memoria
        self.mode = None        # 'bootstrap' | 'master' | 'slot'
        self.slot_name = None
        self.slot_id = None     # id de la wrap de ranura de la sesión
        # Contador de generación de sesión: sube en cada desbloqueo y en
        # cada bloqueo. El reproductor lo usa para invalidar de verdad su
        # memoria (URLs resueltas y precarga) cuando la sesión cambia
        # (sup4-H2 / sup2-M3).
        self.generation = 0

    # ---------- estado ----------
    @property
    def unlocked(self):
        return self._dek is not None

    @property
    def is_master(self):
        return self.mode in ("master", "bootstrap")

    def has_master(self):
        return self.con.execute(
            "SELECT COUNT(*) FROM wraps WHERE kind = 'master'").fetchone()[0] > 0

    def has_bootstrap(self):
        return self.con.execute(
            "SELECT COUNT(*) FROM wraps WHERE kind = 'bootstrap'").fetchone()[0] > 0

    def total_links(self):
        return self.con.execute("SELECT COUNT(*) FROM links").fetchone()[0]

    def lock(self):
        if self._dek is not None:
            for i in range(len(self._dek)):
                self._dek[i] = 0
        self._dek = None
        self.mode = None
        self.slot_name = None
        self.slot_id = None
        self.generation += 1

    def close(self):
        self.lock()
        try:
            self.con.close()
        except Exception:
            pass

    # ---------- desbloqueo ----------
    def unlock(self, secret):
        if not secret:
            return False
        # El código de instalación se enseña con guiones (XXXX-XXXX-…): se
        # acepta tal cual se ve, sin guiones y en minúsculas también.
        candidates = [secret]
        norm = secret.replace("-", "").replace(" ", "").upper()
        if norm != secret:
            candidates.append(norm)
        for cand in candidates:
            if self._try_unlock(cand):
                return True
        return False

    def _try_unlock(self, secret):
        rows = self.con.execute(
            """SELECT * FROM wraps
               ORDER BY CASE kind WHEN 'master' THEN 0 WHEN 'bootstrap' THEN 1 ELSE 2 END, id"""
        ).fetchall()
        for row in rows:
            kek = _crypto()["scrypt"](secret.encode("utf-8"), row["salt"], 32,
                                      N=row["n"], r=row["r"], p=row["p"])
            c = _crypto()["AES"].new(kek, _crypto()["AES"].MODE_GCM,
                                     nonce=row["nonce"])
            wrapped = row["wrapped"]
            try:
                dek = c.decrypt_and_verify(wrapped[:-16], wrapped[-16:])
            except ValueError:
                continue
            self._dek = bytearray(dek)
            self.mode = row["kind"]
            self.slot_name = row["name"]
            self.slot_id = row["id"] if row["kind"] == "slot" else None
            self.generation += 1
            return True
        return False

    def verify_master(self, secret):
        """True si `secret` desenvuelve la wrap MAESTRA (y solo esa).
        No toca la sesión: sirve para pedir la contraseña actual antes
        de cambiarla (sup5-B1)."""
        if not secret:
            return False
        rows = self.con.execute(
            "SELECT * FROM wraps WHERE kind = 'master'").fetchall()
        if not rows:
            return False
        candidates = [secret]
        norm = secret.replace("-", "").replace(" ", "").upper()
        if norm != secret:
            candidates.append(norm)
        for cand in candidates:
            for row in rows:
                kek = _crypto()["scrypt"](cand.encode("utf-8"), row["salt"],
                                          32, N=row["n"], r=row["r"],
                                          p=row["p"])
                c = _crypto()["AES"].new(kek, _crypto()["AES"].MODE_GCM,
                                         nonce=row["nonce"])
                wrapped = row["wrapped"]
                try:
                    c.decrypt_and_verify(wrapped[:-16], wrapped[-16:])
                    return True
                except ValueError:
                    continue
        return False

    # ---------- gestión (solo con la maestra / instalación) ----------
    def create_master(self, password):
        if self._dek is None:
            return False
        # Guarda simétrica a add_slot/remove_slot (sup2-M2): si YA hay
        # maestra, sustituirla exige sesión de maestra (o de instalación
        # en la creación inicial, cuando aún no existe ninguna).
        if self.has_master() and not self.is_master:
            return False
        salt, n, r, p, nonce, wrapped = _wrap(password, bytes(self._dek))
        self.con.execute("DELETE FROM wraps WHERE kind = 'master'")
        self.con.execute(
            "INSERT INTO wraps (kind, name, salt, n, r, p, nonce, wrapped) VALUES ('master', 'Maestra', ?, ?, ?, ?, ?, ?)",
            (salt, n, r, p, nonce, wrapped))
        # La ranura de instalación muere al nacer la maestra.
        self.con.execute("DELETE FROM wraps WHERE kind = 'bootstrap'")
        self.con.commit()
        self.mode = "master"
        self.slot_name = "Maestra"
        return True

    def add_slot(self, name, pin):
        """Crea una ranura; devuelve su id (o False). El id permite
        sellar los metadatos por ranura y no por nombre (sup5-M4)."""
        if not self.is_master or self._dek is None:
            return False
        salt, n, r, p, nonce, wrapped = _wrap(pin, bytes(self._dek))
        cur = self.con.execute(
            "INSERT INTO wraps (kind, name, salt, n, r, p, nonce, wrapped) VALUES ('slot', ?, ?, ?, ?, ?, ?, ?)",
            (name, salt, n, r, p, nonce, wrapped))
        self.con.commit()
        return cur.lastrowid

    def remove_slot(self, slot_id):
        if not self.is_master:
            return False
        self.con.execute("DELETE FROM wraps WHERE id = ? AND kind = 'slot'", (slot_id,))
        self.con.commit()
        return True

    def list_slots(self):
        return [dict(r) for r in self.con.execute(
            "SELECT id, kind, name FROM wraps WHERE kind = 'slot' ORDER BY id")]

    # ---------- accesos remotos (remote.py) ----------
    # Fontanería para la gestión remota de accesos: la criptografía es
    # la misma de siempre (la DEK solo se usa en memoria; las wraps que
    # viajan son las mismas filas que ya crea add_slot). La política
    # (quién puede crear/revocar/sincronizar) vive en remote.py y en
    # services.py, no aquí.
    def derive_key(self, label):
        """Clave derivada de la DEK en memoria (HMAC-SHA256 con una
        etiqueta de dominio). None si la bóveda está bloqueada. Sirve
        para cifrar/firmar la lista de accesos compartida: solo un
        aparato que puede abrir la bóveda puede derivarla."""
        if self._dek is None:
            return None
        return hmac.new(bytes(self._dek), label.encode("utf-8"),
                        hashlib.sha256).digest()

    def make_wrap(self, secret):
        """Envuelve la DEK con `secret` SIN insertar la fila: devuelve
        los campos de la wrap (bytes) o False si está bloqueada. Es el
        mismo _wrap de add_slot, para accesos que vivirán en otros
        dispositivos (remotos)."""
        if self._dek is None:
            return False
        salt, n, r, p, nonce, wrapped = _wrap(secret, bytes(self._dek))
        return {"salt": salt, "n": n, "r": r, "p": p,
                "nonce": nonce, "wrapped": wrapped}

    def insert_slot_wrap(self, name, salt, n, r, p, nonce, wrapped):
        """Inserta una wrap de ranura ya construida (activación de
        invitado / sincronización remota) y devuelve su id local."""
        cur = self.con.execute(
            "INSERT INTO wraps (kind, name, salt, n, r, p, nonce, wrapped) "
            "VALUES ('slot', ?, ?, ?, ?, ?, ?, ?)",
            (name, salt, n, r, p, nonce, wrapped))
        self.con.commit()
        return cur.lastrowid

    def slot_wrap(self, wrap_id):
        """Campos completos de una wrap de ranura (o None)."""
        row = self.con.execute(
            "SELECT * FROM wraps WHERE id = ? AND kind = 'slot'",
            (wrap_id,)).fetchone()
        return dict(row) if row else None

    def sync_delete_slot(self, wrap_id):
        """Borra UNA wrap de ranura por id (sincronización remota: solo
        ids que remote.py lleva en su mapa; jamás maestra/bootstrap)."""
        self.con.execute(
            "DELETE FROM wraps WHERE id = ? AND kind = 'slot'", (wrap_id,))
        self.con.commit()
        return True

    def install_guest_wrap(self, name, salt, n, r, p, nonce, wrapped):
        """Alta de invitado: instala su wrap de ranura y elimina la de
        instalación (el código de instalación muere también en este
        aparato, como al crear la maestra). Solo en aparatos SIN
        maestra: un administrador nunca se convierte en invitado."""
        if self.has_master():
            return False
        cur = self.con.execute(
            "INSERT INTO wraps (kind, name, salt, n, r, p, nonce, wrapped) "
            "VALUES ('slot', ?, ?, ?, ?, ?, ?, ?)",
            (name, salt, n, r, p, nonce, wrapped))
        self.con.execute("DELETE FROM wraps WHERE kind = 'bootstrap'")
        self.con.commit()
        return cur.lastrowid

    # ---------- estructura (sin desbloquear) ----------
    def seasons(self, tmdb):
        return [dict(r) for r in self.con.execute(
            """SELECT temporada, COUNT(DISTINCT episodio) AS episodios
               FROM links WHERE kind = 'serie' AND tmdb = ?
               GROUP BY temporada ORDER BY temporada""", (tmdb,))]

    def episodes(self, tmdb, temporada):
        return [dict(r) for r in self.con.execute(
            """SELECT DISTINCT episodio FROM links
               WHERE kind = 'serie' AND tmdb = ? AND temporada = ? ORDER BY episodio""",
            (tmdb, temporada))]

    def calidades(self, kind, tmdb):
        k = "pelicula" if kind == "pelicula" else "serie"
        vals = [r[0] for r in self.con.execute(
            "SELECT DISTINCT calidad FROM links WHERE kind = ? AND tmdb = ?", (k, tmdb))]
        vals.sort(key=quality_rank)
        return vals

    # ---------- enlaces (solo desbloqueada; descifrado en memoria) ----------
    def _dec(self, nonce, ct):
        c = _crypto()["AES"].new(bytes(self._dek),
                                 _crypto()["AES"].MODE_GCM, nonce=nonce)
        return c.decrypt_and_verify(ct[:-16], ct[-16:]).decode("utf-8")

    def _links(self, where, params):
        if self._dek is None:
            return []
        rows = []
        for r in self.con.execute(
                "SELECT rowid, calidad, audio, info, nonce, ct FROM links WHERE " + where, params):
            rows.append({"rowid": r["rowid"], "calidad": r["calidad"],
                         "audio": r["audio"], "info": r["info"],
                         "url": self._dec(r["nonce"], r["ct"])})
        rows.sort(key=lambda x: quality_rank(x["calidad"]))
        return rows

    def links_meta(self, kind, tmdb, temporada=None, episodio=None):
        """Estructura de los enlaces SIN descifrar nada (Fase 2, botón
        «Enlaces» de la Ficha): rowid + calidad/audio/info de cada
        enlace, en el mismo orden en que links_peli/links_ep los
        devolverían al reproducir. Las direcciones no salen de aquí."""
        k = "pelicula" if kind == "pelicula" else "serie"
        q = "SELECT rowid, calidad, audio, info FROM links WHERE kind = ? AND tmdb = ?"
        params = [k, tmdb]
        if temporada is not None:
            q += " AND temporada = ?"
            params.append(temporada)
        if episodio is not None:
            q += " AND episodio = ?"
            params.append(episodio)
        rows = [{"rowid": r["rowid"], "calidad": r["calidad"],
                 "audio": r["audio"], "info": r["info"]}
                for r in self.con.execute(q, params)]
        rows.sort(key=lambda x: quality_rank(x["calidad"]))
        return rows

    def links_peli(self, tmdb):
        return self._links("kind = 'pelicula' AND tmdb = ?", (tmdb,))

    def links_ep(self, tmdb, temporada, episodio):
        return self._links(
            "kind = 'serie' AND tmdb = ? AND temporada = ? AND episodio = ?",
            (tmdb, temporada, episodio))
