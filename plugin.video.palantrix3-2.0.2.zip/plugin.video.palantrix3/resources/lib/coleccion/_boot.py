# -*- coding: utf-8 -*-
"""Desbloqueo automatico de la Coleccion (PalAntriX 2.0.0, decision P4:
sin proteccion en esta version). El codigo de instalacion vigente va
ofuscado y partido; se recompone solo en memoria para desenvolver la
boveda. Cuando llegue la capa de proteccion, este modulo desaparece."""
import base64

_PARTS = [
    '==AWLdlTY',
    'd1S2AFO',
]


def bootstrap_secret():
    try:
        return base64.b64decode("".join(_PARTS)[::-1]).decode("utf-8")
    except Exception:
        return ""
