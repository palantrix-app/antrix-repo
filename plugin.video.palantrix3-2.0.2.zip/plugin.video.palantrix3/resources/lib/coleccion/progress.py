# -*- coding: utf-8 -*-
"""Datos del usuario (userdata.db): progreso de visionado y Mi lista.

Vive separado del catálogo para que las actualizaciones de la base
no borren el historial. INSTALACIÓN LIMPIA SIEMPRE (decisión de
Àngel, 2026-11-22, §6): el paquete NO siembra historial ni favoritos
de nadie en ninguna instalación — cada aparato arranca vacío y el
historial y los favoritos de cada persona llegan SOLO de su propio
Trakt al vincularlo y sincronizar.
"""
import os
import sqlite3
from datetime import datetime, timezone

DDL = (
    """CREATE TABLE IF NOT EXISTS vistos_pelis (tmdb INTEGER PRIMARY KEY,
       playcount INTEGER DEFAULT 0, progress REAL, runtime INTEGER, lastPlayed TEXT)""",
    """CREATE TABLE IF NOT EXISTS vistos_episodios (tmdb INTEGER, temporada INTEGER,
       episodio INTEGER, playcount INTEGER DEFAULT 0, progress REAL, runtime INTEGER,
       lastPlayed TEXT, PRIMARY KEY (tmdb, temporada, episodio))""",
    """CREATE TABLE IF NOT EXISTS favoritos (kind TEXT, tmdb INTEGER,
       added TEXT, PRIMARY KEY (kind, tmdb))""",
    # Fase 2: «Quitar de aquí» de la cola Up Next (no borra el historial;
    # la fila vuelve si se reproduce algo del título después del descarte)
    """CREATE TABLE IF NOT EXISTS descartes (kind TEXT, tmdb INTEGER,
       at TEXT, PRIMARY KEY (kind, tmdb))""",
    # Fase 2: búsquedas recientes de la casa
    """CREATE TABLE IF NOT EXISTS busquedas (texto TEXT PRIMARY KEY,
       at TEXT)""",
)

def _now():
    # Milisegundos REALES (sup3-M4): con «.000» fijos, dos guardados en
    # el mismo segundo no cambiaban la huella de Up Next y un descarte
    # podía sobrevivir a una reproducción simultánea.
    n = datetime.now(timezone.utc)
    return n.strftime("%Y-%m-%dT%H:%M:%S.") + "%03dZ" % (n.microsecond // 1000)

class UserData(object):
    def __init__(self, user_path, catalog_path=None):
        # catalog_path se acepta por compatibilidad de firma y NO se
        # usa: ya no hay siembra desde el catálogo (§6, instalación
        # limpia siempre).
        self.con = sqlite3.connect(user_path, check_same_thread=False,
                                   timeout=30)
        for ddl in DDL:
            self.con.execute(ddl)
        self.con.commit()

    def save_movie(self, tmdb, progress_pct, runtime=None, finished=False):
        if finished:
            self.con.execute(
                """INSERT INTO vistos_pelis (tmdb, playcount, progress, runtime, lastPlayed)
                   VALUES (?, 1, 0, ?, ?)
                   ON CONFLICT(tmdb) DO UPDATE SET playcount = playcount + 1,
                       progress = 0, lastPlayed = excluded.lastPlayed""",
                (tmdb, runtime, _now()))
        else:
            self.con.execute(
                """INSERT INTO vistos_pelis (tmdb, playcount, progress, runtime, lastPlayed)
                   VALUES (?, 0, ?, ?, ?)
                   ON CONFLICT(tmdb) DO UPDATE SET progress = excluded.progress,
                       runtime = excluded.runtime, lastPlayed = excluded.lastPlayed""",
                (tmdb, progress_pct, runtime, _now()))
        self.con.commit()

    def save_episode(self, tmdb, temporada, episodio, progress_pct, runtime=None, finished=False):
        if finished:
            self.con.execute(
                """INSERT INTO vistos_episodios (tmdb, temporada, episodio, playcount, progress, runtime, lastPlayed)
                   VALUES (?, ?, ?, 1, 0, ?, ?)
                   ON CONFLICT(tmdb, temporada, episodio) DO UPDATE SET
                       playcount = playcount + 1, progress = 0, lastPlayed = excluded.lastPlayed""",
                (tmdb, temporada, episodio, runtime, _now()))
        else:
            self.con.execute(
                """INSERT INTO vistos_episodios (tmdb, temporada, episodio, playcount, progress, runtime, lastPlayed)
                   VALUES (?, ?, ?, 0, ?, ?, ?)
                   ON CONFLICT(tmdb, temporada, episodio) DO UPDATE SET
                       progress = excluded.progress, runtime = excluded.runtime,
                       lastPlayed = excluded.lastPlayed""",
                (tmdb, temporada, episodio, progress_pct, runtime, _now()))
        self.con.commit()

    def is_fav(self, kind, tmdb):
        return self.con.execute("SELECT 1 FROM favoritos WHERE kind = ? AND tmdb = ?",
                                (kind, tmdb)).fetchone() is not None

    def toggle_fav(self, kind, tmdb):
        if self.is_fav(kind, tmdb):
            self.con.execute("DELETE FROM favoritos WHERE kind = ? AND tmdb = ?", (kind, tmdb))
            self.con.commit()
            return False
        self.con.execute("INSERT OR IGNORE INTO favoritos VALUES (?,?,?)", (kind, tmdb, _now()))
        self.con.commit()
        return True

    # ---------- marcar / desmarcar vistos (Fase 2) ----------
    def unwatch_movie(self, tmdb):
        self.con.execute("DELETE FROM vistos_pelis WHERE tmdb = ?", (tmdb,))
        self.con.commit()

    def unwatch_episode(self, tmdb, temporada, episodio):
        self.con.execute(
            "DELETE FROM vistos_episodios WHERE tmdb = ? AND temporada = ? AND episodio = ?",
            (tmdb, temporada, episodio))
        self.con.commit()

    def unwatch_serie(self, tmdb):
        self.con.execute("DELETE FROM vistos_episodios WHERE tmdb = ?", (tmdb,))
        self.con.commit()

    # ---------- descartes de la cola Up Next (Fase 2) ----------
    def descartar(self, kind, tmdb):
        self.con.execute(
            "INSERT OR REPLACE INTO descartes (kind, tmdb, at) VALUES (?,?,?)",
            (kind, tmdb, _now()))
        self.con.commit()

    # ---------- búsquedas recientes (Fase 2) ----------
    def add_busqueda(self, texto):
        texto = (texto or "").strip()
        if len(texto) < 2:
            return
        self.con.execute(
            "INSERT OR REPLACE INTO busquedas (texto, at) VALUES (?,?)",
            (texto, _now()))
        self.con.commit()

    def busquedas_recientes(self, limit=10):
        return [r[0] for r in self.con.execute(
            "SELECT texto FROM busquedas ORDER BY at DESC LIMIT ?", (limit,))]

    def clear_busquedas(self):
        self.con.execute("DELETE FROM busquedas")
        self.con.commit()

    def favoritos(self, kind=None):
        if kind:
            return [r[0] for r in self.con.execute(
                "SELECT tmdb FROM favoritos WHERE kind = ? ORDER BY added DESC", (kind,))]
        return [(r[0], r[1]) for r in self.con.execute(
            "SELECT kind, tmdb FROM favoritos ORDER BY added DESC")]

    def close(self):
        try:
            self.con.close()
        except Exception:
            pass
