# -*- coding: utf-8 -*-
"""Acceso a datos del catálogo PalAntriX (palantrix.db)."""
import sqlite3

TMDB_IMG = "https://image.tmdb.org/t/p/"

def img(path, size="w500"):
    if not path:
        return ""
    if path.startswith("http"):
        return path
    if path.startswith("/"):
        return TMDB_IMG + size + path
    return path

def quality_rank(calidad):
    c = (calidad or "").upper()
    if "DV" in c:
        return 0
    if "4K" in c or "2160" in c:
        return 1
    if "1080" in c:
        return 2
    if c.startswith("HD") or "720" in c:
        return 3
    if "SD" in c or "480" in c:
        return 4
    return 5

# Cubos de calidad para el filtro «Por calidad»: la bóveda guarda textos
# libres (DV, DV HDR10+, 4K HDR10 (R), 1080p (IMAX)…); se agrupan por prefijo.
CALIDAD_PATTERNS = {
    "DV": ("DV%",),
    "4K": ("4K%", "8K%", "2160%"),
    "1080p": ("1080%",),
    "HD": ("HD", "720%"),
    "SD": ("SD%", "480%"),
}
CALIDAD_ORDEN = ("DV", "4K", "1080p", "HD", "SD")

# Plegado de acentos para el A–Z (sup3-M2): los títulos con inicial
# acentuada (Ávila, Érase…) caen bajo su vocal sin acento; la Ñ se queda
# como letra propia.
LETRA_VARIANTES = {"A": ("Á",), "E": ("É",), "I": ("Í",),
                   "O": ("Ó",), "U": ("Ú", "Ü")}
_LETRA_FOLD = {}
for _base, _vars in LETRA_VARIANTES.items():
    for _v in _vars:
        _LETRA_FOLD[_v] = _base
        _LETRA_FOLD[_v.lower()] = _base

class Catalog(object):
    def __init__(self, path, user_path=None, vault_path=None):
        self.con = sqlite3.connect("file:%s?mode=ro" % path, uri=True,
                                    check_same_thread=False, timeout=30)
        self.con.row_factory = sqlite3.Row
        self.vp = ""
        self.has_vault = False
        # Cachés de sesión: el catálogo no cambia mientras la app está
        # abierta, y varios conteos recorren tablas enteras (recomendadas,
        # calidades de la bóveda, colecciones). Sin caché, abrir un menú
        # costaba decenas de segundos.
        self._spec_count_cache = {}
        self._gen_hist = None
        self._rec_ids = {}
        self._col_counts = None
        self._cal_sets = None       # {kind: {cubo: set(tmdb)}} (sup3-M1)
        self._miembros = None       # {id colección: [tmdb,...]} (Fase 2)
        self._upnext = None         # cola Up Next memorizada (Fase 2)
        self._upnext_ver = None
        self._novedades = None      # tabla novedades del paquete (§2)
        if user_path:
            self.con.execute("ATTACH DATABASE ? AS u", (user_path,))
            self.vp = "u."
        if vault_path:
            # Solo se lee la ESTRUCTURA (qué calidades hay por título);
            # las direcciones jamás salen de la bóveda (SPEC §10).
            try:
                self.con.execute("ATTACH DATABASE ? AS v", (vault_path,))
                self.has_vault = True
            except Exception:
                self.has_vault = False

    def close(self):
        try:
            self.con.close()
        except Exception:
            pass

    # ---------- rejilla (catálogo completo, por lotes) ----------
    def _grid_where(self, table, categoria=None, categorias=None, genero=None,
                    year=None, query=None, letra=None, novedad=False, calidad=None):
        where, args = [], []
        cats = list(categorias or [])
        if categoria:
            cats.append(categoria)
        if cats:
            where.append("categoria IN (%s)" % ",".join("?" * len(cats)))
            args += cats
        if genero:
            where.append("genero LIKE ?"); args.append("%" + genero + "%")
        if year:
            where.append("substr(fecha,1,4) = ?"); args.append(str(year))
        if query:
            where.append("titulo LIKE ?"); args.append("%" + query + "%")
        if letra:
            if letra == "0-9":
                where.append("titulo GLOB '[0-9]*'")
            else:
                # La letra alcanza también sus iniciales acentuadas
                # (sup3-M2): «A» casa «Á…», «U» casa «Ú…» y «Ü…».
                variantes = [letra] + list(LETRA_VARIANTES.get(letra, ()))
                cond = " OR ".join("titulo LIKE ?" for _ in variantes)
                where.append("(%s)" % cond)
                args += [v + "%" for v in variantes]
        if novedad:
            # «Últimos ~90 días» anclados a la fecha más reciente DEL CATÁLOGO
            # (es una foto fija: anclar a «hoy» acabaría vaciando el nodo).
            where.append("fecha IS NOT NULL AND fecha != '' AND "
                         "fecha >= date((SELECT MAX(fecha) FROM %s), '-90 days')" % table)
        if calidad and self.has_vault:
            # El conjunto de tmdb por cubo se materializa UNA vez por
            # sesión (_calidad_sets): la subconsulta sobre v.links en
            # cada página costaba ~4 s en frío (sup3-M1). Los ids son
            # enteros de la propia base: la lista literal es segura.
            kind_en = "pelicula" if table == "pelis" else "serie"
            ids = self._calidad_sets().get(kind_en, {}).get(calidad) or set()
            if ids:
                where.append("tmdb IN (%s)"
                             % ",".join(str(int(i)) for i in sorted(ids)))
            else:
                where.append("1 = 0")
        w = (" WHERE " + " AND ".join(where)) if where else ""
        return w, args

    def grid(self, kind, offset=0, limit=60, categoria=None, genero=None,
             year=None, order="updated", query=None, categorias=None,
             letra=None, novedad=False, calidad=None):
        table = "pelis" if kind == "pelicula" else "series"
        w, args = self._grid_where(table, categoria, categorias, genero, year,
                                   query, letra, novedad, calidad)
        ordmap = {"updated": "updated DESC", "titulo": "titulo ASC",
                  "fecha": "fecha DESC",
                  "rating": "CAST(substr(rating,1,3) AS REAL) DESC",
                  # «Populares» (D2): no hay columna de popularidad en el
                  # catálogo; lo más parecido y honesto es nota + recencia.
                  "populares": "CAST(substr(rating,1,3) AS REAL) DESC, fecha DESC"}
        q = ("SELECT tmdb, titulo, poster, fondo, fecha, rating, genero, categoria FROM %s%s "
             "ORDER BY %s LIMIT ? OFFSET ?" % (table, w, ordmap.get(order, "updated DESC")))
        args += [limit, offset]
        return [dict(r) for r in self.con.execute(q, args)]

    def grid_count(self, kind, categoria=None, genero=None, year=None, query=None,
                   categorias=None, letra=None, novedad=False, calidad=None):
        table = "pelis" if kind == "pelicula" else "series"
        w, args = self._grid_where(table, categoria, categorias, genero, year,
                                   query, letra, novedad, calidad)
        return self.con.execute("SELECT COUNT(*) FROM %s%s" % (table, w), args).fetchone()[0]

    # ---------- especificaciones de rejilla (menús de texto, Fase 1) ----------
    # Una «spec» es un dict con la consulta ya resuelta de un nodo del mapa:
    #   tipo: 'grid' | 'colecciones' | 'coleccion' | 'seguimiento' | 'sin_terminar'
    #   kind: 'pelicula' | 'serie'      (en 'grid')
    #   categorias / genero / year / letra / calidad / novedad: filtros
    #   order: 'updated' | 'fecha' | 'rating' | 'titulo' | 'populares' | 'recomendadas'
    #   coleccion: id de colección      (en 'coleccion')
    # La ventana Sección solo consume spec_rows/spec_count; la lógica fina
    # de hojas (Fase 2) puede refinar sin tocar los menús.
    def spec_count(self, spec):
        if not spec:
            return 0
        tipo = spec.get("tipo", "grid")
        if tipo == "grid":
            key = repr(sorted((k, repr(v)) for k, v in spec.items()))
            if key not in self._spec_count_cache:
                self._spec_count_cache[key] = self._spec_count_grid(spec)
            return self._spec_count_cache[key]
        return self._spec_count_grid(spec)

    def _spec_count_grid(self, spec):
        tipo = spec.get("tipo", "grid")
        if tipo == "novedades":
            return self._novedades_count()
        if tipo == "favoritos":
            return self._favoritos_count()
        if tipo == "ids":
            return len(spec.get("ids") or [])
        if tipo == "colecciones":
            return self.colecciones_count(especiales=bool(spec.get("especiales")))
        if tipo == "coleccion":
            return len(self._miembros_coleccion().get(str(spec.get("coleccion")), []))
        if tipo == "seguimiento":
            return len([r for r in self.up_next(1000) if r.get("kind") == "serie"])
        if tipo == "sin_terminar":
            rows = self.up_next(1000)
            k = spec.get("kind")
            if k:
                rows = [r for r in rows if r.get("kind") == k]
            return len(rows)
        if spec.get("order") == "recomendadas":
            return len(self._recomendadas_ids(spec.get("kind", "pelicula")))
        return self.grid_count(spec.get("kind", "pelicula"),
                               categorias=spec.get("categorias"),
                               genero=spec.get("genero"), year=spec.get("year"),
                               letra=spec.get("letra"), novedad=spec.get("novedad", False),
                               calidad=spec.get("calidad"))

    def spec_rows(self, spec, offset=0, limit=60):
        if not spec:
            return []
        tipo = spec.get("tipo", "grid")
        if tipo == "novedades":
            return self._novedades_rows(offset, limit)
        if tipo == "favoritos":
            return self._favoritos_rows(offset, limit)
        if tipo == "ids":
            return self._ids_rows(spec, offset, limit)
        if tipo == "colecciones":
            rows = self.colecciones(offset, limit,
                                    especiales=bool(spec.get("especiales")))
            for r in rows:
                r["_coleccion"] = True
                r["kind"] = "pelicula"
            return rows
        if tipo == "coleccion":
            rows = self.coleccion(spec.get("coleccion"))
            for r in rows:
                r["kind"] = "pelicula"
            return rows[offset:offset + limit]
        if tipo == "seguimiento":
            rows = [r for r in self.up_next(1000) if r.get("kind") == "serie"]
            return rows[offset:offset + limit]
        if tipo == "sin_terminar":
            rows = self.up_next(1000)
            k = spec.get("kind")
            if k:
                rows = [r for r in rows if r.get("kind") == k]
            return rows[offset:offset + limit]
        if spec.get("order") == "recomendadas":
            return self._recomendadas_rows(spec.get("kind", "pelicula"), offset, limit)
        rows = self.grid(spec.get("kind", "pelicula"), offset=offset, limit=limit,
                         categorias=spec.get("categorias"),
                         genero=spec.get("genero"), year=spec.get("year"),
                         letra=spec.get("letra"), novedad=spec.get("novedad", False),
                         calidad=spec.get("calidad"), order=spec.get("order", "updated"))
        for r in rows:
            r["kind"] = spec.get("kind", "pelicula")
        return rows

    def spec_sample(self, spec, limit=3):
        """Primeras filas con póster/fondo: vista previa de un ítem de menú."""
        if not spec:
            return []
        rows = self.spec_rows(spec, 0, max(limit * 3, 6))
        out = [r for r in rows if r.get("poster") or r.get("fondo")]
        return out[:limit]

    # ---------- novedades (§2: fecha de entrada y marca NUEVO) ----------
    def _novedades_data(self):
        """(títulos nuevos, episodios nuevos, filas) desde la tabla
        `novedades` del catálogo. Los paquetes anteriores a v572 no la
        traen: todo devuelve vacío y nadie se rompe."""
        if self._novedades is None:
            titulos, episodios, filas = set(), set(), []
            try:
                hay = self.con.execute(
                    "SELECT 1 FROM sqlite_master WHERE type='table' "
                    "AND name='novedades'").fetchone()
                if hay:
                    for kind, tmdb, t, e, fecha in self.con.execute(
                            "SELECT kind, tmdb, temporada, episodio, fecha "
                            "FROM novedades"):
                        titulos.add((kind, int(tmdb)))
                        if t is not None and e is not None:
                            episodios.add((int(tmdb), int(t), int(e)))
                        filas.append({"kind": kind, "tmdb": int(tmdb),
                                      "temporada": t, "episodio": e,
                                      "fecha": fecha or ""})
            except Exception:
                pass
            self._novedades = (titulos, episodios, filas)
        return self._novedades

    def es_nuevo(self, kind, tmdb):
        """¿El título tiene entradas recientes en el catálogo? (§2)"""
        if tmdb is None:
            return False
        titulos, _e, _f = self._novedades_data()
        return (kind, int(tmdb)) in titulos

    def episodio_nuevo(self, tmdb, temporada, episodio):
        _t, episodios, _f = self._novedades_data()
        return (int(tmdb), int(temporada), int(episodio)) in episodios

    def _novedades_rows(self, offset=0, limit=60):
        """El apartado «Novedades»: un título por fila, ordenado por la
        fecha de entrada más reciente; la etiqueta dice cuántos
        capítulos nuevos trae (o que el título entero es nuevo)."""
        _t, _e, filas = self._novedades_data()
        agg = {}
        for f in filas:
            key = (f["kind"], f["tmdb"])
            a = agg.setdefault(key, {"fecha": "", "eps": 0})
            a["fecha"] = max(a["fecha"], f["fecha"])
            if f["temporada"] is not None:
                a["eps"] += 1
        orden = sorted(agg.items(),
                       key=lambda kv: kv[1]["fecha"], reverse=True)
        out = []
        for (kind, tmdb), a in orden:
            row = self.detail(kind, tmdb)
            if not row:
                continue
            row["kind"] = kind
            row["nuevo"] = True
            if a["eps"]:
                n = a["eps"]
                row["label2"] = "%d capítulo%s nuevo%s" % (
                    n, "s" if n != 1 else "", "s" if n != 1 else "")
            else:
                row["label2"] = "Nuevo en el catálogo"
            out.append(row)
        return out[offset:offset + limit]

    def _novedades_count(self):
        _t, _e, filas = self._novedades_data()
        return len({(f["kind"], f["tmdb"]) for f in filas})

    # ---------- Mi lista (favoritos del dispositivo, §1 «Más») ----------
    def _favoritos_rows(self, offset=0, limit=60):
        if not self.vp:
            return []
        out = []
        for kind, tmdb in self.con.execute(
                "SELECT kind, tmdb FROM %sfavoritos ORDER BY added DESC"
                % self.vp):
            row = self.detail(kind, tmdb)
            if row:
                row["kind"] = kind
                out.append(row)
        return out[offset:offset + limit]

    def _favoritos_count(self):
        if not self.vp:
            return 0
        return self.con.execute(
            "SELECT COUNT(*) FROM %sfavoritos" % self.vp).fetchone()[0]

    # ---------- lista explícita de ids (p. ej. filmografía de un actor) --
    def _ids_rows(self, spec, offset=0, limit=60):
        ids = [int(i) for i in (spec.get("ids") or [])]
        kind = spec.get("kind", "pelicula")
        if not ids:
            return []
        table = "pelis" if kind == "pelicula" else "series"
        by = {}
        q = ("SELECT tmdb, titulo, poster, fondo, fecha, rating, genero, "
             "categoria FROM %s WHERE tmdb IN (%s)"
             % (table, ",".join("?" * len(ids))))
        for r in self.con.execute(q, ids):
            d = dict(r)
            d["kind"] = kind
            by[d["tmdb"]] = d
        rows = [by[i] for i in ids if i in by]
        return rows[offset:offset + limit]

    # ---------- recomendadas (regla local, MAPA D2/debate) ----------
    def _generos_historial(self):
        """Géneros más frecuentes en lo visto (pelis + episodios)."""
        if self._gen_hist is not None:
            return self._gen_hist
        counts = {}
        if not self.vp:
            self._gen_hist = counts
            return counts
        for tabla, vista in (("pelis", "vistos_pelis"), ("series", "vistos_episodios")):
            q = ("SELECT t.genero FROM %s t JOIN %s%s v ON v.tmdb = t.tmdb"
                 % (tabla, self.vp, vista))
            try:
                for (g,) in self.con.execute(q):
                    for part in (g or "").split("#"):
                        p = part.strip()
                        if p:
                            counts[p] = counts.get(p, 0) + 1
            except Exception:
                pass
        self._gen_hist = counts
        return counts

    def _recomendadas_ids(self, kind):
        """No vistos del tipo, afines a los géneros de la casa y bien notados."""
        if kind in self._rec_ids:
            return self._rec_ids[kind]
        table = "pelis" if kind == "pelicula" else "series"
        vista = "vistos_pelis" if kind == "pelicula" else "vistos_episodios"
        pesos = self._generos_historial()
        q = ("SELECT tmdb, genero, rating FROM %s WHERE tmdb NOT IN "
             "(SELECT tmdb FROM %s%s) AND rating IS NOT NULL AND rating != ''" % (table, self.vp, vista)) \
            if self.vp else \
            ("SELECT tmdb, genero, rating FROM %s WHERE rating IS NOT NULL AND rating != ''" % table)
        cand = []
        for tmdb, genero, rating in self.con.execute(q):
            afin = sum(pesos.get(p.strip(), 0) for p in (genero or "").split("#"))
            try:
                nota = float((rating or "0").split("/")[0].replace(",", "."))
            except Exception:
                nota = 0.0
            cand.append((tmdb, afin, nota))
        cand.sort(key=lambda x: (-x[1], -x[2], x[0]))
        ids = [c[0] for c in cand]
        self._rec_ids[kind] = ids
        return ids

    def _recomendadas_rows(self, kind, offset=0, limit=60):
        ids = self._recomendadas_ids(kind)[offset:offset + limit]
        if not ids:
            return []
        table = "pelis" if kind == "pelicula" else "series"
        by_id = {}
        q = ("SELECT tmdb, titulo, poster, fondo, fecha, rating, genero, categoria FROM %s "
             "WHERE tmdb IN (%s)" % (table, ",".join("?" * len(ids))))
        for r in self.con.execute(q, ids):
            d = dict(r)
            d["kind"] = kind
            by_id[d["tmdb"]] = d
        return [by_id[i] for i in ids if i in by_id]

    # ---------- conteos para menús dinámicos (una sola pasada) ----------
    def _cat_cond(self, categorias):
        if not categorias:
            return "", []
        return (" WHERE categoria IN (%s)" % ",".join("?" * len(categorias)),
                list(categorias))

    def letras_con_conteo(self, kind, categorias=None):
        table = "pelis" if kind == "pelicula" else "series"
        w, args = self._cat_cond(categorias)
        out = {}
        for letra, n in self.con.execute(
                "SELECT UPPER(substr(titulo,1,1)) AS l, COUNT(*) FROM %s%s GROUP BY l" % (table, w), args):
            if letra and letra.isdigit():
                out["0-9"] = out.get("0-9", 0) + n
            elif letra:
                # Iniciales acentuadas plegadas a su vocal (sup3-M2),
                # en coherencia con el filtro de la rejilla.
                clave = _LETRA_FOLD.get(letra, letra)
                out[clave] = out.get(clave, 0) + n
        return out

    def generos_con_conteo(self, kind, categorias=None):
        table = "pelis" if kind == "pelicula" else "series"
        w, args = self._cat_cond(categorias)
        out = {}
        for (g,) in self.con.execute("SELECT genero FROM %s%s" % (table, w), args):
            for part in (g or "").split("#"):
                p = part.strip()
                if p:
                    out[p] = out.get(p, 0) + 1
        return out

    def anos_con_conteo(self, kind, categorias=None):
        table = "pelis" if kind == "pelicula" else "series"
        conds = ["fecha IS NOT NULL", "substr(fecha,1,4) != ''"]
        args = []
        if categorias:
            conds.append("categoria IN (%s)" % ",".join("?" * len(categorias)))
            args += list(categorias)
        return [(y, n) for (y, n) in self.con.execute(
            "SELECT substr(fecha,1,4) AS y, COUNT(*) FROM %s WHERE %s GROUP BY y ORDER BY y DESC"
            % (table, " AND ".join(conds)), args) if y]

    def _calidad_sets(self):
        """{kind: {cubo: set(tmdb)}} desde la estructura de la bóveda.

        Una sola pasada sobre `links` para los dos tipos, memorizada
        por sesión: alimenta tanto los conteos de los menús como el
        filtro «Por calidad» de las rejillas (sup3-M1)."""
        if self._cal_sets is None:
            self._cal_sets = {"pelicula": {}, "serie": {}}
            if self.has_vault:
                for knd, cal, tmdb in self.con.execute(
                        "SELECT kind, calidad, tmdb FROM v.links"):
                    if knd not in self._cal_sets:
                        continue
                    c = (cal or "").strip()
                    for cubo, pats in CALIDAD_PATTERNS.items():
                        for p in pats:
                            hit = c.startswith(p[:-1]) if p.endswith("%") else c == p
                            if hit:
                                self._cal_sets[knd].setdefault(cubo, set()).add(tmdb)
                                break
        return self._cal_sets

    def calidades_con_conteo(self, kind):
        """{cubo: nº de títulos} desde la estructura de la bóveda."""
        sets = self._calidad_sets().get(kind, {})
        return {c: len(s) for c, s in sets.items() if s}

    # ---------- calidades presentes en la bóveda (estructura, sin enlaces) ----------
    def calidades_presentes(self, kind):
        """Cubos de calidad con al menos un título de este tipo en la bóveda."""
        if not self.has_vault:
            return []
        kind_en = "pelicula" if kind == "pelicula" else "serie"
        presentes = set()
        for (cal,) in self.con.execute(
                "SELECT DISTINCT calidad FROM v.links WHERE kind = ?", (kind_en,)):
            c = (cal or "").strip()
            for cubo, pats in CALIDAD_PATTERNS.items():
                for p in pats:
                    if p.endswith("%"):
                        if c.startswith(p[:-1]):
                            presentes.add(cubo)
                    elif c == p:
                        presentes.add(cubo)
        return [c for c in CALIDAD_ORDEN if c in presentes]

    def generos(self, kind):
        table = "pelis" if kind == "pelicula" else "series"
        out = set()
        for (g,) in self.con.execute("SELECT DISTINCT genero FROM %s WHERE genero IS NOT NULL" % table):
            for part in (g or "").split("#"):
                if part.strip():
                    out.add(part.strip())
        return sorted(out)

    def years(self, kind):
        table = "pelis" if kind == "pelicula" else "series"
        return [r[0] for r in self.con.execute(
            "SELECT DISTINCT substr(fecha,1,4) FROM %s WHERE fecha IS NOT NULL AND fecha != '' ORDER BY 1 DESC" % table)]

    # ---------- detalle ----------
    def detail(self, kind, tmdb):
        table = "pelis" if kind == "pelicula" else "series"
        r = self.con.execute("SELECT * FROM %s WHERE tmdb = ?" % table, (tmdb,)).fetchone()
        return dict(r) if r else None

    # Temporadas/episodios/calidades/enlaces viven en la bóveda (vault.py):
    # el catálogo ya no contiene ninguna tabla de enlaces (SPEC §10).

    # ---------- colecciones (Fase 2: pertenencia por tokens) ----------
    # Ojo con la base rescatada: `pelis.coleccion` guarda VARIAS colecciones
    # separadas por «#» (p. ej. «151#LOS80#TREK»). La pertenencia real es
    # por token; la igualdad exacta de la Fase 1 dejaba sagas vacías
    # (la colección 151 de Star Trek daba 0 con igualdad y tiene miembros).
    def _miembros_coleccion(self):
        if self._miembros is None:
            miembros = {}
            for tmdb, col in self.con.execute(
                    """SELECT tmdb, coleccion FROM pelis
                       WHERE coleccion IS NOT NULL AND coleccion != ''"""):
                for tok in str(col).split("#"):
                    tok = tok.strip()
                    if tok:
                        miembros.setdefault(tok, []).append(tmdb)
            self._miembros = miembros
        return self._miembros

    def _coleccion_counts(self):
        """{id de colección: nº de películas} por pertenencia (tokens)."""
        if self._col_counts is None:
            self._col_counts = {cid: len(v)
                                for cid, v in self._miembros_coleccion().items()}
        return self._col_counts

    @staticmethod
    def _es_especial(cid, titulo):
        # Las colecciones temáticas de Palantir («Especial Star Trek»…)
        # tienen id NO numérico o título que empieza por «Especial»; las
        # sagas de verdad son ids numéricos de TMDB.
        return (not str(cid).isdigit()) or (titulo or "").startswith("Especial")

    def coleccion(self, coleccion_id):
        ids = self._miembros_coleccion().get(str(coleccion_id), [])
        if not ids:
            return []
        q = ("""SELECT tmdb, titulo, poster, fondo, fecha, rating, genero, categoria
                FROM pelis WHERE tmdb IN (%s) ORDER BY fecha ASC"""
             % ",".join("?" * len(ids)))
        return [dict(r) for r in self.con.execute(q, ids)]

    def colecciones(self, offset=0, limit=60, especiales=False):
        counts = self._coleccion_counts()
        out = []
        for r in self.con.execute(
                "SELECT id, titulo, poster, fondo, plot FROM colecciones_pelis"):
            d = dict(r)
            n = counts.get(str(d["id"]), 0)
            esp = self._es_especial(d["id"], d["titulo"])
            if especiales:
                if esp and n >= 1:
                    d["num"] = n
                    out.append(d)
            elif not esp and n > 1:
                d["num"] = n
                out.append(d)
        out.sort(key=lambda r: (-r["num"], r["titulo"] or ""))
        return out[offset:offset + limit]

    def colecciones_count(self, especiales=False):
        counts = self._coleccion_counts()
        total = 0
        for r in self.con.execute("SELECT id, titulo FROM colecciones_pelis"):
            n = counts.get(str(r[0]), 0)
            esp = self._es_especial(r[0], r[1])
            if especiales:
                total += 1 if (esp and n >= 1) else 0
            else:
                total += 1 if (not esp and n > 1) else 0
        return total

    def en_seguimiento(self, offset=0, limit=60):
        return [dict(r) for r in self.con.execute(
            """SELECT s.tmdb, s.titulo, s.poster, s.fondo, s.fecha, s.rating, s.genero,
                      MAX(v.lastPlayed) AS ultimo
               FROM series s JOIN %svistos_episodios v ON v.tmdb = s.tmdb
               GROUP BY s.tmdb ORDER BY ultimo DESC LIMIT ? OFFSET ?""" % self.vp,
            (limit, offset))]

    def en_seguimiento_count(self):
        return self.con.execute(
            "SELECT COUNT(DISTINCT tmdb) FROM %svistos_episodios" % self.vp).fetchone()[0]

    # ---------- cola Up Next (Fase 2) ----------
    @staticmethod
    def _norm_ts(s):
        """Normaliza marcas de tiempo a forma comparable: el catálogo usa
        «2026-11-12 17:32:33» y el userdata «2026-11-19T20:12:49.000Z»."""
        if not s:
            return ""
        s = str(s).replace("T", " ").rstrip("Z")
        if "." in s:
            s = s.split(".")[0]
        return s

    @staticmethod
    def _upnext_label(d):
        if d.get("kind") == "serie" and d.get("temporada") is not None:
            base = "T%d E%d" % (d["temporada"], d["episodio"])
            prog = d.get("progress")
            if prog:
                rt = d.get("runtime") or 0
                if rt:
                    # Formato corto con prima (37' = minutos): medido en
                    # banco, «-37 min» aún se truncaba en el rail por el
                    # escalado de fuentes del sistema; la prima cabe.
                    return "%s · -%d'" % (
                        base, int(round(rt * (1 - prog) / 60.0)))
                return "%s · a medias" % base
            if d.get("nuevo"):
                n = d.get("pendientes") or 1
                return "%s · %s" % (base, "1 nuevo" if n == 1 else "%d nuevos" % n)
            n = d.get("pendientes") or 0
            return "%s · quedan %d" % (base, n) if n else base
        prog = d.get("progress")
        rt = d.get("runtime") or 0
        if prog and rt:
            return "quedan %d'" % int(round(rt * (1 - prog) / 60.0))
        if prog:
            return "a medias · %d%%" % int(round(prog * 100))
        return ""

    def _upnext_version(self):
        """Huella barata del userdata: cualquier guardado o descarte la
        cambia y la cola memorizada se recalcula sola."""
        if not self.vp:
            return None
        try:
            a = self.con.execute(
                "SELECT COUNT(*), MAX(lastPlayed) FROM %svistos_episodios" % self.vp).fetchone()
            b = self.con.execute(
                "SELECT COUNT(*), MAX(lastPlayed) FROM %svistos_pelis" % self.vp).fetchone()
            try:
                d = self.con.execute(
                    "SELECT COUNT(*), MAX(at) FROM %sdescartes" % self.vp).fetchone()
            except Exception:
                d = (0, None)
            return (tuple(a), tuple(b), tuple(d))
        except Exception:
            return None

    def up_next(self, limit=40):
        """La cola única «qué me toca ahora» (semántica Up Next + D5):

        1) a medias (episodios y películas), por última reproducción ↓;
        2) siguiente episodio pendiente de las series en curso;
        3) episodio nuevo detectado: hay episodios sin ver más allá del
           último visto y el catálogo se actualizó (updated) después de
           la última vez que se vio la serie.
        Cada fila nombra el episodio concreto y los pendientes, y trae su
        «label2» ya compuesto. Los descartes («Quitar de aquí») excluyen
        el título hasta que se reproduzca algo suyo después del descarte.
        """
        if not self.vp:
            return []
        version = self._upnext_version()
        if self._upnext is not None and version == self._upnext_ver:
            return self._upnext[:limit]
        descartes = {}
        try:
            for k, t, at in self.con.execute(
                    "SELECT kind, tmdb, at FROM %sdescartes" % self.vp):
                descartes[(k, t)] = self._norm_ts(at)
        except Exception:
            pass

        def descartado(kind, tmdb, last_played):
            at = descartes.get((kind, tmdb))
            return bool(at) and at >= self._norm_ts(last_played)

        # Pase por serie: estructura de la bóveda + vistos (pendientes)
        series_info = {}
        if self.has_vault:
            vistos = {}
            for r in self.con.execute(
                    """SELECT tmdb, temporada, episodio, playcount, progress,
                              lastPlayed FROM %svistos_episodios""" % self.vp):
                vistos.setdefault(r[0], []).append(
                    {"temporada": r[1], "episodio": r[2], "playcount": r[3],
                     "progress": r[4], "lastPlayed": r[5]})
            for tmdb, vrows in vistos.items():
                estructura = [(r[0], r[1]) for r in self.con.execute(
                    """SELECT DISTINCT temporada, episodio FROM v.links
                       WHERE kind = 'serie' AND tmdb = ?
                       ORDER BY temporada, episodio""", (tmdb,))]
                if not estructura:
                    continue
                completos, en_curso, ultimo = set(), None, ""
                for vr in vrows:
                    key = (vr["temporada"], vr["episodio"])
                    if (vr["playcount"] or 0) > 0 or (vr["progress"] or 0) >= 97:
                        completos.add(key)
                    elif 1 < (vr["progress"] or 0) < 97:
                        if en_curso is None or (vr["lastPlayed"] or "") > (en_curso[1]["lastPlayed"] or ""):
                            en_curso = (key, vr)
                    if (vr["lastPlayed"] or "") > ultimo:
                        ultimo = vr["lastPlayed"] or ""
                series_info[tmdb] = {"estructura": estructura,
                                     "completos": completos,
                                     "en_curso": en_curso, "ultimo": ultimo}

        def pendientes_de(info, desde):
            est = info["estructura"]
            try:
                i = est.index(desde)
            except ValueError:
                return 0
            return sum(1 for k in est[i:] if k not in info["completos"])

        cat1, cat2, cat3 = [], [], []
        series_en_cat1 = set()
        q1 = """SELECT e.tmdb AS tmdb, s.titulo AS titulo, s.poster AS poster,
                       s.fondo AS fondo, s.plot AS plot, s.fecha AS fecha,
                       s.genero AS genero, s.rating AS rating,
                       s.categoria AS categoria,
                       e.temporada AS temporada, e.episodio AS episodio,
                       e.progress AS progress, e.runtime AS runtime,
                       e.lastPlayed AS lastPlayed, 'serie' AS kind
                FROM %svistos_episodios e JOIN series s ON s.tmdb = e.tmdb
                WHERE IFNULL(e.progress,0) > 1 AND IFNULL(e.progress,0) < 97
                ORDER BY e.lastPlayed DESC""" % self.vp
        for r in self.con.execute(q1):
            d = dict(r)
            if d["tmdb"] in series_en_cat1:
                continue
            if descartado("serie", d["tmdb"], d["lastPlayed"]):
                continue
            series_en_cat1.add(d["tmdb"])
            d["progress"] = (d["progress"] or 0) / 100.0
            info = series_info.get(d["tmdb"])
            d["pendientes"] = (pendientes_de(info, (d["temporada"], d["episodio"]))
                               if info else 0)
            d["nuevo"] = False
            d["label2"] = self._upnext_label(d)
            cat1.append(d)
        q2 = """SELECT p.tmdb AS tmdb, p.titulo AS titulo, p.poster AS poster,
                       p.fondo AS fondo, p.plot AS plot, p.fecha AS fecha,
                       p.genero AS genero, p.rating AS rating,
                       p.categoria AS categoria,
                       NULL AS temporada, NULL AS episodio,
                       p2.progress AS progress, p2.runtime AS runtime,
                       p2.lastPlayed AS lastPlayed, 'pelicula' AS kind
                FROM %svistos_pelis p2 JOIN pelis p ON p.tmdb = p2.tmdb
                WHERE IFNULL(p2.progress,0) > 1 AND IFNULL(p2.progress,0) < 97
                ORDER BY p2.lastPlayed DESC""" % self.vp
        for r in self.con.execute(q2):
            d = dict(r)
            if descartado("pelicula", d["tmdb"], d["lastPlayed"]):
                continue
            d["progress"] = (d["progress"] or 0) / 100.0
            d["pendientes"] = 0
            d["nuevo"] = False
            d["label2"] = self._upnext_label(d)
            cat1.append(d)
        cat1.sort(key=lambda d: d["lastPlayed"] or "", reverse=True)

        for tmdb, info in series_info.items():
            if info["en_curso"] or tmdb in series_en_cat1:
                continue
            if descartado("serie", tmdb, info["ultimo"]):
                continue
            srow = self.con.execute(
                """SELECT titulo, poster, fondo, plot, fecha, genero, rating,
                          categoria, updated FROM series WHERE tmdb = ?""",
                (tmdb,)).fetchone()
            if srow is None:
                continue
            s = dict(srow)
            completos, est = info["completos"], info["estructura"]
            siguiente = None
            if completos:
                tope = max(completos)
                for k in est:
                    if k > tope and k not in completos:
                        siguiente = k
                        break
            if siguiente is None:
                for k in est:
                    if k not in completos:
                        siguiente = k
                        break
            if siguiente is None:
                continue  # serie terminada: no toca nada ahora
            nuevo = bool(s.get("updated")) and \
                self._norm_ts(s["updated"]) > self._norm_ts(info["ultimo"])
            d = {"kind": "serie", "tmdb": tmdb, "titulo": s["titulo"],
                 "poster": s["poster"], "fondo": s["fondo"], "plot": s["plot"],
                 "fecha": s["fecha"], "genero": s["genero"],
                 "rating": s["rating"], "categoria": s["categoria"],
                 "temporada": siguiente[0], "episodio": siguiente[1],
                 "progress": None, "runtime": None,
                 "lastPlayed": info["ultimo"], "nuevo": nuevo,
                 "pendientes": pendientes_de(info, siguiente)}
            d["label2"] = self._upnext_label(d)
            (cat3 if nuevo else cat2).append(d)
        cat2.sort(key=lambda d: d["lastPlayed"] or "", reverse=True)
        cat3.sort(key=lambda d: d["lastPlayed"] or "", reverse=True)
        out = cat1 + cat2 + cat3
        self._upnext = out
        self._upnext_ver = version
        return out[:limit]

    # ---------- relacionados (Ficha-puerta, Fase 2) ----------
    def relacionados(self, kind, tmdb, limit=14):
        """Primero los demás títulos de su misma colección (pelis), después
        mismo género + categoría por nota. Solo títulos del catálogo."""
        row = self.detail(kind, tmdb)
        if not row:
            return []
        table = "pelis" if kind == "pelicula" else "series"
        out, seen = [], {tmdb}
        if kind == "pelicula" and row.get("coleccion"):
            # Solo cuentan como «su saga» las colecciones de verdad: los
            # tokens «Especial …» son etiquetas temáticas de Palantir
            # (San Valentín tiene 2.809 miembros; no es una saga).
            titulos_col = {str(r[0]): r[1] for r in self.con.execute(
                "SELECT id, titulo FROM colecciones_pelis")}
            ids = []
            for tok in str(row["coleccion"]).split("#"):
                tok = tok.strip()
                if tok and not self._es_especial(tok, titulos_col.get(tok)):
                    ids += self._miembros_coleccion().get(tok, [])
            ids = [i for i in dict.fromkeys(ids) if i != tmdb]
            if ids:
                q = ("""SELECT tmdb, titulo, poster, fondo, fecha, rating,
                               genero, categoria FROM pelis
                        WHERE tmdb IN (%s) ORDER BY fecha ASC"""
                     % ",".join("?" * len(ids)))
                for r in self.con.execute(q, ids):
                    d = dict(r)
                    d["kind"] = "pelicula"
                    out.append(d)
                    seen.add(d["tmdb"])
        gens = [p.strip() for p in (row.get("genero") or "").split("#") if p.strip()]
        if gens and len(out) < limit:
            # Hasta 3 géneros del propio título (sup3-M8), no solo el
            # primero: la afinidad se acerca a la de Recomendadas.
            gens3 = gens[:3]
            cond = " OR ".join("genero LIKE ?" for _ in gens3)
            q = ("""SELECT tmdb, titulo, poster, fondo, fecha, rating, genero,
                           categoria FROM %s
                    WHERE (%s) AND categoria IS ?
                    ORDER BY CAST(substr(rating,1,3) AS REAL) DESC LIMIT ?"""
                 % (table, cond))
            try:
                rows = self.con.execute(
                    q, ["%" + g + "%" for g in gens3]
                    + [row.get("categoria"), limit * 2])
            except Exception:
                rows = []
            for r in rows:
                d = dict(r)
                if d["tmdb"] in seen:
                    continue
                d["kind"] = kind
                out.append(d)
                seen.add(d["tmdb"])
                if len(out) >= limit:
                    break
        return out[:limit]

    def vistos_pelis_mapa(self):
        """{tmdb: {progress, playcount}} de películas, para sagas."""
        if not self.vp:
            return {}
        return {r[0]: {"progress": r[1], "playcount": r[2]} for r in self.con.execute(
            "SELECT tmdb, progress, playcount FROM %svistos_pelis" % self.vp)}

    # ---------- vistos (para Detalle) ----------
    def progreso_peli(self, tmdb):
        r = self.con.execute(
            "SELECT progress, playcount FROM %svistos_pelis WHERE tmdb = ?" % self.vp,
            (tmdb,)).fetchone()
        return dict(r) if r else None

    def progreso_ep(self, tmdb, temporada, episodio):
        r = self.con.execute(
            """SELECT progress, playcount FROM %svistos_episodios
               WHERE tmdb = ? AND temporada = ? AND episodio = ?""" % self.vp,
            (tmdb, temporada, episodio)).fetchone()
        return dict(r) if r else None

    def ultimo_visto_ep(self, tmdb):
        r = self.con.execute(
            """SELECT temporada, episodio, progress, playcount FROM %svistos_episodios
               WHERE tmdb = ? ORDER BY lastPlayed DESC LIMIT 1""" % self.vp, (tmdb,)).fetchone()
        return dict(r) if r else None

    def vistos_de_serie(self, tmdb):
        out = {}
        for r in self.con.execute(
                "SELECT temporada, episodio, progress, playcount FROM %svistos_episodios WHERE tmdb = ?" % self.vp,
                (tmdb,)):
            out[(r[0], r[1])] = {"progress": r[2], "playcount": r[3]}
        return out
