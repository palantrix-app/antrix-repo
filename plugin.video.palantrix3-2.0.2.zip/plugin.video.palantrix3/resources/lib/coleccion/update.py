# -*- coding: utf-8 -*-
"""Actualización del catálogo y de la bóveda (Fase 3 · Servicios).

Corrección de seguridad sobre la 0.2.0: la actualización NUNCA sustituye
el fichero `boveda.db` de un dispositivo ya instalado — dentro viven su
contraseña maestra y sus accesos (tabla `wraps`). El paquete nuevo se
mezcla POR FILAS: se abre como fuente y se hace INSERT OR REPLACE de las
tablas de enlaces en la bóveda del dispositivo dentro de una transacción,
sin tocar jamás `wraps`. Si la mezcla falla, se descarta entera y se
sigue con la base anterior. El catálogo (metadatos públicos, sin llaves)
sí se puede sustituir.
"""
import datetime
import hashlib
import json
import os
import shutil
import sqlite3
import zipfile

import xbmc
import xbmcgui

PKG_URL = "https://antrix.pages.dev/palantrix_pkg.json"
BASE_URL = "https://antrix.pages.dev/"

CAT_FILE = "catalogo.db"
VAULT_FILE = "boveda.db"
VER_FILE = "catalog_version.txt"
CHECK_FILE = "catalog_check.txt"


def local_version(profile):
    try:
        with open(os.path.join(profile, VER_FILE)) as f:
            return f.read().strip()
    except Exception:
        return None


def check_stamp(profile):
    """Fecha de la última comprobación de actualizaciones (o None)."""
    try:
        with open(os.path.join(profile, CHECK_FILE)) as f:
            return f.read().strip() or None
    except Exception:
        return None


def stamp_check(profile):
    try:
        with open(os.path.join(profile, CHECK_FILE), "w") as f:
            f.write(datetime.datetime.now().strftime("%d/%m/%Y"))
    except Exception:
        pass


def catalog_info(profile):
    """(versión, total de títulos, fecha de última comprobación)."""
    total = 0
    try:
        con = sqlite3.connect("file:%s?mode=ro" %
                              os.path.join(profile, CAT_FILE), uri=True)
        try:
            total = (con.execute("SELECT COUNT(*) FROM pelis").fetchone()[0]
                     + con.execute("SELECT COUNT(*) FROM series").fetchone()[0])
        finally:
            con.close()
    except Exception:
        pass
    return local_version(profile) or "—", total, check_stamp(profile)


# ---------------------------------------------------------------------------
# Mezcla de la bóveda (la pieza de seguridad de esta fase)
# ---------------------------------------------------------------------------
# Lista blanca de tablas mezclables (sup2-M4): del paquete solo pueden
# entrar los enlaces y los metadatos; cualquier otra tabla se ignora y
# se anota. `wraps` queda fuera por principio: es del dispositivo.
_MERGEABLES = ("links", "meta")


def _meta_val(con, clave):
    try:
        row = con.execute("SELECT v FROM meta WHERE k = ?",
                          (clave,)).fetchone()
    except Exception:
        return None
    return row[0] if row else None


def merge_vault(device_path, source_path):
    """Mezcla la bóveda del paquete (`source_path`) en la del dispositivo
    (`device_path`), sin tocar jamás su tabla `wraps`.

    - `links`: INSERT OR REPLACE por rowid; las filas del dispositivo
      que ya no vienen en el paquete se eliminan (el paquete es una
      foto COMPLETA: run_update se niega a mezclar si el manifiesto no
      lo declara así).
    - `meta`: upsert por clave, sin borrados (las claves propias del
      dispositivo sobreviven).
    Todo en una transacción: o entra entero o no entra nada.

    Huella de DEK (sup3-B1): si la fuente y el dispositivo guardan
    `meta.dek_fp` y difieren, el paquete se cifró con otra DEK y
    mezclarlo dejaría los enlaces indescifrables con las wraps del
    dispositivo: se aborta ANTES de tocar nada. Si el dispositivo aún
    no tiene huella (bóvedas v568) y la fuente sí, la adopta con la
    propia mezcla de `meta`.
    """
    src = sqlite3.connect("file:%s?mode=ro" % source_path, uri=True)
    try:
        src_tables = set(r[0] for r in src.execute(
            "SELECT name FROM sqlite_master WHERE type = 'table'"))
        src_fp = _meta_val(src, "dek_fp") if "meta" in src_tables else None
    finally:
        src.close()
    if "links" not in src_tables:
        raise ValueError("El paquete no trae la tabla de enlaces")
    for nombre in sorted(src_tables - set(_MERGEABLES) - {"wraps",
                                                          "sqlite_sequence"}):
        xbmc.log("PalAntriX update: tabla del paquete ignorada: %s" % nombre,
                 xbmc.LOGWARNING)

    con = sqlite3.connect(device_path, timeout=30)
    try:
        dev_fp = _meta_val(con, "dek_fp")
        if src_fp and dev_fp and src_fp != dev_fp:
            raise ValueError("La huella de la bóveda del paquete no "
                             "corresponde a la de este dispositivo")
        con.execute("ATTACH DATABASE ? AS src", (source_path,))
        device_tables = set(r[0] for r in con.execute(
            "SELECT name FROM sqlite_master WHERE type = 'table'"))
        con.execute("BEGIN IMMEDIATE")
        if "links" in device_tables:
            cols = [r[1] for r in con.execute("PRAGMA table_info(links)")]
            collist = ", ".join('"%s"' % c for c in cols)
            # Mezcla DIFERENCIAL (corrección 0.3.1): solo se escriben
            # las filas nuevas o cambiadas. Reescribir la tabla entera
            # (~594.000 filas) en una transacción generaba un diario de
            # decenas de MB en el dispositivo y podía tumbar la
            # actualización en teles con poco espacio o flash lenta,
            # incluso cuando el paquete no cambia ni un enlace (de
            # v568 a v569 los enlaces son idénticos: solo entra
            # `meta`). El estado final es exactamente el mismo que con
            # la sustitución total: cambiadas y nuevas entran, las que
            # ya no vienen se borran abajo, las idénticas no se tocan.
            iguales = " AND ".join(
                'd."%s" IS s."%s"' % (c, c) for c in cols)
            con.execute(
                'INSERT OR REPLACE INTO main."links" (rowid, %s) '
                'SELECT s.rowid, %s FROM src."links" s '
                'WHERE NOT EXISTS (SELECT 1 FROM main."links" d '
                'WHERE d.rowid = s.rowid AND %s)'
                % (collist, ", ".join('s."%s"' % c for c in cols),
                   iguales))
            con.execute(
                'DELETE FROM main."links" WHERE rowid NOT IN '
                '(SELECT rowid FROM src."links")')
        if "meta" in src_tables and "meta" in device_tables:
            # Por clave y sin borrados: la huella adoptada y cualquier
            # clave propia del dispositivo quedan a salvo.
            con.execute(
                'INSERT OR REPLACE INTO main."meta" (k, v) '
                'SELECT k, v FROM src."meta"')
        con.commit()
    except Exception:
        try:
            con.rollback()
        except Exception:
            pass
        raise
    finally:
        try:
            con.execute("DETACH DATABASE src")
        except Exception:
            pass
        con.close()


def extract_catalog_zip(zip_path, profile):
    """Sustituye `catalogo.db` desde el zip descargado, y SOLO eso
    (sup2-B1): nada de extractall sobre el perfil — si el zip trajera
    alguna vez otra entrada (una `boveda.db` colada por un error de
    empaquetado), jamás tocaría el perfil."""
    tmp = os.path.join(profile, "catalogo.db.tmp")
    try:
        with zipfile.ZipFile(zip_path) as z:
            if CAT_FILE not in z.namelist():
                raise ValueError("El zip del catálogo no trae %s" % CAT_FILE)
            with z.open(CAT_FILE) as src, open(tmp, "wb") as dst:
                shutil.copyfileobj(src, dst)
        os.replace(tmp, os.path.join(profile, CAT_FILE))
    finally:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Flujo completo de actualización (descargar → mezclar → sustituir catálogo)
# ---------------------------------------------------------------------------
def _part_meta(manifest, name):
    """Metadatos de integridad de una parte según el manifiesto:
    {'sha256': ..., 'size': ...} o {} si el manifiesto no los declara."""
    if not manifest:
        return {}
    hashes = manifest.get("hashes") or {}
    return hashes.get(name) or {}


def download_parts(parts, dst, dlg, label, base_pct, span_pct, manifest=None):
    """Descarga las partes (trozos de un mismo fichero) concatenadas en
    `dst`, verificando CADA parte antes de darla por buena (sup3-B1):

    - los bytes recibidos deben igualar el Content-Length de la parte;
    - si el manifiesto declara `size`/`sha256` para la parte, deben
      casar; si no casa, se lanza ValueError y no se toca nada más.

    DECISIÓN (corrección tras la revisión): un manifiesto SIN hashes
    (el v568 actual) se acepta con la sola comprobación de longitud,
    porque es el manifiesto de nuestro propio repo y el camino de
    publicación real debe seguir funcionando para los dispositivos ya
    instalados; en cuanto el manifiesto declare hashes (la publicación
    de la 0.3.0 los traerá), se exigen. La marca de foto completa se
    trata igual: solo un `"complete": false` explícito bloquea la
    mezcla (un paquete delta futuro lo declarará); la huella de DEK de
    `merge_vault` protege además cualquier paquete reconstruido con
    otra llave, declare lo que declare el manifiesto.
    """
    import requests
    with open(dst, "wb") as f:
        for i, name in enumerate(parts):
            meta = _part_meta(manifest, name)
            h = hashlib.sha256()
            done = 0
            with requests.get(BASE_URL + name, stream=True, timeout=60) as r:
                r.raise_for_status()
                total = int(r.headers.get("Content-Length") or 0)
                # Con recodificación (gzip), Content-Length es el tamaño
                # comprimido y NO el del fichero: no es comparable.
                if (r.headers.get("Content-Encoding")
                        or "identity").strip().lower() != "identity":
                    total = 0
                for chunk in r.iter_content(262144):
                    f.write(chunk)
                    h.update(chunk)
                    done += len(chunk)
                    if dlg is not None:
                        if dlg.iscanceled():
                            return False
                        if total:
                            frac = (i + done / float(total)) / len(parts)
                            dlg.update(base_pct + int(frac * span_pct), label)
            if total and done != total:
                raise ValueError("Descarga incompleta de %s" % name)
            if meta.get("size") is not None and done != int(meta["size"]):
                raise ValueError("El tamaño de %s no coincide con el "
                                 "manifiesto" % name)
            if meta.get("sha256") and \
                    h.hexdigest().lower() != str(meta["sha256"]).lower():
                raise ValueError("La huella de %s no coincide con el "
                                 "manifiesto" % name)
    return True


def run_update(profile, dlg=None):
    """Devuelve (código, mensaje): 'current' | 'updated' | 'error' |
    'cancelled'. La comprobación queda fechada aunque no haya novedad."""
    import requests
    try:
        r = requests.get(PKG_URL, timeout=15)
        manifest = json.loads(r.text)
    except Exception:
        return "error", "No se ha podido comprobar (sin conexión)."
    stamp_check(profile)
    remote = str(manifest.get("version") or "")
    if not remote:
        return "error", "El servidor no ha dado una versión válida."
    if remote == local_version(profile):
        return "current", "Ya tienes la base más reciente (v%s)." % remote
    if "complete" in manifest and not manifest.get("complete"):
        # La mezcla asume una foto COMPLETA de la base (borra lo que no
        # viene): un paquete parcial (delta) jamás debe pasar por aquí.
        return "error", ("El paquete disponible no es una base completa; "
                         "no se ha tocado nada.")

    tmp_zip = os.path.join(profile, "catalogo.zip")
    tmp_vault = os.path.join(profile, "boveda_src.tmp")
    try:
        if not download_parts(manifest["catalog"], tmp_zip, dlg,
                              "Actualizando…", 0, 40,
                              manifest=manifest):
            return "cancelled", "Descarga cancelada; no se ha tocado nada."
        if not download_parts(manifest["vault"], tmp_vault, dlg,
                              "Actualizando…", 40, 50,
                              manifest=manifest):
            return "cancelled", "Descarga cancelada; no se ha tocado nada."
        if dlg is not None:
            dlg.update(92, "Actualizando…")
        # Primero la bóveda: si la mezcla falla, no se toca nada más y se
        # sigue con la base anterior al completo.
        try:
            merge_vault(os.path.join(profile, VAULT_FILE), tmp_vault)
        except Exception as e:
            xbmc.log("PalAntriX update: mezcla de bóveda fallida: %s" % e,
                     xbmc.LOGERROR)
            return "error", ("La actualización de los enlaces ha fallado; "
                             "se mantiene tu base anterior, con tu maestra "
                             "y tus accesos intactos.")
        if dlg is not None:
            dlg.update(96, "Actualizando…")
        extract_catalog_zip(tmp_zip, profile)
        with open(os.path.join(profile, VER_FILE), "w") as f:
            f.write(remote)
        return "updated", ("Base actualizada a v%s. Tu maestra y tus "
                           "accesos no se han tocado; el catálogo nuevo se "
                           "aplica por completo al reabrir la app." % remote)
    except Exception as e:
        xbmc.log("PalAntriX update: %s" % e, xbmc.LOGERROR)
        return "error", "La actualización ha fallado; se mantiene la base anterior."
    finally:
        for tmp in (tmp_zip, tmp_vault):
            try:
                if os.path.exists(tmp):
                    os.remove(tmp)
            except Exception:
                pass
