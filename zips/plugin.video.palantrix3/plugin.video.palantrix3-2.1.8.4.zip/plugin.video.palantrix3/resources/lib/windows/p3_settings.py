# -*- coding: utf-8 -*-
"""
	PalAntriX 2.0.0 — Ventana visual de Ajustes con Servicios dentro.

	REGLA DE ORO (aprendida del fallo de la 0.5.2): el estado de cada
	servicio se REEVALÚA en cada onInit — al abrir la ventana y al
	reactivarse tras cerrar un diálogo hijo (vinculación, ajustes
	avanzados) — nunca se cachea de la primera apertura.

	- AllDebrid: estado real (control.setting('alldebrid.token') +
	  AllDebrid.account_info()) y Vincular/Desvincular con
	  AllDebrid().auth() / revoke_auth().
	- Trakt: estado real (modules/trakt.getTraktCredentialsInfo() +
	  trakt.username) y Vincular con el flujo por código del propio
	  módulo (trakt.auth()) / Desvincular (trakt.deauth()).
	- Colección: estado (coleccion_runtime.data_ready(), versión del
	  paquete vía coleccion/update.local_version, total de enlaces
	  si la bóveda abre) y «Actualizar la Colección» forzando la
	  comprobación (update.run_update con DialogProgress
	  «Actualizando…»).
	- «Ajustes avanzados» -> control.openSettings().
"""

import xbmcgui

from resources.lib.modules import control
from resources.lib.modules import coleccion_runtime
from resources.lib.modules import log_utils
from resources.lib.windows.base import BaseDialog
from resources.lib.windows import coleccion_ui

# Controles (ver p3_settings.xml)
LBL_AD_ESTADO = 1301
LBL_AD_DETALLE = 1303
BTN_AD = 1302
LBL_TRAKT_ESTADO = 1311
LBL_TRAKT_DETALLE = 1313
BTN_TRAKT = 1312
LBL_COL_ESTADO = 1321
LBL_COL_DETALLE = 1323
BTN_COL = 1322
BTN_AVANZADOS = 1332
BTN_ACCESOS = 1343
LBL_VERSION = 1341
BTN_NOVEDADES = 1342


class SettingsWindow(BaseDialog):
	"""Ajustes visuales + Servicios, con el estado siempre visible
	y reevaluado al reactivarse la ventana."""

	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, args)
		self._ad_linked = False
		self._trakt_linked = False

	def onInit(self):
		# Sin guarda de «ya iniciado»: onInit ES el punto de
		# reevaluación al volver de cualquier ventana/diálogo hijo.
		coleccion_ui.sidebar_init(self, 'settings')
		self._refresh()

	# ───────────────────────── estado real ─────────────────────────
	def _refresh(self):
		self._refresh_alldebrid()
		self._refresh_trakt()
		self._refresh_coleccion()
		# 2.0.2: sección «Versión» — la versión instalada y el acceso
		# manual a las mejoras («Ver mejoras»). Las novedades NUNCA
		# se abren solas; solo desde este botón.
		try:
			self.getControl(LBL_VERSION).setLabel(
				'PalAntriX %s' % control.addonVersion(
					'plugin.video.palantrix3'))
		except Exception:
			pass
		try:
			self.getControl(coleccion_ui.LBL_STATUS).setLabel(
				coleccion_ui.status_text())
		except Exception:
			pass
		# 2.1.8.4: «Gestionar accesos» solo para administradores. Para
		# el resto, etiqueta vacía Y oculto: un control meramente
		# oculto seguiría devolviendo su texto por Control.GetLabel.
		try:
			from resources.lib.modules import activacion
			es_admin = activacion.is_admin()
			btn = self.getControl(BTN_ACCESOS)
			btn.setLabel('Gestionar accesos' if es_admin else '')
			btn.setVisible(es_admin)
		except Exception:
			pass

	def _refresh_alldebrid(self):
		token = (control.setting('alldebrid.token') or '').strip()
		self._ad_linked = bool(token)
		estado = 'Sin vincular'
		detalle = 'Vincula tu cuenta para reproducir los enlaces.'
		if self._ad_linked:
			estado = 'Vinculado'
			detalle = ''
			try:
				from resources.lib.debrid.alldebrid import AllDebrid
				info = AllDebrid().account_info()
				user = (info or {}).get('user') or {}
				if user:
					estado = 'Premium' if user.get('isPremium') else 'Vinculado (sin Premium)'
					detalle = user.get('username') or ''
			except Exception:
				# La cuenta no responde: se dice tal cual, sin tragarlo.
				detalle = 'Vinculado, pero AllDebrid no ha respondido ahora.'
		try:
			self.getControl(LBL_AD_ESTADO).setLabel(estado)
			self.getControl(LBL_AD_DETALLE).setLabel(detalle)
			self.getControl(BTN_AD).setLabel(
				'Desvincular' if self._ad_linked else 'Vincular')
		except Exception:
			pass

	def _refresh_trakt(self):
		self._trakt_linked = False
		username = ''
		try:
			from resources.lib.modules import trakt
			self._trakt_linked = bool(trakt.getTraktCredentialsInfo())
			username = (control.setting('trakt.username') or '').strip()
		except Exception:
			log_utils.error()
		try:
			self.getControl(LBL_TRAKT_ESTADO).setLabel(
				'Vinculado' if self._trakt_linked else 'Sin vincular')
			self.getControl(LBL_TRAKT_DETALLE).setLabel(
				username if self._trakt_linked else
				'Vincula tu cuenta para sincronizar vistos y tu lista.')
			self.getControl(BTN_TRAKT).setLabel(
				'Desvincular' if self._trakt_linked else 'Vincular')
		except Exception:
			pass

	def _refresh_coleccion(self):
		ready = False
		version = '—'
		detalle = 'Sin datos en este aparato todavía.'
		try:
			ready = coleccion_runtime.data_ready()
			if ready:
				from coleccion import update as col_update
				version = col_update.local_version(
					coleccion_runtime._profile()) or '—'
				detalle = 'Datos %s' % version
				v = coleccion_runtime.get_vault()
				if v is not None:
					try:
						detalle += ' · %s enlaces en la bóveda' % \
							coleccion_ui._fmt_num(v.total_links())
					except Exception:
						pass
				else:
					detalle += ' · la bóveda no se ha podido abrir'
		except Exception:
			log_utils.error()
		try:
			self.getControl(LBL_COL_ESTADO).setLabel(
				'Lista' if ready else 'Sin datos')
			self.getControl(LBL_COL_DETALLE).setLabel(detalle)
		except Exception:
			pass

	# ───────────────────────── acciones ─────────────────────────
	def _update_coleccion(self):
		"""Fuerza la comprobación y mezcla del paquete (como en
		palantrix2: run_update con progreso «Actualizando…»). Si la
		actualización falla y había base, se mantiene la anterior."""
		dlg = xbmcgui.DialogProgress()
		dlg.create('PalAntriX', 'Actualizando…')
		code = 'error'
		try:
			from coleccion import update as col_update
			code, _msg = col_update.run_update(coleccion_runtime._profile(), dlg)
		except Exception:
			log_utils.error()
		finally:
			try:
				dlg.close()
			except Exception:
				pass
		# El paquete puede haber sustituido el catálogo en disco: se
		# sueltan los objetos cacheados del runtime para releerlo.
		try:
			st = coleccion_runtime._state
			if st.get('catalog') is not None:
				try:
					st['catalog'].close()
				except Exception:
					pass
			st['catalog'] = None
			st['vault'] = None
			st['userdata'] = None
			st['ensured'] = None
		except Exception:
			pass
		if code == 'uptodate':
			control.notification(message='La Colección ya está al día.')
		elif code == 'error':
			xbmcgui.Dialog().ok(
				'Colección',
				'La actualización ha fallado. Se mantiene tu base anterior.')
		else:
			control.notification(message='Colección actualizada.')
		self._refresh()

	def onClick(self, control_id):
		if coleccion_ui.sidebar_click(self, control_id, 'settings'):
			return
		if control_id == BTN_AD:
			from resources.lib.debrid.alldebrid import AllDebrid
			if self._ad_linked:
				AllDebrid().revoke_auth()
			else:
				AllDebrid().auth()
			self._refresh()
		elif control_id == BTN_TRAKT:
			from resources.lib.modules import trakt
			if self._trakt_linked:
				trakt.deauth()
			else:
				trakt.auth()
			self._refresh()
		elif control_id == BTN_COL:
			self._update_coleccion()
		elif control_id == BTN_AVANZADOS:
			control.openSettings()
			self._refresh()
		elif control_id == BTN_ACCESOS:
			from resources.lib.modules import activacion
			if not activacion.is_admin():
				return
			from resources.lib.windows import p3_accesos
			p3_accesos.show_accesos()
			self._refresh()
		elif control_id == BTN_NOVEDADES:
			from resources.lib.modules import changelog
			changelog.get('palantrix')
			self._refresh()


def show_settings():
	w = SettingsWindow('p3_settings.xml', coleccion_ui._addon_path(),
					   'Default', '1080i')
	w.doModal()
	del w
