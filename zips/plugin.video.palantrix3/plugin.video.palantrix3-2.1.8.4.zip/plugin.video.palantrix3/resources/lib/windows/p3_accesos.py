# -*- coding: utf-8 -*-
"""
	PalAntriX 2.1.8.4 — Panel de control de accesos (Serveis →
	Gestionar accesos, solo administradores).

	- Crear: UN teclado para el nombre; el código generado ES la
	  clave de la wrap (un solo secreto, sin PIN aparte). El código
	  se muestra UNA vez en la etiqueta 1345, en crudo (20 caracteres,
	  sin guiones: así lo lee el aparato que se activa).
	- Listar: las filas 1370-1377 muestran los accesos del registro
	  del admin (adoptados de la lista de la puerta al abrir).
	- Revocar: clic en la fila → «Revocar acceso» → confirmación
	  (Sí/No) → se publica la lista sin ese acceso y su código deja
	  de valer al momento (la puerta ya no lo sirve).
	- La escritura va firmada con la clave de prueba de admin
	  (X-Admin-Proof); si la puerta la rechaza (403: el admin entró
	  con contraseña maestra y no tiene la clave enlazada), el panel
	  pide el código de administrador UNA vez, enlaza la clave y
	  reintenta la operación. Sin verificación no se escribe nada.
	- Tras crear, NO se muestra ningún diálogo modal: el código queda
	  en la etiqueta 1345 para que se pueda leer (y activar) enseguida.
"""
import xbmc
import xbmcgui

from resources.lib.modules import activacion
from resources.lib.modules import coleccion_runtime
from resources.lib.modules import control
from resources.lib.modules import log_utils
from resources.lib.modules import puerta
from resources.lib.windows.base import BaseDialog
from resources.lib.windows import coleccion_ui

LBL_TITULO = 1343
LBL_CODIGO_TIT = 1344
LBL_CODIGO = 1345
BTN_CREAR = 1350
BTN_REVOCAR = 1351
BTN_CERRAR = 1352
FILAS = (1370, 1371, 1372, 1373, 1374, 1375, 1376, 1377)


class AccesosWindow(BaseDialog):
	"""Panel de control de accesos (solo admin)."""

	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, args)
		self._vault = None
		self._slots = []
		self._sel_rid = None
		self._sel_name = ''

	def onInit(self):
		# Sin guarda de «ya iniciado»: onInit ES el punto de
		# reevaluación al volver de cualquier diálogo hijo.
		if self._vault is None:
			self._vault = coleccion_runtime.get_vault()
			if self._vault is None:
				try:
					v, _mode = activacion.unlock_with_code(
						activacion.get_stored_code())
					self._vault = v
				except Exception:
					log_utils.error()
			if self._vault is None:
				try:
					control.notification(
						message='No se ha podido abrir la bóveda.')
				except Exception:
					pass
				self.close()
				return
		try:
			# Adopta en el registro lo publicado por otros aparatos
			# del admin (tras un reinicio limpio el registro local
			# está vacío y la lista tiene que venir de la puerta).
			puerta.apply_sync(self._vault, coleccion_runtime._profile())
		except Exception:
			log_utils.error()
		self._refresh()

	def _refresh(self):
		"""Repinta las filas desde el registro; no toca el código
		mostrado (1344/1345) ni la selección salvo para resetearla."""
		try:
			self._slots = puerta.registry_slots(
				coleccion_runtime._profile())
		except Exception:
			log_utils.error()
			self._slots = []
		self._sel_rid = None
		self._sel_name = ''
		try:
			self.getControl(BTN_REVOCAR).setVisible(False)
		except Exception:
			pass
		for i, cid in enumerate(FILAS):
			try:
				btn = self.getControl(cid)
				if i < len(self._slots):
					s = self._slots[i]
					estado = 'Activo' if s.get('pendiente') else 'Sin usar'
					btn.setLabel('%s · %s' % (s.get('name') or '?', estado))
					btn.setVisible(True)
				else:
					btn.setLabel('')
					btn.setVisible(False)
			except Exception:
				pass

	def _mostrar_codigo(self, codigo):
		try:
			self.getControl(LBL_CODIGO_TIT).setLabel(
				'Código nuevo — compártelo una sola vez')
			self.getControl(LBL_CODIGO).setLabel(codigo or '')
		except Exception:
			pass

	def _limpiar_codigo(self):
		try:
			self.getControl(LBL_CODIGO_TIT).setLabel('')
			self.getControl(LBL_CODIGO).setLabel('')
		except Exception:
			pass

	def _con_prueba(self, fn):
		"""Ejecuta fn(clave_de_prueba) -> (ok, resultado_o_mensaje).
		Si la puerta rechaza la prueba (403), pide el código de
		administrador UNA vez, enlaza la clave y reintenta una vez."""
		key = activacion.get_proof_key()
		ok, res = fn(key)
		if ok:
			return ok, res
		if isinstance(res, str) and 'prueba no válida' in res:
			code = activacion.pedir_codigo_admin()
			if not code:
				return False, res
			key = activacion.enlazar_prueba_con_codigo(code)
			if not key:
				return False, res
			return fn(key)
		return ok, res

	def _crear(self):
		try:
			kb = xbmc.Keyboard('', 'Nombre del acceso', False)
			kb.doModal()
			if not kb.isConfirmed():
				return
			nombre = (kb.getText() or '').strip()
		except Exception:
			log_utils.error()
			return
		if not nombre:
			return
		vault = self._vault or coleccion_runtime.get_vault()
		if vault is None:
			control.notification(message='No se ha podido abrir la bóveda.')
			return
		profile = coleccion_runtime._profile()

		def _do(key):
			return puerta.create_remote_access(vault, profile, nombre, key)

		ok, info = self._con_prueba(_do)
		if not ok:
			control.notification(
				message='No se pudo crear el acceso: %s' % (info or ''))
			return
		if not (info or {}).get('publicado'):
			control.notification(
				message='Acceso creado, pero la activación no se publicó.')
		self._mostrar_codigo((info or {}).get('codigo') or '')
		self._refresh()

	def _seleccionar(self, control_id):
		idx = FILAS.index(control_id)
		if idx >= len(self._slots):
			return
		s = self._slots[idx]
		self._sel_rid = s.get('rid')
		self._sel_name = s.get('name') or ''
		try:
			self.getControl(BTN_REVOCAR).setVisible(True)
			self.setFocusId(BTN_REVOCAR)
		except Exception:
			pass

	def _revocar(self):
		if not self._sel_rid:
			return
		rid = self._sel_rid
		nombre = self._sel_name
		if not xbmcgui.Dialog().yesno(
				'PalAntriX',
				'¿Revocar el acceso «%s»?\nSu código dejará de funcionar.'
				% nombre):
			return
		vault = self._vault or coleccion_runtime.get_vault()
		if vault is None:
			control.notification(message='No se ha podido abrir la bóveda.')
			return
		profile = coleccion_runtime._profile()

		def _do(key):
			return puerta.revoke_remote(vault, profile, rid, key)

		ok, msg = self._con_prueba(_do)
		if not ok:
			control.notification(
				message='No se pudo revocar: %s' % (msg or ''))
			return
		self._limpiar_codigo()
		self._refresh()
		control.notification(message='Acceso «%s» revocado.' % nombre)

	def onClick(self, control_id):
		if control_id == BTN_CREAR:
			self._crear()
		elif control_id == BTN_REVOCAR:
			self._revocar()
		elif control_id == BTN_CERRAR:
			self.close()
		elif control_id in FILAS:
			self._seleccionar(control_id)


def show_accesos():
	w = AccesosWindow('p3_accesos.xml', coleccion_ui._addon_path(),
	                  'Default', '1080i')
	w.doModal()
	del w
