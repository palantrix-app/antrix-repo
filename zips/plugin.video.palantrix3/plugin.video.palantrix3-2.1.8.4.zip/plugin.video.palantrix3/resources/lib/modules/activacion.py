# -*- coding: utf-8 -*-
"""
	PalAntriX 2.1.8.4 — Capa de activación por código (decisión de Àngel
	27/11: UN código de administrador; con él, panel de control de
	accesos en Serveis para dar o quitar acceso a otros usuarios).

	CORRECCIÓN DE SEGURIDAD (auditoria 27/11): el código de
	instalación antiguo es PÚBLICO por construcción (va ofuscado en
	cada zip publicado y se desxifra en una línea); NUNCA es el
	código admin y NUNCA concede nada. La wrap 'bootstrap' no abre
	la app: si un código abre la bóveda en modo 'bootstrap', la
	activación lo rechaza y vuelve a bloquear la bóveda.

	Modelo vigente:
	- Sin rol guardado (primera apertura), se pide un código.
	- El código se valida contra la propia bóveda (unlock prueba las
	  wraps maestra → instalación → ranura) o contra la puerta
	  (puerta.py: el blob de activación lleva la wrap). El modo que
	  abre dice el rol: 'master' → administrador; 'slot' → usuario;
	  'bootstrap' → NADA (comprometido).
	- El código de administrador es UNO, elegido por el dueño
	  (opción B): su wrap vive en la puerta como activación con
	  role='admin' y se instala como wrap 'master' en el aparato
	  (install_admin_wrap, que borra la wrap de instalación). El
	  valor del código NO está en la app: ADMIN_CODE de abajo es
	  solo el marcador del hueco, a conectar cuando el dueño elija
	  el código nuevo y se re-embolque la bóveda.
	- El rol y el código (ofuscado, nunca en claro) se guardan en
	  ajustes ocultos: en los arranques siguientes la bóveda se
	  reabre en silencio con el código guardado («recordarme»).
	- Un administrador nunca se convierte en invitado
	  (install_guest_wrap lo impide) y en un aparato de usuario no
	  se crea jamás una maestra (create_master borra la wrap de
	  instalación).
	- La revocación se impone en dos sitios: al activar (el blob
	  de un código revocado ya no está en la puerta) y en cada
	  arranque con red (post_unlock_sync: si la ranura propia ya
	  no está en la lista KV, se borra el rol y el código y vuelve
	  la pantalla de activación). Sin red, se mantiene el rol
	  guardado (no se deja tirado al usuario por un fallo de
	  conexión).
	- Si la activación falla, la app abre igual con el catálogo
	  navegable y la bóveda bloqueada; la pantalla vuelve a salir
	  en el próximo arranque. Nunca se deja el aparato bloqueado.
"""

import base64

import xbmc
import xbmcgui

from resources.lib.modules import control
from resources.lib.modules import coleccion_runtime
from resources.lib.modules import log_utils

SETTING_ROLE = 'palantrix.access_role'
SETTING_CODE = 'palantrix.access_code'
SETTING_PROOF = 'palantrix.access_proof'

ROLE_ADMIN = 'admin'
ROLE_USER = 'user'

# PLACEHOLDER del código de administrador (opción B, pendiente):
# el dueño elige el código nuevo y se conecta al re-embolcar la
# bóveda (la wrap 'master' con ese código llega por la puerta como
# activación role='admin'). NO poner aquí ningún código real y
# NUNCA el código de instalación antiguo (comprometido). La app no
# compara contra esta constante: el código se valida por la wrap
# que abre (master) o por el blob de la puerta.
ADMIN_CODE = ''

# Ofuscación del código guardado (NO es cifrado: solo evita dejar el
# código en claro en settings.xml; la protección real es la wrap de
# la bóveda + la lista de la puerta).
_XOR_KEY = b'PalAntriX-acceso-2183'


def obfuscar(code):
	"""Código en claro -> texto guardable."""
	try:
		raw = (code or '').encode('utf-8')
		x = bytes(b ^ _XOR_KEY[i % len(_XOR_KEY)] for i, b in enumerate(raw))
		return base64.urlsafe_b64encode(x).decode('ascii')
	except Exception:
		return ''


def desofuscar(stored):
	"""Texto guardado -> código en claro ('' si no se puede)."""
	try:
		x = base64.urlsafe_b64decode((stored or '').encode('ascii'))
		raw = bytes(b ^ _XOR_KEY[i % len(_XOR_KEY)] for i, b in enumerate(x))
		return raw.decode('utf-8')
	except Exception:
		return ''


def normalizar_codigo(code):
	"""Igual que Vault.unlock: sin guiones ni espacios, en mayúsculas."""
	return (code or '').replace('-', '').replace(' ', '').upper()


def role_for_mode(mode):
	"""El modo de desbloqueo dice el rol ('master' -> administrador;
	'slot' -> usuario). 'bootstrap' NO concede nada: el código de
	instalación antiguo está comprometido."""
	if mode == 'master':
		return ROLE_ADMIN
	if mode == 'slot':
		return ROLE_USER
	return None


# ───────────────────────── estado guardado ─────────────────────────
def get_role():
	try:
		return (control.setting(SETTING_ROLE) or '').strip()
	except Exception:
		return ''


def set_role(role):
	try:
		control.setSetting(SETTING_ROLE, role or '')
	except Exception:
		log_utils.error()


def get_stored_code():
	try:
		return desofuscar(control.setting(SETTING_CODE) or '')
	except Exception:
		return ''


def set_stored_code(code):
	try:
		control.setSetting(SETTING_CODE, obfuscar(code or ''))
	except Exception:
		log_utils.error()


def is_admin():
	return get_role() == ROLE_ADMIN


def clear_activation():
	"""Olvida el rol y el código y bloquea la bóveda en memoria."""
	set_role('')
	set_stored_code('')
	try:
		coleccion_runtime.reset_cache()
	except Exception:
		pass


# ───────────────────────── clave de prueba de admin ─────────────────────────
def get_proof_key():
	"""Clave de prueba (bytes) para firmar las escrituras a la puerta.
	Orden: la guardada (enlazada una vez con el código admin); si no
	hay, se deriva del código guardado cuando el rol es admin (el
	código guardado ES el código admin en ese caso). Un admin por
	contraseña maestra (proyector) no la tiene: el panel le pide el
	código admin una vez para enlazarla (pedir_codigo_admin)."""
	try:
		stored = control.setting(SETTING_PROOF) or ''
		if stored:
			raw = desofuscar(stored)
			if raw:
				return bytes.fromhex(raw)
	except Exception:
		pass
	try:
		if get_role() == ROLE_ADMIN:
			code = get_stored_code()
			if code:
				from resources.lib.modules import puerta
				return puerta.derive_proof_key(code)
	except Exception:
		log_utils.error()
	return None


def set_proof_key(key_bytes):
	"""Guarda la clave de prueba (ofuscada, nunca en claro)."""
	try:
		control.setSetting(SETTING_PROOF,
		                   obfuscar(key_bytes.hex()) if key_bytes else '')
	except Exception:
		log_utils.error()


def pedir_codigo_admin():
	"""Pide el código de administrador para enlazar la clave de
	prueba (caso del admin por contraseña maestra). None si cancela."""
	try:
		kb = xbmc.Keyboard(
			'', 'Introduce el código de administrador', True)
		kb.doModal()
		if not kb.isConfirmed():
			return None
		return normalizar_codigo(kb.getText() or '')
	except Exception:
		log_utils.error()
		return None


def enlazar_prueba_con_codigo(code):
	"""Deriva la clave de prueba del código admin dado y la guarda.
	Devuelve la clave o None."""
	try:
		from resources.lib.modules import puerta
		key = puerta.derive_proof_key(code)
		if key:
			set_proof_key(key)
		return key
	except Exception:
		log_utils.error()
		return None


def _asegurar_setup_admin(code):
	"""Primera activació com a admin: enlaza la clave de prueba y
	la configura en la puerta (POST /api/accesos/setup) si aún no
	lo está. Silencioso: si la puerta es antigua o no hay red, el
	panel lo dirá al publicar; en el próximo arranque se reintenta
	(la llamada es idempotente)."""
	try:
		key = enlazar_prueba_con_codigo(code)
		if key:
			from resources.lib.modules import puerta
			puerta.ensure_admin_setup(key)
	except Exception:
		log_utils.error()


# ───────────────────────── desbloqueo ─────────────────────────
def unlock_with_code(code):
	"""Desbloquea con el código dado. Devuelve (bóveda, modo) o
	(None, None). Si el código abre la bóveda en un modo que no
	concede rol (p. ej. 'bootstrap', comprometido), la bóveda se
	vuelve a BLOQUEAR en el acto: un desbloqueo sin rol no deja
	nunca la bóveda abierta en memoria."""
	try:
		if not coleccion_runtime.data_ready():
			return None, None
		v = coleccion_runtime.unlock_vault(code)
		if v is None:
			return None, None
		if role_for_mode(v.mode) is None:
			try:
				v.lock()
			except Exception:
				pass
			try:
				coleccion_runtime.reset_cache()
			except Exception:
				pass
			return None, None
		return v, v.mode
	except Exception:
		log_utils.error()
		return None, None


def _rol_coherente(role):
	"""¿El rol guardado cuadra con las wraps reales de la bóveda?
	La bóveda manda. Administrador exige wrap 'master' (la
	'bootstrap' no cuenta: comprometida)."""
	try:
		if not coleccion_runtime.data_ready():
			return True
		from coleccion.vault import Vault
		v = Vault(coleccion_runtime.vault_file())
		try:
			if role == ROLE_ADMIN:
				return bool(v.has_master())
			if role == ROLE_USER:
				return len(v.list_slots()) > 0
			return True
		finally:
			try:
				v.close()
			except Exception:
				pass
	except Exception:
		return True


def _tras_desbloqueo(vault, role):
	"""Tras un desbloqueo válido: sincroniza con la puerta (adopta
	accesos en el registro del admin; espeja la lista en el invitado
	y detecta si el acceso propio fue revocado). Devuelve True para
	seguir, False si el acceso fue revocado (hay que olvidar la
	activación y volver a la pantalla)."""
	try:
		from resources.lib.modules import puerta
		estado = puerta.post_unlock_sync(
			vault, coleccion_runtime._profile())
		if estado == 'own_revoked':
			return False
		return True
	except Exception:
		log_utils.error()
		return True


# ───────────────────────── pantalla de activación ─────────────────────────
def _pedir_codigo():
	"""Teclado de Kodi para el código. None si cancela."""
	try:
		kb = xbmc.Keyboard('', 'Introduce el código de activación', True)
		kb.doModal()
		if not kb.isConfirmed():
			return None
		return (kb.getText() or '').strip()
	except Exception:
		log_utils.error()
		return None


def _pantalla_activacion():
	"""Bucle de activación: pide el código hasta que uno abre la
	bóveda o el usuario cancela. Devuelve el rol ('admin'/'user')
	o None (cancelado: la app abre con la bóveda bloqueada y la
	pantalla volverá a salir en el próximo arranque). El fallo NO
	deja ningún diálogo modal abierto: solo un aviso breve y el
	teclado se vuelve a abrir enseguida (el banco teclea el código
	siguiente sin esperas)."""
	while True:
		typed = _pedir_codigo()
		if typed is None:
			return None
		if not typed:
			continue
		codigo = normalizar_codigo(typed)
		# 1) ¿Abre alguna wrap local? (maestra / ranura; la de
		# instalación NO concede rol y se re-bloquea dentro de
		# unlock_with_code).
		v, mode = unlock_with_code(codigo)
		role = role_for_mode(mode)
		if role:
			if _tras_desbloqueo(v, role):
				set_role(role)
				set_stored_code(codigo)
				if role == ROLE_ADMIN:
					_asegurar_setup_admin(codigo)
				return role
			clear_activation()
			continue
		# 2) ¿Es un código de la puerta (aparato limpio: la wrap aún
		# no está aquí)? La puerta decide el rol por el blob
		# (role='admin' instala wrap maestra; si no, de invitado).
		try:
			from resources.lib.modules import puerta
			from coleccion.vault import Vault
			v0 = Vault(coleccion_runtime.vault_file())
			try:
				ok_puerta = puerta.activar_codigo(
					v0, coleccion_runtime._profile(), codigo)
			finally:
				try:
					v0.close()
				except Exception:
					pass
			if ok_puerta:
				v, mode = unlock_with_code(codigo)
				role = role_for_mode(mode)
				if role:
					if _tras_desbloqueo(v, role):
						set_role(role)
						set_stored_code(codigo)
						if role == ROLE_ADMIN:
							_asegurar_setup_admin(codigo)
						return role
					clear_activation()
					continue
		except Exception:
			log_utils.error()
		# 3) Ni local ni puerta: código no válido. Aviso breve y a
		# pedirlo otra vez (sin diálogo modal que bloquee el teclado).
		try:
			control.notification(
				message='Código no válido. Comprueba que lo has escrito bien.')
		except Exception:
			pass


def ensure_activation():
	"""Puerta de entrada: la llama el router antes de abrir la
	Principal. Devuelve el rol ('admin'/'user') o None (sin datos
	que proteger, cancelado, o activación pendiente)."""
	try:
		if not coleccion_runtime.data_ready():
			return None
		role = get_role()
		code = get_stored_code()
		if role in (ROLE_ADMIN, ROLE_USER) and code:
			if _rol_coherente(role):
				v, mode = unlock_with_code(code)
				if v is not None and role_for_mode(mode) == role:
					if _tras_desbloqueo(v, role):
						if role == ROLE_ADMIN:
							_asegurar_setup_admin(code)
						return role
					clear_activation()
		return _pantalla_activacion()
	except Exception:
		log_utils.error()
		return None
