# -*- coding: utf-8 -*-
"""
	PalAntriX 2.0.0 — Apartado «Colección» (base de Palantir rescatada)
	sobre el motor luc.

	Pegamento fino, sin tocar el motor:
	- Descarga/mezcla del paquete de datos (update.py de palantrix2,
	  intacto): catálogo sin enlaces + bóveda cifrada, en el perfil de
	  ESTE addon. La cosecha diaria sigue publicando el mismo paquete.
	- Desbloqueo AUTOMÁTICO de la bóveda al arrancar (decisión P4 de
	  Àngel: en esta versión no hay protección; ni contraseña, ni PIN,
	  ni activación en la UI). El formato de datos, la DEK y el código
	  de instalación no cambian.
	- Reproducción de enlaces de la bóveda con el Player de luc:
	  Vault (descifrado en memoria) -> AllDebrid.unrestrict_link ->
	  Player.play_source. Una sola contabilidad de vistos (Trakt).
	- REGLA DE PREVALENCIA (suya): si un contenido existe en la
	  bóveda, se sirve primero el de la bóveda; luc es el respaldo.
"""

import os
import sys
import threading

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib.modules import control
from resources.lib.modules import log_utils

_ADDON_PATH = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path'))
_LIB_DIR = os.path.join(_ADDON_PATH, 'resources', 'lib')
_COL_DIR = os.path.join(_LIB_DIR, 'coleccion')
for _d in (_LIB_DIR, _COL_DIR):
	if _d not in sys.path:
		sys.path.append(_d)

_state = {'catalog': None, 'vault': None, 'userdata': None, 'ensured': None}

# 2.0.2: la descarga/mezcla del paquete puede correr en segundo plano
# (apertura) y a la vez pedirla la ventana de la Colección: el candado
# serializa ambas llamadas para que nunca haya dos mezclas a la vez.
_ensure_lock = threading.Lock()


def _profile():
	return xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))


def cat_file():
	return os.path.join(_profile(), 'catalogo.db')


def vault_file():
	return os.path.join(_profile(), 'boveda.db')


def user_file():
	return os.path.join(_profile(), 'userdata.db')


def reset_cache():
	"""Suelta catálogo/bóveda/userdata en memoria (tras actualizar el
	paquete, para releer la base nueva al siguiente acceso)."""
	for k in ('catalog', 'vault', 'userdata'):
		obj = _state.get(k)
		if obj is not None:
			try:
				obj.close()
			except Exception:
				pass
		_state[k] = None
	_state['ensured'] = None


def data_ready():
	try:
		return (os.path.getsize(cat_file()) > 1000000
				and os.path.getsize(vault_file()) > 1000000)
	except Exception:
		return False


def ensure_data(show_progress=True):
	with _ensure_lock:
		return _ensure_data_locked(show_progress)


def _ensure_data_locked(show_progress=True):
	"""Descarga/actualiza el paquete si falta o hay versión nueva.
	Devuelve True si hay base utilizable. Si la actualización falla,
	se sigue con la base anterior (y se avisa sin bloquear).

	Flujo = el de palantrix2 (default.py ensure_files), que es el
	correcto: en INSTALACIÓN LIMPIA la bóveda descargada se ADOPTA
	entera (trae la wrap bootstrap; merge_vault jamás toca wraps y
	sobre un fichero vacío no mezclaría nada); con bóveda ya presente
	se mezclan solo los enlaces (merge_vault)."""
	if _state['ensured'] is not None:
		return _state['ensured']
	ok = data_ready()
	dlg = None
	tmp_zip = tmp_vault = None
	try:
		from coleccion import update as col_update
		profile = _profile()
		need = not ok
		remote = ''
		manifest = None
		import json
		import requests
		for _try in range(2 if not ok else 1):
			try:
				r = requests.get(col_update.PKG_URL, timeout=15)
				manifest = json.loads(r.text)
				remote = str(manifest.get('version') or '')
				break
			except Exception:
				manifest = None
				if not ok:
					xbmc.sleep(1500)
		if manifest is None and not ok:
			control.notification(message='Sin conexión: la Colección no se ha podido descargar. Se reintentará al abrir de nuevo.')
		if manifest is not None:
			need = (not ok) or (bool(remote) and remote != col_update.local_version(profile))
			if 'complete' in manifest and not manifest.get('complete'):
				# Paquete parcial: jamás se aplica (la mezcla asume una
				# foto COMPLETA de la base; ver coleccion/update.py).
				# No se toca nada, haya base local o no.
				need = False
		if need and manifest is not None:
			if not os.path.isdir(profile):
				os.makedirs(profile)
			if show_progress:
				dlg = xbmcgui.DialogProgress()
				dlg.create('PalAntriX', 'Actualizando…' if ok else 'Cargando…')
			tmp_zip = os.path.join(profile, 'catalogo.zip')
			tmp_vault = os.path.join(profile, 'boveda.tmp')
			done = False
			# Primero se descargan LAS DOS piezas a temporales; solo
			# cuando ambas están completas se toca la base en disco
			# (primero la bóveda, después el catálogo, como run_update
			# de palantrix2). Si una descarga falla a mitad, la base
			# anterior queda intacta y completa: nunca bases mezcladas.
			if (col_update.download_parts(manifest['catalog'], tmp_zip, dlg,
										  'Actualizando…' if ok else 'Cargando…',
										  0, 40, manifest=manifest)
					and col_update.download_parts(manifest['vault'], tmp_vault, dlg,
												  'Actualizando…' if ok else 'Cargando…',
												  45, 50, manifest=manifest)):
				try:
					if os.path.exists(vault_file()):
						col_update.merge_vault(vault_file(), tmp_vault)
						os.remove(tmp_vault); tmp_vault = None
					else:
						os.rename(tmp_vault, vault_file()); tmp_vault = None
					col_update.extract_catalog_zip(tmp_zip, profile)
					os.remove(tmp_zip); tmp_zip = None
					try:
						col_update.stamp_check(profile)
					except Exception:
						pass
					with open(os.path.join(profile, 'catalog_version.txt'), 'w') as f:
						f.write(remote)
					done = True
				except Exception:
					log_utils.error()
			if not done and ok:
				control.notification(message='No se ha podido actualizar la Colección; sigues con tu base anterior.')
			ok = data_ready()
	except Exception:
		log_utils.error()
	finally:
		try:
			if dlg is not None:
				dlg.close()
		except Exception:
			pass
		for tmp in (tmp_zip, tmp_vault):
			try:
				if tmp and os.path.exists(tmp):
					os.remove(tmp)
			except Exception:
				pass
	_state['ensured'] = ok if ok else None
	return ok


def get_catalog():
	if _state['catalog'] is None:
		from coleccion.db import Catalog
		_state['catalog'] = Catalog(cat_file(), user_path=user_file(),
									vault_path=vault_file())
	return _state['catalog']


def get_userdata():
	if _state['userdata'] is None:
		from coleccion.progress import UserData
		_state['userdata'] = UserData(user_file(), cat_file())
	return _state['userdata']


def unlock_vault(secret):
	"""Desbloquea la bóveda con el secreto dado. Es el ÚNICO sitio
	que desbloquea, y solo lo llama el flujo de activación con el
	código que teclea el usuario (2.1.8.4: fin del desbloqueo
	automático P4). Devuelve la bóveda desbloqueada o None. El modo
	('master' / 'bootstrap' / 'slot') dice el rol que concede ese
	código; lo decide el llamador."""
	if not data_ready():
		return None
	v = _state.get('vault')
	if v is not None and v.unlocked:
		return v
	try:
		from coleccion.vault import Vault
		if v is not None:
			try:
				v.close()
			except Exception:
				pass
		v = Vault(vault_file())
		if v.unlocked or v.unlock(secret):
			_state['vault'] = v
			return v
		try:
			v.close()
		except Exception:
			pass
	except Exception:
		log_utils.error()
	_state['vault'] = None
	return None


def get_vault():
	"""Bóveda desbloqueada (2.1.8.4: SIN desbloqueo automático; la
	abre solo el flujo de activación con el código del usuario).
	None si este aparato aún no se ha activado en esta sesión."""
	v = _state.get('vault')
	if v is not None and v.unlocked:
		return v
	_state['vault'] = None
	return None


def vault_ready():
	return get_vault() is not None


def in_catalog(kind, tmdb):
	"""¿Existe el título en el catálogo? (prevalencia)"""
	try:
		if not tmdb:
			return False
		return get_catalog().detail(kind, int(tmdb)) is not None
	except Exception:
		return False


def has_links(kind, tmdb, season=None, episode=None):
	try:
		v = get_vault()
		if v is None:
			return False
		return len(v.links_meta(kind, int(tmdb), season, episode)) > 0
	except Exception:
		return False


def _audio_tokens(audio):
	import re
	return set(t for t in re.split(r'[^a-z]+', (audio or '').lower()) if t)


def _es_castellano(audio):
	toks = _audio_tokens(audio)
	return 'esp' in toks or 'spa' in toks or 'castellano' in (audio or '').lower()


def _es_latino_solo(audio):
	return 'lat' in _audio_tokens(audio) and not _es_castellano(audio)


def order_chain(links):
	"""Orden de prueba de la cadena de la bóveda (el de palantrix2):
	calidad descendente (quality_rank de db) y castellano primero;
	el latino solo queda fuera de la cadena automática (R2)."""
	from coleccion.db import quality_rank
	pool = [(i, l) for i, l in enumerate(links) if not _es_latino_solo(l.get('audio'))]
	pool.sort(key=lambda p: (quality_rank(p[1].get('calidad')),
							 0 if _es_castellano(p[1].get('audio')) else 1,
							 p[0]))
	return [l for _i, l in pool]


def vault_links(kind, tmdb, season=None, episode=None):
	v = get_vault()
	if v is None:
		return []
	if kind == 'pelicula':
		return v.links_peli(int(tmdb))
	return v.links_ep(int(tmdb), int(season), int(episode))


def build_meta(kind, detail, season=None, episode=None):
	"""Meta al estilo del motor a partir de la fila del catálogo."""
	d = detail or {}
	title = d.get('titulo') or d.get('title') or ''
	_fecha = str(d.get('fecha') or d.get('year') or '')
	meta = {
		'title': title,
		'tvshowtitle': title if kind != 'pelicula' else '',
		'year': _fecha[:4] if len(_fecha) >= 4 and _fecha[:4].isdigit() else _fecha,
		'premiered': d.get('fecha') or '',
		'genre': d.get('genero') or '',
		'plot': d.get('sinopsis') or d.get('plot') or '',
		'poster': d.get('poster') or '',
		'fanart': d.get('fondo') or d.get('fanart') or '',
		'rating': d.get('rating') or '',
		'imdb': str(d.get('imdb') or ''),
		'tmdb': str(d.get('tmdb') or ''),
		'mediatype': 'movie' if kind == 'pelicula' else 'tvshow',
	}
	return meta


def play_vault(kind, tmdb, season=None, episode=None, link_rowid=None):
	"""Reproduce desde la bóveda con el Player de luc.
	Devuelve True si se lanzó la reproducción; False si ningún enlace
	de la bóveda resolvió (el llamador cae entonces a la búsqueda en
	vivo de luc: cadena de respaldo entre mundos)."""
	try:
		v = get_vault()
		if v is None:
			return False
		detail = get_catalog().detail(kind, int(tmdb))
		if detail is None:
			return False
		links = vault_links(kind, tmdb, season, episode)
		if link_rowid is not None:
			links = [l for l in links if l.get('rowid') == link_rowid] or links
		else:
			links = order_chain(links)
		if not links:
			return False
		from resources.lib.debrid.alldebrid import AllDebrid
		from resources.lib.modules import player as luc_player
		ad = AllDebrid()
		meta = build_meta(kind, detail, season, episode)
		title = meta['title']
		year = meta.get('year') or ''
		imdb = detail.get('imdb') or ''
		for link in links:
			try:
				url = ad.unrestrict_link(link.get('url'))
			except Exception:
				url = None
			if not url:
				continue
			# Reproducción lanzada desde una ventana (o prevalencia):
			# el Player de luc solo usa player.play() directo si está
			# la propiedad bingie_direct; sin ella haría setResolvedUrl
			# sobre un handle que ya no espera resolución y no pasaría
			# nada en pantalla. Es el mecanismo del propio motor para
			# sus ventanas (lo limpia él tras usarlo).
			try:
				xbmcgui.Window(10000).setProperty('luc_kodi.bingie_direct', 'true')
			except Exception:
				pass
			luc_player.Player().play_source(
				title, year, season, episode, imdb, str(tmdb), '',
				url, meta)
			return True
		return False
	except Exception:
		log_utils.error()
		return False


def search_catalog(query, limit=30):
	"""Resultados del catálogo para el Buscador (van primero: prevalencia)."""
	out = []
	try:
		cat = get_catalog()
		for kind in ('pelicula', 'serie'):
			for row in cat.grid(kind, limit=limit, query=query, order='titulo'):
				row = dict(row)
				row['kind'] = kind
				out.append(row)
	except Exception:
		log_utils.error()
	return out
