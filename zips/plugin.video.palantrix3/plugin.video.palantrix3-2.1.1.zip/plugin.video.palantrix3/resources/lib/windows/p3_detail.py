# -*- coding: utf-8 -*-
"""
	PalAntriX 2.1.0 — FICHA FUSIONADA (p3_detail), piel negro/azul.

	Notas 1+2 de Àngel (24/11): la ficha y los capítulos son UNA sola
	pantalla. Sin botones Reproducir/Temporadas/Mi lista en series:
	la sinopsis GENERAL de la serie arriba y, aparte, la sinopsis del
	CAPÍTULO enfocado; las temporadas vistas enteras se OCULTAN
	(según Trakt) y el próximo capítulo a ver queda PRESELECCIONADO.
	El «visto» de cada capítulo se marca con la pestaña nueva
	(marca_visto.png, propiedad p3_watched del ítem).
	«Más» guarda lo de siempre + «Mi lista» dentro + «Actores»:
	el reparto pasa a la barra inferior y, al pulsar un actor, su
	filmografía (TMDB combined_credits); pulsar un título de la
	filmografía abre SU ficha encima.
	En películas se queda «Reproducir» (es un solo ítem) + «Más».

	Nota 5: pulsación larga (acción de contexto) sobre un capítulo
	abre el MENÚ DE CAPÍTULO propio (panel 43xx, estilo de la app):
	Reproducir / Enlaces / Marcar visto-no visto. «Enlaces»: los de
	la bóveda para ese capítulo (ventana de Enlaces existente) o, si
	no hay, el selector de fuentes del motor (alterSources).

	Reproducir capítulo/película — PREVALENCIA de la Colección:
	primero bóveda (play_vault); si devuelve False, búsqueda en vivo
	(RunPlugin play_Item bingie=1).
"""

from urllib.parse import quote_plus
from json import dumps as jsdumps
import datetime

from resources.lib.modules import control
from resources.lib.windows.base import BaseDialog

ADDON = 'plugin://plugin.video.palantrix3/'

BTN_PLAY = 4001
BTN_MAS = 4004
MAS_ENLACES = 4101
MAS_VISTO = 4102
MAS_NOVISTO = 4103
MAS_TRAILER = 4104
MAS_LISTA = 4105
MAS_ACTORES = 4106
MAS2_LISTA = 4151
MAS2_VISTO = 4152
MAS2_NOVISTO = 4153
MAS2_ACTORES = 4154
MAS2_TRAILER = 4155
EPM_PLAY = 4301
EPM_ENLACES = 4302
EPM_MARCAR = 4303
EPM_NOVISTO = 4304
BOTTOM_LIST = 6100
SEASON_LIST = 6200

ACTION_CONTEXT_MENU = 117


def normalize_item(raw, kind_hint=None):
	"""Motor dict o fila de catálogo -> dict común de la ficha."""
	raw = raw or {}
	if 'titulo' in raw or 'sinopsis' in raw:
		kind = raw.get('kind') or kind_hint or 'pelicula'
		fecha = str(raw.get('fecha') or '')
		return {
			'title': raw.get('titulo') or '', 'tvshowtitle': raw.get('titulo') or '',
			'year': fecha[:4], 'premiered': fecha,
			'genre': raw.get('genero') or '', 'plot': raw.get('sinopsis') or '',
			'poster': raw.get('poster') or '', 'fanart': raw.get('fondo') or '',
			'rating': raw.get('rating') or '', 'imdb': raw.get('imdb') or '',
			'tmdb': raw.get('tmdb') or '', 'tvdb': raw.get('tvdb') or '',
			'_p3_media': 'tvshow' if kind == 'serie' else 'movie',
			'_p3_kind': kind, '_from_coleccion': True,
		}
	item = dict(raw)
	media = item.get('_p3_media') or item.get('mediatype') or ''
	if media not in ('movie', 'tvshow'):
		media = 'tvshow' if (item.get('tvshowtitle') and not item.get('title')) or kind_hint == 'serie' else 'movie'
	item['_p3_media'] = media
	item['_p3_kind'] = 'serie' if media == 'tvshow' else 'pelicula'
	if media == 'tvshow' and not item.get('title'):
		item['title'] = item.get('tvshowtitle') or ''
	return item


def _meta_line(item):
	parts = []
	if item.get('year'):
		parts.append(str(item['year']))
	parts.append('Serie' if item['_p3_media'] == 'tvshow' else 'Película')
	genre = item.get('genre')
	if genre and str(genre) != 'NA':
		if isinstance(genre, (list, tuple)):
			genre = ' / '.join(genre)
		try:
			from resources.lib.modules import cleangenre
			genre = cleangenre.lang(genre, control.apiLanguage()['trakt'])
		except Exception:
			pass
		parts.append(str(genre))
	try:
		rating = float(item.get('rating') or 0)
		if rating > 0:
			parts.append('★ %.1f' % rating)
	except Exception:
		pass
	return '   •   '.join(parts)


def _in_watchlist(item):
	try:
		from resources.lib.database import traktsync
		table = 'shows_watchlist' if item['_p3_media'] == 'tvshow' else 'movies_watchlist'
		for row in traktsync.fetch_watch_list(table) or []:
			if item.get('imdb') and row.get('imdb') == item['imdb']:
				return True
			if item.get('tmdb') and str(row.get('tmdb')) == str(item['tmdb']):
				return True
	except Exception:
		pass
	return False


# ───────────────── progreso de Trakt y plan de temporadas ─────────────────

def datos_vistos(item):
	"""(vistos, por_temp) desde Trakt watched/shows?extended=progress.
	vistos: set((temporada, episodio)); por_temp: {temp: (aired, completed)}.
	(None, None) si no hay Trakt o la serie no está en su lista."""
	try:
		from resources.lib.modules import trakt as trakt_mod
		if not trakt_mod.getTraktCredentialsInfo():
			return None, None
		shows = trakt_mod.watchedShows() or []
		tmdb = str(item.get('tmdb') or '')
		imdb = item.get('imdb') or ''
		tvdb = str(item.get('tvdb') or '')
		for entry in shows:
			ids = (entry.get('show') or {}).get('ids') or {}
			if not ((tmdb and str(ids.get('tmdb') or '') == tmdb) or
					(imdb and ids.get('imdb') == imdb) or
					(tvdb and str(ids.get('tvdb') or '') == tvdb)):
				continue
			vistos = set()
			por_temp = {}
			for s in entry.get('seasons') or []:
				sn = s.get('number')
				if sn is None or sn == 0:
					continue
				comp = 0
				for e in s.get('episodes') or []:
					if e.get('completed'):
						comp += 1
						vistos.add((sn, e.get('number')))
				por_temp[sn] = (s.get('aired') or 0, comp)
			return vistos, por_temp
	except Exception:
		pass
	return None, None


def plan_temporadas(temporadas, por_temp):
	"""(visibles, temporada_del_siguiente). Una temporada vista entera
	(aired>0 y completed>=aired) se oculta; si TODAS lo están, se deja
	la última. Sin datos de Trakt: todas visibles, sin siguiente."""
	temporadas = list(temporadas or [])
	if por_temp is None:
		return temporadas, None
	visibles = []
	for s in temporadas:
		aired, comp = por_temp.get(s, (0, 0))
		if aired > 0 and comp >= aired:
			continue
		visibles.append(s)
	if not visibles and temporadas:
		visibles = [temporadas[-1]]
	sig = None
	for s in visibles:
		aired, comp = por_temp.get(s, (0, 0))
		if aired == 0 or comp < aired:
			sig = s
			break
	return visibles, sig


def _es_emitido(ep):
	prem = str((ep or {}).get('premiered') or '')[:10]
	if not prem:
		return True
	return prem <= datetime.date.today().isoformat()


def siguiente_en_temporada(eps, temporada, vistos):
	"""Posición en la lista del próximo capítulo a ver de la temporada:
	el primero emitido y no visto; si no hay, el último emitido; si la
	temporada no tiene emitidos, 0."""
	if not eps:
		return 0
	ultimo_emitido = 0
	for idx, ep in enumerate(eps):
		if not _es_emitido(ep):
			continue
		ultimo_emitido = idx
		if vistos is not None and (temporada, ep.get('episode')) not in vistos:
			return idx
		if vistos is None:
			return idx
	return ultimo_emitido


# ───────────────── reparto y filmografía (TMDB) ─────────────────

def _fetch_cast(item):
	"""Reparto con id de persona (TMDB credits); respaldo: el del dict."""
	try:
		tmdb_id = item.get('tmdb')
		if tmdb_id:
			from resources.lib.indexers.tmdb import TMDb, base_link
			t = TMDb()
			kind = 'tv' if item['_p3_media'] == 'tvshow' else 'movie'
			url = '%s%s/%s/credits?api_key=<redacted>' % (
				base_link, kind, tmdb_id, t.API_key, t.lang)
			data = t.get_request(url)
			if isinstance(data, dict):
				out = []
				for p in (data.get('cast') or [])[:18]:
					thumb = ('https://image.tmdb.org/t/p/w185%s' % p['profile_path']) if p.get('profile_path') else ''
					out.append({'name': p.get('name') or '', 'role': p.get('character') or '',
								'thumbnail': thumb, 'id': p.get('id')})
				if out:
					return out
	except Exception:
		pass
	out = []
	for c in (item.get('cast') or item.get('castandrole') or item.get('castandart') or []):
		if isinstance(c, dict) and c.get('name'):
			out.append({'name': c.get('name'), 'role': c.get('role') or c.get('character') or '',
						'thumbnail': c.get('thumbnail') or c.get('thumb') or '', 'id': c.get('id')})
	return out


def _fetch_filmografia(person_id, name=''):
	"""combined_credits de TMDB -> ítems normalizados para show_detail."""
	out = []
	try:
		from resources.lib.indexers.tmdb import TMDb, base_link
		t = TMDb()
		if not person_id and name:
			from urllib.parse import quote
			surl = '%ssearch/person?api_key=<redacted>' % (
				base_link, t.API_key, t.lang, quote(str(name)))
			sdata = t.get_request(surl)
			if isinstance(sdata, dict) and sdata.get('results'):
				person_id = sdata['results'][0].get('id')
		if not person_id:
			return out
		url = '%sperson/%s/combined_credits?api_key=<redacted>' % (
			base_link, person_id, t.API_key, t.lang)
		data = t.get_request(url)
		if not isinstance(data, dict):
			return out
		seen = set()
		cast = sorted(data.get('cast') or [], key=lambda c: -(c.get('popularity') or 0))
		for c in cast:
			media = c.get('media_type')
			if media not in ('movie', 'tv'):
				continue
			key = (media, c.get('id'))
			if key in seen:
				continue
			seen.add(key)
			fecha = c.get('release_date') or c.get('first_air_date') or ''
			out.append({
				'title': c.get('title') or c.get('name') or '',
				'tvshowtitle': c.get('name') or c.get('title') or '',
				'year': fecha[:4], 'premiered': fecha,
				'genre': '', 'plot': c.get('overview') or '',
				'poster': ('https://image.tmdb.org/t/p/w500%s' % c['poster_path']) if c.get('poster_path') else '',
				'fanart': ('https://image.tmdb.org/t/p/w1280%s' % c['backdrop_path']) if c.get('backdrop_path') else '',
				'rating': c.get('vote_average') or '',
				'imdb': '', 'tmdb': str(c.get('id') or ''), 'tvdb': '',
				'_p3_media': 'tvshow' if media == 'tv' else 'movie',
			})
			if len(out) >= 24:
				break
	except Exception:
		pass
	return out


class P3DetailXML(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, args)
		self.item = normalize_item(kwargs.get('item') or {}, kwargs.get('kind_hint'))
		self._inited = False
		self._wl = False
		self._mode = 'episodios' if self.item['_p3_media'] == 'tvshow' else 'nada'
		self._seasons_all = []      # dicts de menus.seasons (sin la 0)
		self._seasons_vis = []      # números visibles
		self._season = None
		self._eps = []              # capítulos de la temporada actual
		self._eps_cache = {}
		self._vistos = None
		self._por_temp = None
		self._cast = []
		self._filmo = []
		self._ep_info_key = None
		self._epmenu_ep = None      # capítulo del menú de capítulo (None = película)

	def onInit(self):
		if self._inited:
			return
		self._inited = True
		i = self.item
		self.setProperty('p3.title', i.get('title') or '')
		self.setProperty('p3.meta_line', _meta_line(i))
		self.setProperty('p3.plot', i.get('plot') or '')
		self.setProperty('p3.poster', i.get('poster') or control.addonPoster())
		fanart = i.get('fanart') or i.get('fanart2') or i.get('fanart3') or control.addonFanart()
		self.setProperty('p3.fanart', fanart)
		self.setProperty('p3.is_series', '1' if i['_p3_media'] == 'tvshow' else '')
		self._wl = _in_watchlist(i)
		self._refresh_watchlist_label()
		try:
			if i['_p3_media'] == 'tvshow':
				self._init_series()
				self.getControl(BOTTOM_LIST).setNavigation(
					self.getControl(SEASON_LIST), self.getControl(BOTTOM_LIST),
					self.getControl(BOTTOM_LIST), self.getControl(BOTTOM_LIST))
				self.getControl(SEASON_LIST).setNavigation(
					self.getControl(BTN_MAS), self.getControl(BOTTOM_LIST),
					self.getControl(SEASON_LIST), self.getControl(SEASON_LIST))
			else:
				self._mode = 'nada'
				self.setProperty('p3.mode', 'nada')
				self.clearProperty('p3.has_bottom')
				self.getControl(BOTTOM_LIST).setNavigation(
					self.getControl(BTN_PLAY), self.getControl(BOTTOM_LIST),
					self.getControl(BOTTOM_LIST), self.getControl(BOTTOM_LIST))
				self.setFocusId(BTN_PLAY)
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def _refresh_watchlist_label(self):
		self.setProperty('p3.watchlist_label', '✓ En mi lista' if self._wl else '+ Mi lista')

	# — series: temporadas + capítulos en la propia ficha —
	def _init_series(self):
		i = self.item
		self._vistos, self._por_temp = datos_vistos(i)
		from resources.lib.menus import seasons as seasons_menu
		art = jsdumps({'poster': i.get('poster', ''), 'fanart': i.get('fanart', ''),
					   'icon': i.get('poster', ''), 'thumb': i.get('poster', ''),
					   'banner': '', 'clearlogo': '', 'clearart': '',
					   'landscape': i.get('fanart', ''), 'tvshow.poster': i.get('poster', '')})
		seasons = seasons_menu.Seasons().get(
			i.get('tvshowtitle') or i.get('title', ''), i.get('year', ''),
			i.get('imdb', ''), i.get('tmdb', ''), i.get('tvdb', ''),
			art, create_directory=False) or []
		self._seasons_all = [s for s in seasons if str(s.get('season')) not in ('0',)]
		nums = []
		for s in self._seasons_all:
			try:
				nums.append(int(s.get('season')))
			except Exception:
				pass
		vis, sig_temp = plan_temporadas(nums, self._por_temp)
		self._seasons_vis = vis
		if not vis:
			self.clearProperty('p3.has_bottom')
			return
		self.setProperty('p3.mode', 'episodios')
		self.setProperty('p3.has_seasons', '1')
		lis = []
		for n in vis:
			li = control.item(label='Temporada %d' % n, offscreen=True)
			lis.append(li)
		ctrl = self.getControl(SEASON_LIST)
		ctrl.reset()
		ctrl.addItems(lis)
		# Temporada inicial: la del siguiente capítulo; sin Trakt, la última.
		start = sig_temp if sig_temp in vis else vis[-1]
		self._season = start
		try:
			ctrl.selectItem(vis.index(start))
		except Exception:
			pass
		self._load_episodes(start, focus_next=True)
		try:
			self.setFocusId(BOTTOM_LIST)
		except Exception:
			pass

	def _season_dict(self, numero):
		for s in self._seasons_all:
			try:
				if int(s.get('season')) == numero:
					return s
			except Exception:
				pass
		return {'season': numero}

	def _load_episodes(self, numero, focus_next=False):
		i = self.item
		self._season = numero
		if numero in self._eps_cache:
			eps = self._eps_cache[numero]
		else:
			from resources.lib.menus import episodes as episodes_menu
			eps = episodes_menu.Episodes().get(
				i.get('tvshowtitle') or i.get('title', ''), i.get('year', ''),
				i.get('imdb', ''), i.get('tmdb', ''), i.get('tvdb', ''),
				jsdumps(self._season_dict(numero)), season=numero,
				create_directory=False) or []
			self._eps_cache[numero] = eps
		self._eps = eps
		self._mode = 'episodios'
		self.setProperty('p3.mode', 'episodios')
		self.setProperty('p3.bottom_title', 'Capítulos · Temporada %d' % numero)
		lis = []
		for e in eps:
			try:
				lbl = 'T%d E%d · %s' % (int(e.get('season') or numero),
										int(e.get('episode') or 0),
										e.get('title') or '')
			except Exception:
				lbl = e.get('title') or ''
			thumb = e.get('thumb') or (e.get('art') or {}).get('thumb') or i.get('fanart') or ''
			li = control.item(label=lbl, offscreen=True)
			li.setArt({'thumb': thumb, 'poster': thumb, 'fanart': i.get('fanart') or ''})
			if self._ep_watched(e):
				li.setProperty('p3_watched', '1')
			lis.append(li)
		ctrl = self.getControl(BOTTOM_LIST)
		ctrl.reset()
		ctrl.addItems(lis)
		if eps:
			self.setProperty('p3.has_bottom', '1')
		else:
			self.clearProperty('p3.has_bottom')
		pos = siguiente_en_temporada(eps, numero, self._vistos) if (focus_next or self._vistos is not None) else 0
		try:
			ctrl.selectItem(pos)
		except Exception:
			pass
		self._ep_info_key = None
		self._sync_ep_info(force=True)

	def _ep_watched(self, ep):
		if self._vistos is not None:
			try:
				return (int(ep.get('season')), int(ep.get('episode'))) in self._vistos
			except Exception:
				return False
		try:
			return int(ep.get('playcount') or 0) > 0
		except Exception:
			return False

	def _sync_ep_info(self, force=False):
		"""Sinopsis del capítulo enfocado (aparte de la general)."""
		try:
			if self._mode != 'episodios' or self.getFocusId() != BOTTOM_LIST:
				return
			pos = self.get_position(BOTTOM_LIST)
			key = (self._season, pos)
			if not force and key == self._ep_info_key:
				return
			self._ep_info_key = key
			if 0 <= pos < len(self._eps):
				e = self._eps[pos]
				try:
					tit = 'T%d E%d · %s' % (int(e.get('season') or self._season or 0),
											int(e.get('episode') or 0), e.get('title') or '')
				except Exception:
					tit = e.get('title') or ''
				if self._ep_watched(e):
					tit += '  ·  ✓ visto'
				self.setProperty('p3.ep_title', tit)
				self.setProperty('p3.ep_plot', e.get('plot') or '')
			else:
				self.setProperty('p3.ep_title', '')
				self.setProperty('p3.ep_plot', '')
		except Exception:
			pass

	# — reparto / filmografía en la barra inferior —
	def _fill_bottom(self, entries, title):
		"""entries: [('cast', person) | ('filmo', item)]"""
		self.setProperty('p3.bottom_title', title)
		lis = []
		for kind, data in entries:
			if kind == 'cast':
				lbl = data.get('name') or ''
				if data.get('role'):
					lbl += '\n' + data['role']
				thumb = data.get('thumbnail') or ''
			else:
				lbl = data.get('title') or ''
				if data.get('year'):
					lbl += ' (%s)' % data['year']
				thumb = data.get('poster') or ''
			li = control.item(label=lbl, offscreen=True)
			li.setArt({'thumb': thumb, 'poster': thumb, 'fanart': self.item.get('fanart') or ''})
			lis.append(li)
		ctrl = self.getControl(BOTTOM_LIST)
		ctrl.reset()
		ctrl.addItems(lis)
		if entries:
			self.setProperty('p3.has_bottom', '1')
		else:
			self.clearProperty('p3.has_bottom')

	def _load_cast_mode(self, focus=False):
		if not self._cast:
			self._cast = _fetch_cast(self.item)
		self._mode = 'reparto'
		self.setProperty('p3.mode', 'reparto')
		self._fill_bottom([('cast', c) for c in self._cast], 'Reparto')
		if focus:
			try:
				self.setFocusId(BOTTOM_LIST)
			except Exception:
				pass

	def _load_filmografia(self, person):
		filmo = _fetch_filmografia(person.get('id'), person.get('name') or '')
		if not filmo:
			control.notification(title=person.get('name', ''), message='Sin filmografía disponible')
			return
		self._filmo = filmo
		self._mode = 'filmografia'
		self.setProperty('p3.mode', 'filmografia')
		self._fill_bottom([('filmo', f) for f in filmo], 'Con %s' % (person.get('name') or ''))
		try:
			self.getControl(BOTTOM_LIST).selectItem(0)
			self.setFocusId(BOTTOM_LIST)
		except Exception:
			pass

	def _volver_de_modos(self):
		"""Atrás dentro de la ficha: filmografía -> reparto -> capítulos."""
		if self._mode == 'filmografia':
			self._load_cast_mode(focus=True)
			return True
		if self._mode == 'reparto' and self.item['_p3_media'] == 'tvshow' and self._seasons_vis:
			self._load_episodes(self._season or self._seasons_vis[-1])
			try:
				self.setFocusId(BOTTOM_LIST)
			except Exception:
				pass
			return True
		if self._mode == 'reparto' and self.item['_p3_media'] != 'tvshow':
			self._mode = 'nada'
			self.setProperty('p3.mode', 'nada')
			self.clearProperty('p3.has_bottom')
			try:
				self.setFocusId(BTN_MAS)
			except Exception:
				pass
			return True
		return False

	# — acciones —
	def onClick(self, controlId):
		if controlId == BTN_PLAY:
			self._play()
		elif controlId == BTN_MAS:
			self._toggle_mas(True)
		elif controlId in (MAS_ENLACES,):
			self._toggle_mas(False)
			self._open_enlaces()
		elif controlId in (MAS_LISTA, MAS2_LISTA):
			self._toggle_mas(False)
			self._toggle_watchlist()
		elif controlId in (MAS_VISTO, MAS2_VISTO):
			self._toggle_mas(False)
			self._set_watched(True)
		elif controlId in (MAS_NOVISTO, MAS2_NOVISTO):
			self._toggle_mas(False)
			self._set_watched(False)
		elif controlId in (MAS_ACTORES, MAS2_ACTORES):
			self._toggle_mas(False)
			self._load_cast_mode(focus=True)
		elif controlId in (MAS_TRAILER, MAS2_TRAILER):
			self._toggle_mas(False)
			self._play_trailer()
		elif controlId == SEASON_LIST:
			pos = self.get_position(SEASON_LIST)
			if 0 <= pos < len(self._seasons_vis):
				self._load_episodes(self._seasons_vis[pos])
				try:
					self.setFocusId(BOTTOM_LIST)
				except Exception:
					pass
		elif controlId == BOTTOM_LIST:
			self._click_bottom()
		elif controlId == EPM_PLAY:
			ep = self._epmenu_ep
			self._toggle_epmenu(False)
			if ep is not None:
				self._play_episode(ep)
			else:
				self._play()
		elif controlId == EPM_ENLACES:
			ep = self._epmenu_ep
			self._toggle_epmenu(False)
			if ep is not None:
				self._enlaces_episode(ep)
			else:
				self._enlaces_movie()
		elif controlId == EPM_MARCAR:
			ep = self._epmenu_ep
			self._toggle_epmenu(False)
			if ep is not None:
				self._toggle_episode_watched(ep)
			else:
				self._set_watched(True)
		elif controlId == EPM_NOVISTO:
			self._toggle_epmenu(False)
			self._set_watched(False)

	def onAction(self, action):
		try:
			aid = action.getId()
			if aid == ACTION_CONTEXT_MENU:
				if not self.getProperty('p3.mas_open') and not self.getProperty('p3.epmenu_open'):
					if self._mode == 'episodios' and self.getFocusId() == BOTTOM_LIST:
						pos = self.get_position(BOTTOM_LIST)
						if 0 <= pos < len(self._eps):
							self._toggle_epmenu(True, self._eps[pos])
							return
					elif self.item['_p3_media'] == 'movie':
						self._toggle_epmenu(True, None)
						return
			if aid in self.closing_actions:
				if self.getProperty('p3.epmenu_open'):
					self._toggle_epmenu(False)
					return
				if self.getProperty('p3.mas_open'):
					self._toggle_mas(False)
					return
				if self._volver_de_modos():
					return
				return self.close()
		except Exception:
			pass
		self._sync_ep_info()

	def _toggle_mas(self, open_it):
		if open_it:
			self.setProperty('p3.mas_open', '1')
			try:
				self.setFocusId(MAS2_LISTA if self.item['_p3_media'] == 'tvshow' else MAS_ENLACES)
			except Exception:
				pass
		else:
			self.clearProperty('p3.mas_open')
			try:
				self.setFocusId(BTN_MAS)
			except Exception:
				pass

	# — menú de capítulo (nota 5) —
	def _toggle_epmenu(self, open_it, ep=None):
		if open_it:
			self._epmenu_ep = ep
			if ep is not None:
				try:
					tit = 'T%d E%d · %s' % (int(ep.get('season') or 0), int(ep.get('episode') or 0), ep.get('title') or '')
				except Exception:
					tit = ep.get('title') or ''
				self.setProperty('p3.epmenu_title', tit)
				self.setProperty('p3.epmenu_label', 'Marcar como no visto' if self._ep_watched(ep) else 'Marcar como visto')
			else:
				self.setProperty('p3.epmenu_title', self.item.get('title') or '')
				self.setProperty('p3.epmenu_label', 'Marcar como visto')
			self.setProperty('p3.epmenu_open', '1')
			try:
				self.setFocusId(EPM_PLAY)
			except Exception:
				pass
		else:
			self.clearProperty('p3.epmenu_open')
			try:
				self.setFocusId(BOTTOM_LIST if self._epmenu_ep is not None else BTN_MAS)
			except Exception:
				pass
			self._epmenu_ep = None

	def _play(self):
		i = self.item
		if i['_p3_media'] == 'tvshow':
			return
		# PREVALENCIA: primero la bóveda de la Colección.
		try:
			if i.get('tmdb'):
				from resources.lib.modules import coleccion_runtime
				if coleccion_runtime.in_catalog('pelicula', i['tmdb']) and \
						coleccion_runtime.has_links('pelicula', i['tmdb']):
					if coleccion_runtime.play_vault('pelicula', i['tmdb']):
						return
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()
		self._play_live_movie(i)

	def _play_live_movie(self, i):
		try:
			cmd = ('RunPlugin(%s?action=play_Item&title=%s&year=%s&imdb=%s&tmdb=%s&meta=%s&bingie=1)'
				   % (ADDON, quote_plus(i.get('title', '')), i.get('year', ''),
					  i.get('imdb', ''), i.get('tmdb', ''), quote_plus(jsdumps(i))))
			control.execute(cmd)
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def _play_episode(self, data):
		i = self.item
		season, episode = data.get('season'), data.get('episode')
		# Prevalencia también por capítulo.
		try:
			if i.get('tmdb'):
				from resources.lib.modules import coleccion_runtime
				if coleccion_runtime.has_links('serie', i['tmdb'], season, episode):
					if coleccion_runtime.play_vault('serie', i['tmdb'], season, episode):
						return
		except Exception:
			pass
		cmd = ('RunPlugin(%s?action=play_Item&title=%s&year=%s&imdb=%s&tmdb=%s&tvdb=%s'
			   '&season=%s&episode=%s&tvshowtitle=%s&premiered=%s&meta=%s&bingie=1)'
			   % (ADDON, quote_plus(data.get('title', '')), i.get('year', ''),
				  i.get('imdb', ''), i.get('tmdb', ''), i.get('tvdb', ''),
				  season, episode, quote_plus(i.get('tvshowtitle') or i.get('title', '')),
				  quote_plus(str(data.get('premiered', '') or '')),
				  quote_plus(jsdumps(data))))
		control.execute(cmd)

	def _open_enlaces(self):
		"""«Más» de películas: ventana de Enlaces de la bóveda."""
		i = self.item
		cmd = ('RunPlugin(%s?action=p3_enlaces&kind=%s&tmdb=%s)'
			   % (ADDON, i['_p3_kind'], i.get('tmdb', '')))
		control.execute(cmd)

	def _enlaces_movie(self):
		i = self.item
		try:
			if i.get('tmdb'):
				from resources.lib.modules import coleccion_runtime
				if coleccion_runtime.has_links('pelicula', i['tmdb']):
					self._open_enlaces()
					return
		except Exception:
			pass
		self._alter_sources_movie()

	def _enlaces_episode(self, ep):
		i = self.item
		season, episode = ep.get('season'), ep.get('episode')
		try:
			if i.get('tmdb'):
				from resources.lib.modules import coleccion_runtime
				if coleccion_runtime.has_links('serie', i['tmdb'], season, episode):
					from resources.lib.windows import coleccion_ui
					coleccion_ui.open_enlaces('serie', int(i['tmdb']), season, episode,
											  titulo='%s · %sx%02d' % (i.get('title', ''), season or 0, episode or 0))
					return
		except Exception:
			pass
		self._alter_sources_episode(ep)

	def _alter_sources_episode(self, ep):
		"""Sin enlaces de bóveda: selector de fuentes del motor."""
		i = self.item
		url = ('%s?action=play_Item&title=%s&year=%s&imdb=%s&tmdb=%s&tvdb=%s&season=%s&episode=%s'
			   '&tvshowtitle=%s&premiered=%s&meta=%s'
			   % (ADDON, quote_plus(ep.get('title', '')), i.get('year', ''),
				  i.get('imdb', ''), i.get('tmdb', ''), i.get('tvdb', ''),
				  ep.get('season'), ep.get('episode'),
				  quote_plus(i.get('tvshowtitle') or i.get('title', '')),
				  quote_plus(str(ep.get('premiered', '') or '')), quote_plus(jsdumps(ep))))
		control.execute('RunPlugin(%s?action=alterSources&url=%s&meta=%s)'
						% (ADDON, quote_plus(url), quote_plus(jsdumps(ep))))

	def _alter_sources_movie(self):
		i = self.item
		url = ('%s?action=play_Item&title=%s&year=%s&imdb=%s&tmdb=%s&meta=%s'
			   % (ADDON, quote_plus(i.get('title', '')), i.get('year', ''),
				  i.get('imdb', ''), i.get('tmdb', ''), quote_plus(jsdumps(i))))
		control.execute('RunPlugin(%s?action=alterSources&url=%s&meta=%s)'
						% (ADDON, quote_plus(url), quote_plus(jsdumps(i))))

	def _toggle_episode_watched(self, ep):
		i = self.item
		try:
			from resources.lib.modules import playcount
			watched = not self._ep_watched(ep)
			playcount.episodes(i.get('tvshowtitle') or i.get('title', ''),
							   i.get('imdb', ''), i.get('tvdb', ''),
							   ep.get('season'), ep.get('episode'), 5 if watched else 4)
			if self._vistos is not None:
				key = (int(ep.get('season')), int(ep.get('episode')))
				if watched:
					self._vistos.add(key)
				else:
					self._vistos.discard(key)
			pos = self.get_position(BOTTOM_LIST)
			try:
				li = self.getControl(BOTTOM_LIST).getListItem(pos)
				li.setProperty('p3_watched', '1' if watched else '')
			except Exception:
				pass
			self._ep_info_key = None
			self._sync_ep_info(force=True)
			control.notification(title=i.get('title', ''),
								 message='Capítulo marcado como visto' if watched else 'Capítulo marcado como no visto')
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def _set_watched(self, watched):
		i = self.item
		try:
			from resources.lib.modules import playcount
			name = i.get('title', '')
			if i['_p3_media'] == 'tvshow':
				playcount.tvshows(name, i.get('imdb', ''), i.get('tvdb', ''), None, 5 if watched else 4)
			else:
				playcount.movies(name, i.get('imdb', ''), 5 if watched else 4)
			control.notification(title=name, message='Marcado como visto' if watched else 'Marcado como no visto')
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def _play_trailer(self):
		i = self.item
		try:
			typ = 'tv' if i['_p3_media'] == 'tvshow' else 'movie'
			name = '%s (%s)' % (i.get('title', ''), i.get('year', '')) if i.get('year') else i.get('title', '')
			cmd = ('PlayMedia(%s?action=play_Trailer&type=%s&name=%s&year=%s&imdb=%s&tmdb=%s)'
				   % (ADDON, typ, quote_plus(name), i.get('year', ''),
					  i.get('imdb', ''), i.get('tmdb', '')))
			control.execute(cmd)
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def _toggle_watchlist(self):
		i = self.item
		try:
			from resources.lib.modules import trakt as trakt_mod
			if i['_p3_media'] == 'tvshow':
				post_ids = {'tvdb': i.get('tvdb', '')} if i.get('tvdb') else {'tmdb': i.get('tmdb', '')}
				post = {'shows': [{'ids': post_ids}]}
				typ = 'shows'
			else:
				post_ids = {'imdb': i.get('imdb', '')} if i.get('imdb') else {'tmdb': i.get('tmdb', '')}
				post = {'movies': [{'ids': post_ids}]}
				typ = 'movies'
			if self._wl:
				trakt_mod.getTrakt('/sync/watchlist/remove', post=post)
			else:
				trakt_mod.getTrakt('/sync/watchlist', post=post)
			try:
				trakt_mod.sync_watch_list(forced=True)
			except Exception:
				pass
			self._wl = not self._wl
			self._refresh_watchlist_label()
			control.notification(title=i.get('title', ''),
								 message='Quitado de Mi lista' if not self._wl else 'Añadido a Mi lista')
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def _click_bottom(self):
		try:
			pos = self.get_position(BOTTOM_LIST)
			if self._mode == 'episodios':
				if 0 <= pos < len(self._eps):
					self._play_episode(self._eps[pos])
			elif self._mode == 'reparto':
				if 0 <= pos < len(self._cast):
					person = self._cast[pos]
					if person.get('id'):
						self._load_filmografia(person)
					else:
						control.notification(title=person.get('name', ''), message='Sin filmografía disponible')
			elif self._mode == 'filmografia':
				if 0 <= pos < len(self._filmo):
					show_detail(self._filmo[pos])
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def run(self):
		self.doModal()
		self.clearProperties()
		return None


def show_detail(item, kind_hint=None):
	window = P3DetailXML('p3_detail.xml', control.addonPath(control.addonId()),
						 item=item, kind_hint=kind_hint)
	window.run()
	del window
