# -*- coding: utf-8 -*-
"""
	PalAntriX 2.0.0 — PIEL EN VIVO (ventanas propias negro/azul).

	P3HomeXML: Principal / Películas / Series / Más sobre la mecánica de
	BingieSectionHomeXML (filas horizontales 6000+, héroe que se refresca
	con el foco, paginación con tarjeta «Página siguiente»), con la piel
	nueva: barra lateral fija, héroe a la derecha y clic en un póster que
	abre la FICHA (p3_detail) en vez de reproducir directo.

	Regla de oro (PLAN §3.2): la línea de estado de la barra lateral
	(AllDebrid · Trakt · Colección) se REEVALÚA en cada onInit, también
	cuando la ventana recupera el foco; nunca se cachea de la primera
	apertura.

	El motor no se toca: los datos vienen de los fetchers del launcher
	bingie (Movies().get/getTMDb, TVshows().get/getTMDb) y de traktsync
	para «Seguimiento» (patrón _load_items de palantrix_home.py).
"""

from json import dumps as jsdumps
from urllib.parse import quote_plus, unquote_plus

from resources.lib.modules import control
from resources.lib.windows.bingie_section_home import BingieSectionHomeXML, ROW_BASE_ID, MAX_ROWS

ADDON = 'plugin://plugin.video.palantrix3/'

# 2.0.6 — marca de «capítulos sin ver» en Seguimiento: la ESQUINITA
# AZUL DOBLADA en la esquina superior derecha del póster (decisión
# de Àngel, 24/11; sustituye al punto provisional). 2.1.4 (26/11):
# la esquinita se RETIRA — la pastilla NUEVO del skin (antes solo
# luc_new) cubre también p3_sinver, y la barra azul (luc_progress)
# y el disco con tick (luc_watched) son las otras dos marcas de
# la miniatura. Una pieza:
#   · SINVER_PROP: propiedad del ListItem que enciende la marca
#     (la pastilla NUEVO de p3_home.xml cuando vale '1').
SINVER_PROP = 'p3_sinver'

# Barra lateral: (id de control, etiqueta, acción p3_*, clave de sección)
# 2.0.6 (petición de Àngel): fuera «Colección» y «Mi lista» de la
# Principal — la Colección vive ahora DENTRO de Películas/Series y
# de «Más», y Mi lista dentro de «Más» y de la Colección.
SIDEBAR = [
	(3000, 'Inicio', 'p3_home', 'principal'),
	(3001, 'Películas', 'p3_peliculas', 'peliculas'),
	(3002, 'Series', 'p3_series', 'series'),
	(3005, 'Buscar', 'p3_search', 'buscar'),
	(3006, 'Ajustes', 'p3_settings', 'ajustes'),
	(3007, 'Más', 'p3_mas', 'mas'),
]
SIDEBAR_BY_ID = dict((c, (a, s)) for c, _l, a, s in SIDEBAR)
SIDEBAR_BY_SECTION = dict((s, c) for c, _l, _a, s in SIDEBAR)

# 2.0.1 (defecto 3): la Principal ya NO muestra indicadores de
# estado de AllDebrid/Trakt/Colección bajo el menú — petición expresa
# de Àngel: nada en su lugar. El estado de cada servicio se ve en
# Ajustes, que es su sitio.


# ─────────────────────── fetchers por fila ───────────────────────

def _fetch_movies(url, tmdb=False):
	from resources.lib.modules import bingie_section_launcher
	return bingie_section_launcher._fetch_movies(url, tmdb)


def _fetch_tvshows(url, tmdb=False):
	from resources.lib.modules import bingie_section_launcher
	return bingie_section_launcher._fetch_tvshows(url, tmdb)


# 2.0.7 \u2014 \u00abSeguimiento\u00bb de verdad: la lista sale del progreso
# de Trakt (todas las series que sigue, con sus cap\u00edtulos vistos),
# fusionada con los marcadores locales (lo pausado). La 2.0.5/2.0.6
# le\u00eda SOLO los marcadores (puntos de reanudaci\u00f3n): en el
# proyector de \u00c0ngel eso daba 13 tarjetas y la fila \u00abse acababa\u00bb;
# y la marca se calculaba contra watchedcache, que no es donde vive
# su progreso. Ahora la esquinita sale del MISMO dato de Trakt:
# capítulos emitidos frente a vistos, sin consultas extra.
# 2.1.2 (petición de Àngel): la esquinita ya NO sale de emitidos
# frente a vistos — sale de la BÓVEDA (capítulos en español con
# enlace) frente a vistos de Trakt (ver _tiene_capitulo_nuevo_es):
# se apaga al ver el último en español y vuelve sola cuando la
# cosecha/bóveda trae uno nuevo. Sin datos de bóveda, se mantiene
# la regla 2.0.7.
def _prog_serie(n_vistos, aired):
	"""2.1.4 — progreso de una serie en Seguimiento: (prog_0_100, al_dia).
	prog solo cuando va a medias (0 < vistos < emitidos); al_dia cuando
	vistos >= emitidos. Sin emitidos, (None, False)."""
	try:
		a = int(aired or 0)
		n = int(n_vistos or 0)
	except Exception:
		return None, False
	if a <= 0:
		return None, False
	if n >= a:
		return None, True
	if n > 0:
		return int(round(100.0 * n / a)), False
	return None, False


_SEG_CACHE = {'ts': 0.0, 'items': None}
_SEG_TTL = 600


def _tiene_capitulo_nuevo_es(tmdb, aired, seen_eps):
	"""Pestaña azul de «Seguimiento» (2.1.2, petición de Àngel):
	solo si queda al menos un capítulo EN ESPAÑOL sin ver.

	Regla: la marca sale de la BÓVEDA (los capítulos que el addon
	tiene en español), no de los emitidos de Trakt — Trakt cuenta
	también capítulos sin enlace en español (aún no cosechados, o
	sin versión en castellano) y la marca no se apagaba nunca.
	· Hay capítulo nuevo: la bóveda trae un (temporada, capítulo)
	  con enlace en español que no está en los vistos de Trakt.
	· Visto el último en español: todos los de la bóveda están
	  vistos → SIN marca; cuando la cosecha/bóveda trae uno nuevo,
	  vuelve a aparecer sola.
	· Sin datos de bóveda para la serie (sin bóveda, sin enlaces):
	  se mantiene la regla anterior (emitidos > vistos) para no
	  cambiar nada a ciegas. No descarga nada ni bloquea la lista:
	  solo lee la base local, y ante cualquier error, la regla
	  anterior. Solo marca series ya empezadas (seen_eps no vacío),
	  como antes."""
	try:
		tmdb_id = int(tmdb or 0)
	except Exception:
		tmdb_id = 0
	if not tmdb_id or not seen_eps:
		try:
			return bool(aired) and bool(seen_eps) and int(aired) > len(seen_eps)
		except Exception:
			return False
	try:
		from resources.lib.modules import coleccion_runtime as _col
		v = _col.get_vault()
		if v is None:
			raise Exception('sin boveda')
		seasons = v.seasons(tmdb_id) or []
		if not seasons:
			raise Exception('serie sin enlaces en boveda')
		for s in seasons:
			try:
				sn = int(s.get('temporada') or 0)
			except Exception:
				continue
			if sn <= 0:
				continue
			for e in v.episodes(tmdb_id, sn) or []:
				try:
					en = int(e.get('episodio') or 0)
				except Exception:
					continue
				if en <= 0 or (sn, en) in seen_eps:
					continue
				# ¿Tiene al menos un enlace en español (no solo latino)?
				links = v.links_meta('serie', tmdb_id, sn, en) or []
				if _col.order_chain(links):
					return True
		return False
	except Exception:
		try:
			return bool(aired) and bool(seen_eps) and int(aired) > len(seen_eps)
		except Exception:
			return False


def _grupo_seg(item):
	"""2.1.6 — grupo de ordenación de «Seguimiento»: 0 = capítulo nuevo
	en español (la esquinita), 1 = a medias / pausada, 2 = ya vista /
	al día. La ordenación estable conserva dentro de cada grupo el
	orden por última actividad."""
	if item.get('_p3_sinver'):
		return 0
	if item.get('_watched') == '1':
		return 2
	return 1


def _seguimiento_items():
	"""Lista COMPLETA y ordenada de \u00abSeguimiento\u00bb, cacheada en
	memoria 10 minutos (paginar no repite la llamada a Trakt).
	Orden (2.1.6, petición de Àngel): tres grupos — 0 = capítulo nuevo
	en español, 1 = a medias / pausada, 2 = ya vista / al día — y dentro
	de cada grupo, por última actividad."""
	import time
	now = time.time()
	if _SEG_CACHE['items'] is not None and now - _SEG_CACHE['ts'] < _SEG_TTL:
		return _SEG_CACHE['items']
	by_key, alias, act = {}, {}, {}

	items_out = []

	def _add(item, actividad):
		ids = [('tmdb', item.get('tmdb')), ('imdb', item.get('imdb')),
			   ('tvdb', item.get('tvdb'))]
		ids = [(k, str(v)) for (k, v) in ids if v]
		if not ids:
			return
		canon = None
		for (k, v) in ids:
			if alias.get((k, v)) in by_key:
				canon = alias[(k, v)]
				break
		if canon is None:
			canon = ids[0]
			item['_seg_key'] = canon
			by_key[canon] = item
			act[canon] = actividad or ''
			items_out.append(item)
		else:
			if actividad and actividad > (act.get(canon) or ''):
				act[canon] = actividad
			if item.get('_p3_sinver'):
				by_key[canon]['_p3_sinver'] = True
		for (k, v) in ids:
			alias[(k, v)] = canon

	# 1) Trakt: las series que sigue, con su progreso real.
	try:
		from resources.lib.modules import trakt as _trakt_mod
		watched = _trakt_mod.watchedShows() \
			if _trakt_mod.getTraktCredentialsInfo() else None
	except Exception:
		watched = None
	if watched:
		for entry in watched:
			try:
				show = entry.get('show') or {}
				ids = show.get('ids') or {}
				title = show.get('title') or ''
				if not title:
					continue
				seen_eps = set()
				for s in (entry.get('seasons') or []):
					try:
						sn = int(s.get('number') or 0)
					except Exception:
						continue
					if sn <= 0:
						continue
					for e in (s.get('episodes') or []):
						try:
							seen_eps.add((sn, int(e.get('number') or 0)))
						except Exception:
							continue
				aired = show.get('aired_episodes') or 0
				item = {'title': title, 'tvshowtitle': title,
						'year': str(show.get('year') or ''),
						'imdb': str(ids.get('imdb') or ''),
						'tmdb': str(ids.get('tmdb') or ''),
						'tvdb': str(ids.get('tvdb') or ''),
						'mediatype': 'tvshow', 'plot': '',
						'_p3_media': 'tvshow', '_bm_movie': False}
				if _tiene_capitulo_nuevo_es(ids.get('tmdb'), aired, seen_eps):
					item['_p3_sinver'] = True
				# 2.1.4: barra azul de la miniatura = vistos/emitidos;
				# al día (vistos>=emitidos) → disco con tick (la base
				# lo pinta con luc_watched desde '_watched').
				prog, al_dia = _prog_serie(len(seen_eps), aired)
				if al_dia:
					item['_watched'] = '1'
				elif prog is not None:
					item['progress'] = prog
				_add(item, entry.get('last_watched_at') or '')
			except Exception:
				continue
	# 2) Marcadores locales: lo pausado (series y pel\u00edculas).
	try:
		from resources.lib.database import traktsync
		rows = []
		for ret_type in ('episodes', 'movies'):
			try:
				part = traktsync.fetch_bookmarks('', ret_all=True, ret_type=ret_type) or []
			except Exception:
				part = []
			for r in part:
				r['_bm_movie'] = (ret_type == 'movies')
			rows += part
		for row in rows:
			title = row.get('tvshowtitle') or row.get('title') or ''
			if not title:
				continue
			es_movie = bool(row.get('_bm_movie'))
			_add({'title': title, 'tvshowtitle': title,
				  'year': row.get('year') or '',
				  'imdb': row.get('imdb') or '',
				  'tmdb': row.get('tmdb') or '',
				  'tvdb': row.get('tvdb') or '',
				  'mediatype': 'movie' if es_movie else 'tvshow',
				  'plot': '', '_p3_media': 'movie' if es_movie else 'tvshow',
				  '_bm_movie': es_movie}, row.get('paused_at') or '')
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()
	items = items_out
	# 2.1.6 — primero por última actividad y luego por grupo (la
	# ordenación estable conserva la actividad dentro del grupo).
	items.sort(key=lambda i: act.get(i.get('_seg_key')) or '', reverse=True)
	items.sort(key=_grupo_seg)
	_SEG_CACHE['ts'] = now
	_SEG_CACHE['items'] = items
	return items


def _fetch_seguimiento(url, tmdb=False):
	"""\u00abSeguimiento\u00bb: paginaci\u00f3n local sobre la lista completa
	(2.0.7: Trakt + marcadores; ver _seguimiento_items), cada p\u00e1gina
	enriquecida desde TMDB/metacach\u00e9 como hasta ahora."""
	from resources.lib.windows.bingie_section_home import ROW_PREVIEW
	offset = 0
	if url and '#' in url:
		try:
			offset = int(url.rsplit('#', 1)[1])
		except Exception:
			offset = 0
	items = _seguimiento_items()
	page = [dict(i) for i in items[offset:offset + ROW_PREVIEW]]
	if page and offset + ROW_PREVIEW < len(items):
		page[-1]['next'] = 'p3_seguimiento#%d' % (offset + ROW_PREVIEW)
	_enrich_seguimiento(page)
	return page


def _enrich_seguimiento(page):
	"""Rellena la página de «Seguimiento» con la meta de TMDB (vía
	metacaché primero; lo que falte se pide y se cachea): póster,
	fanart, trama, nota y título localizado. Si algo falla, la
	tarjeta se queda con el arte del addon, como antes."""
	if not page:
		return
	try:
		from resources.lib.indexers import tmdb as _tmdb_idx
		from resources.lib.database import metacache
		movies_idx = _tmdb_idx.Movies()
		lang, user = movies_idx.lang, movies_idx.user
		try:
			metacache.fetch(page, lang, user)
		except Exception:
			pass
		shows_idx = None
		fresh = []
		for it in page:
			# título localizado ya presente (metacaché): se sincroniza
			if it.get('_bm_movie'):
				if it.get('title'):
					it['tvshowtitle'] = it['title']
			elif it.get('tvshowtitle'):
				it['title'] = it['tvshowtitle']
			if it.get('poster'):
				continue
			tid = it.get('tmdb') or ''
			if not tid:
				continue
			meta = None
			try:
				if it.get('_bm_movie'):
					meta = movies_idx.get_movie_meta(tid, it.get('imdb') or None)
				else:
					if shows_idx is None:
						shows_idx = _tmdb_idx.TVshows()
					meta = shows_idx.get_showSeasons_meta(tid)
			except Exception:
				meta = None
			if not meta:
				continue
			for k in ('poster', 'fanart', 'plot', 'rating', 'genre', 'premiered'):
				if meta.get(k):
					it[k] = meta[k]
			if it.get('_bm_movie'):
				if meta.get('title'):
					it['title'] = meta['title']
					it['tvshowtitle'] = meta['title']
			elif meta.get('tvshowtitle'):
				it['tvshowtitle'] = meta['tvshowtitle']
				it['title'] = meta['tvshowtitle']
			if meta.get('premiered') and not it.get('year'):
				it['year'] = str(meta['premiered'])[:4]
			fresh.append({'imdb': it.get('imdb', ''), 'tmdb': tid,
						  'tvdb': it.get('tvdb', ''), 'lang': lang,
						  'user': user, 'item': meta})
		if fresh:
			try:
				metacache.insert(fresh)
			except Exception:
				pass
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()


def _fetch_porterminar(url, tmdb=False):
	"""«Películas por terminar» (2.0.5, petición de Àngel): películas
	empezadas y no terminadas, para retomarlas de un vistazo.

	Fuente: los marcadores locales del motor (traktsync.fetch_bookmarks
	de películas — la misma fuente que usa Movies.unfinished() del
	motor): los escribe el reproductor al pausar/parar y los sincroniza
	Trakt cuando está vinculado. Sin marcadores, la fila sale vacía y
	el menú no se rompe. Se descartan las que constan como terminadas
	(progreso >= 99 % cuando el dato viene). Paginación local con
	carga continua, igual que «Seguimiento», y enriquecido TMDB
	compartido (póster/fanart y título en castellano)."""
	from resources.lib.windows.bingie_section_home import ROW_PREVIEW
	offset = 0
	if url and '#' in url:
		try:
			offset = int(url.rsplit('#', 1)[1])
		except Exception:
			offset = 0
	items, seen = [], set()
	try:
		from resources.lib.database import traktsync
		try:
			rows = traktsync.fetch_bookmarks('', ret_all=True, ret_type='movies') or []
		except Exception:
			rows = []
		if not isinstance(rows, (list, tuple)):
			rows = []
		rows = sorted(rows, key=lambda r: r.get('paused_at') or '', reverse=True)
		for row in rows:
			if not isinstance(row, dict):
				continue
			prog = None
			try:
				prog = float(row.get('progress') or '')
				if prog >= 99:
					continue
			except Exception:
				prog = None
			tmdb = row.get('tmdb') or ''
			imdb = row.get('imdb') or ''
			key = tmdb or imdb
			if not key or key in seen:
				continue
			title = row.get('title') or ''
			if not title:
				continue
			seen.add(key)
			items.append({
				'title': title, 'tvshowtitle': title,
				'year': row.get('year') or '', 'imdb': imdb, 'tmdb': tmdb,
				'tvdb': '', 'mediatype': 'movie',
				'plot': '', '_p3_media': 'movie',
				'_bm_movie': True,
				# 2.1.4: la base lo convierte en la barra azul
				# (luc_progress) de la miniatura.
				'progress': prog,
			})
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()
		return []
	page = items[offset:offset + ROW_PREVIEW]
	if page and offset + ROW_PREVIEW < len(items):
		page[-1]['next'] = 'p3_porterminar#%d' % (offset + ROW_PREVIEW)
	_enrich_seguimiento(page)
	return page


_MESES_ES = ('ene', 'feb', 'mar', 'abr', 'may', 'jun',
			 'jul', 'ago', 'sep', 'oct', 'nov', 'dic')


def _fecha_es(iso):
	"""'2026-12-24' -> '24 dic 2026' (fecha visible de estreno)."""
	try:
		y, m, d = str(iso)[:10].split('-')
		return '%d %s %s' % (int(d), _MESES_ES[int(m) - 1], y)
	except Exception:
		return ''


def _fetch_proximos(url, tmdb=False):
	"""«Próximos estrenos» (2.0.6, Inicio): películas por estrenar
	(TMDB upcoming) y series por estrenar (TMDB calendar premieres)
	mezcladas y ORDENADAS POR FECHA, cada tarjeta con su fecha
	visible ('_p3_fecha', la pinta _make_li en la etiqueta).

	Paginación propia: la ventana corta cada página a ROW_PREVIEW,
	así que el token 'next' guarda las URLs de página de AMBAS
	fuentes y CUÁNTOS ítems de cada una ya se han emitido de esa
	página ('p3_proximos#<url_pelis>|<url_series>|<n_pelis>|<n_series>',
	URLs escapadas). Al pedir la siguiente, se redescargan esas
	páginas, se descarta el prefijo ya emitido de cada fuente y se
	vuelve a mezclar; la fuente que se agota pasa a su página
	siguiente. Sin este conteo, la cola de la mezcla (los estrenos
	inmediatos tras el corte) se perdería entre página y página."""
	from resources.lib.windows.bingie_section_home import ROW_PREVIEW
	m_url = s_url = None
	m_used = s_used = 0
	if url and '#' in url:
		try:
			partes = url.split('#', 1)[1].split('|')
			pm = partes[0] if len(partes) > 0 else ''
			ps = partes[1] if len(partes) > 1 else ''
			m_url = unquote_plus(pm) if pm and pm != '-' else None
			s_url = unquote_plus(ps) if ps and ps != '-' else None
			m_used = int(partes[2]) if len(partes) > 2 and partes[2] else 0
			s_used = int(partes[3]) if len(partes) > 3 and partes[3] else 0
		except Exception:
			m_url = s_url = None
			m_used = s_used = 0
	try:
		movies = _fetch_movies(m_url or 'tmdb_upcoming', True) or []
	except Exception:
		movies = []
	try:
		shows = _fetch_tvshows(s_url or 'tmdb_calendarPremieres', True) or []
	except Exception:
		shows = []

	def _next_of(lst):
		for i in lst:
			if isinstance(i, dict) and i.get('next'):
				return i['next']
		return None

	nm, ns = _next_of(movies), _next_of(shows)
	for i in movies:
		i.pop('next', None)
	for i in shows:
		i.pop('next', None)
	movies = movies[m_used:]
	shows = shows[s_used:]
	mezcla = []
	for i in movies:
		j = dict(i)
		j['_p3_media'] = 'movie'
		mezcla.append(j)
	for i in shows:
		j = dict(i)
		j['_p3_media'] = 'tvshow'
		mezcla.append(j)
	for j in mezcla:
		f = j.get('premiered') or ''
		j['_p3_fecha_iso'] = f
		j['_p3_fecha'] = _fecha_es(f)
	mezcla.sort(key=lambda j: j.get('_p3_fecha_iso') or '9999-99-99')
	out = mezcla[:ROW_PREVIEW]
	if out and len(mezcla) > len(out) or (out and (nm or ns)):
		n_m = sum(1 for j in out if j.get('_p3_media') == 'movie')
		n_s = len(out) - n_m
		# Próxima página de cada fuente: la misma si aún le queda
		# resto por emitir; la siguiente de TMDB si se agotó.
		if n_m < len(movies):
			tok_m, tok_mu = (quote_plus(m_url) if m_url else
							 quote_plus('tmdb_upcoming')), str(m_used + n_m)
		elif nm:
			tok_m, tok_mu = quote_plus(nm), '0'
		else:
			tok_m, tok_mu = '-', '0'
		if n_s < len(shows):
			tok_s, tok_su = (quote_plus(s_url) if s_url else
							 quote_plus('tmdb_calendarPremieres')), str(s_used + n_s)
		elif ns:
			tok_s, tok_su = quote_plus(ns), '0'
		else:
			tok_s, tok_su = '-', '0'
		if tok_m != '-' or tok_s != '-' or n_m < len(movies) or n_s < len(shows):
			out[-1]['next'] = 'p3_proximos#%s|%s|%s|%s' % (
				tok_m, tok_s, tok_mu, tok_su)
	return out


def _coleccion_entry_cmd(node):
	"""Comando RunPlugin que abre el destino de un nodo de menú de
	la Colección (las mismas acciones p3_coleccion_* del router que
	usa la propia ventana de la Colección)."""
	dest = node.get('dest')
	if dest == 'grid':
		return 'RunPlugin(%s?action=p3_coleccion_grid&spec=%s&titulo=%s)' % (
			ADDON, quote_plus(jsdumps(node.get('spec') or {})),
			quote_plus(node.get('titulo') or 'Colección'))
	if dest in ('menu', 'hub'):
		menu_id = node.get('menu')
		if dest == 'hub':
			menu_id = 'peliculas' if node.get('kind') == 'pelicula' else 'series'
		cmd = 'RunPlugin(%s?action=p3_coleccion_menu&menu=%s' % (
			ADDON, quote_plus(menu_id or 'root'))
		if node.get('params'):
			cmd += '&params=%s' % quote_plus(jsdumps(node['params']))
		return cmd + ')'
	if dest == 'search':
		return 'RunPlugin(%s?action=p3_search)' % ADDON
	if dest == 'servicios':
		return 'RunPlugin(%s?action=p3_settings)' % ADDON
	return ''


def _coleccion_entry_icon(node, menu_id):
	"""Imagen propia para cada tarjeta de la fila «Colección»
	(ficheros del paquete visual, vía _p3_icon como en «Más»)."""
	nid = node.get('id') or ''
	if 'novedades' in nid:
		return 'nowplaying.png'
	if 'anadidas' in nid:
		return 'in-theaters.png'
	if 'actualizaciones' in nid:
		return 'airing-today.png'
	if 'nuevas' in nid:
		return 'new-tvshows.png'
	if 'seguimiento' in nid:
		return 'trakt.png'
	if 'recomendadas' in nid:
		return 'recommended.png'
	if 'populares' in nid:
		return 'most-popular.png'
	if 'sagas' in nid or 'especial' in nid:
		return 'boxsets.png'
	if 'titulo' in nid:
		return 'search.png'
	if 'ano' in nid:
		return 'calendar.png'
	if 'calidad' in nid:
		return 'highly-rated.png'
	if 'generos' in nid or 'az' in nid:
		return 'tvshows.png' if menu_id == 'series' else 'movies.png'
	return 'tvshows.png' if menu_id == 'series' else 'movies.png'


def _fetch_coleccion_seccion(url, tmdb=False):
	"""Fila «Colección» DENTRO de Películas/Series (2.0.6): las
	entradas del menú de la Colección de esa sección (Descubrir /
	Explorar / Buscar por), como tarjetas que abren la ventana de
	la Colección correspondiente. url = 'colmenu:peliculas' |
	'colmenu:series'. Sin datos de la Colección en el aparato, la
	fila sale vacía y nada se rompe."""
	try:
		menu_id = url.split(':', 1)[1] if url and ':' in url else 'root'
		from resources.lib.modules import coleccion_runtime
		coleccion_runtime.ensure_data(show_progress=False)
		if not coleccion_runtime.data_ready():
			return []
		catalog = coleccion_runtime.get_catalog()
		if catalog is None:
			return []
		from resources.lib.windows import coleccion_ui
		_titulo, nodes = coleccion_ui.build_menu(menu_id, catalog)
		out = []
		for node in coleccion_ui.visible_nodes(nodes, catalog):
			if node.get('dest') == 'header':
				continue
			cmd = _coleccion_entry_cmd(node)
			if not cmd:
				continue
			out.append({'title': node.get('titulo') or '',
						'_p3_entry': cmd, '_p3_media': 'entry',
						'mediatype': 'entry',
						'_p3_icon': _coleccion_entry_icon(node, menu_id)})
		return out
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()
		return []


def _mas_entries():
	"""Entradas de «Más» (2.1.6): una sola entrada por categoría, de
	la COLECCIÓN (lo suyo, en español) — sin duplicar con las rejillas
	de género de TMDB (solo películas, de fuera, no funcionaban del
	todo) y sin «Novedades», que ya está en Inicio. Cada una abre una
	ruta VISUAL existente vía RunPlugin."""
	entries = [
		('Mi lista', 'RunPlugin(%s?action=p3_milista)' % ADDON, 'mas_mi_lista.jpg'),
		('Documentales', 'RunPlugin(%s?action=p3_coleccion_menu&menu=cat%%3ADocumental)' % ADDON, 'mas_documentales.jpg'),
		('Dibujos', 'RunPlugin(%s?action=p3_coleccion_menu&menu=cat%%3ADibujo)' % ADDON, 'mas_dibujos.jpg'),
		('Anime', 'RunPlugin(%s?action=p3_coleccion_menu&menu=cat%%3AAnime)' % ADDON, 'mas_anime.jpg'),
		('Música', 'RunPlugin(%s?action=p3_coleccion_menu&menu=musica)' % ADDON, 'mas_musica.jpg'),
		('Telenovelas', 'RunPlugin(%s?action=p3_coleccion_menu&menu=telenovelas)' % ADDON, 'mas_telenovelas.jpg'),
		('Listas de Trakt', 'RunPlugin(%s?action=tools_traktLikedListManager)' % ADDON, 'mas_listas_trakt.jpg'),
	]
	return [{'title': lbl, '_p3_entry': cmd, '_p3_media': 'entry', 'mediatype': 'entry',
			 '_p3_icon': icon}
			for (lbl, cmd, icon) in entries if cmd]


def _fetch_entries(url, tmdb=False):
	return _mas_entries()


_FETCHERS = {
	'movie': _fetch_movies,
	'tvshow': _fetch_tvshows,
	'seguimiento': _fetch_seguimiento,
	'porterminar': _fetch_porterminar,
	'entry': _fetch_entries,
	'proximos': _fetch_proximos,
	'coleccion': _fetch_coleccion_seccion,
}


def _fetch_mixed_tendencias(url, tmdb=False):
	"""Tendencias de la Principal: películas y series de Trakt
	entrelazadas (1 película, 1 serie…), cada ítem etiquetado con su
	media para que la ficha sepa qué es."""
	try:
		movies = _fetch_movies('trakttrending', False)
		shows = _fetch_tvshows('trakttrending', False)
	except Exception:
		movies, shows = [], []
	out = []
	for i in range(max(len(movies), len(shows))):
		if i < len(movies):
			m = dict(movies[i]); m['_p3_media'] = 'movie'; out.append(m)
		if i < len(shows):
			s = dict(shows[i]); s['_p3_media'] = 'tvshow'; out.append(s)
	return out


def _row_fetch(row, url):
	"""Despacha el fetch de una fila según su 'media'. Para páginas
	siguientes, la URL ya es la URL real de siguiente página."""
	media = row.get('media') or 'movie'
	if url == row.get('url'):
		# primera carga: tokens especiales
		if media == 'mixed':
			return _fetch_mixed_tendencias(url, row.get('tmdb', False))
		if media in _FETCHERS:
			return _FETCHERS[media](url, row.get('tmdb', False))
		return _FETCHERS.get(media, _fetch_movies)(url, row.get('tmdb', False))
	# paginación: en filas mixtas la URL de Trakt dice /movies/ o /shows/
	if media == 'mixed':
		fn = _fetch_tvshows if '/shows/' in url else _fetch_movies
		items = fn(url, row.get('tmdb', False))
		tag = 'tvshow' if fn is _fetch_tvshows else 'movie'
		for it in items:
			it['_p3_media'] = tag
		return items
	fn = _FETCHERS.get(media, _fetch_movies)
	return fn(url, row.get('tmdb', False))


# ─────────────────────── la ventana ───────────────────────

class P3HomeXML(BingieSectionHomeXML):
	def __init__(self, *args, **kwargs):
		self.section = kwargs.get('section') or 'principal'
		# La clase base lee rows/section_title/media_type/fetch_fn de
		# kwargs; media_type global solo es un respaldo: cada fila trae
		# su 'media' y cada ítem queda etiquetado con '_p3_media'.
		kwargs.setdefault('media_type', 'movie')
		kwargs['fetch_fn'] = kwargs.get('fetch_fn') or _fetch_movies
		BingieSectionHomeXML.__init__(self, *args, **kwargs)
		# Todo el texto visible en castellano (R2): la base elige la
		# etiqueta de la tarjeta de paginacion segun el idioma de Kodi;
		# aqui se fija siempre en castellano.
		self._lbl_next = 'P\u00e1gina siguiente'

	# — estado SIEMPRE reevaluado (regla de oro) —
	def onInit(self):
		try:
			self.setProperty('p3.section', self.section)
			self.setProperty('p3.section_title', self.section_title)
		except Exception:
			pass
		BingieSectionHomeXML.onInit(self)

	# — carga de filas con fetch por fila (media propia) —
	def _load_row(self, idx):
		if idx >= len(self.rows) or self._row_loaded[idx]:
			return
		row = self.rows[idx]
		# 2.0.3 (bloqueante de campo): la descarga de una fila corre en un
		# hilo con PLAZO (30 s). Tras vincular Trakt, la primera fila
		# (Tendencias = trending de Trakt + enriquecido) podía quedarse
		# colgada para siempre y la portada entera quedaba en
		# «Cargando...» (foto del proyector). Con plazo, la fila se
		# rinde vacía o con el plan B y la portada SIEMPRE termina de
		# abrir; ninguna carga manda sobre la pantalla principal.
		import threading as _th
		_box = {}
		def _job():
			try:
				_box['items'] = _row_fetch(row, row['url']) or []
			except Exception:
				_box['items'] = []
		_t = _th.Thread(target=_job, daemon=True)
		_t.start()
		_t.join(30)
		items = _box.get('items') or []
		if not items and row.get('url') == 'p3_tendencias':
			# Plan B de Tendencias sin Trakt (o con Trakt caído): las
			# populares de TMDB de películas y series, mezcladas.
			try:
				from resources.lib.menus import movies as _mm
				from resources.lib.menus import tvshows as _mt
				fm = _fetch_movies(_mm.Movies().tmdb_popular_link, True) or []
				for it in fm:
					if isinstance(it, dict):
						it.setdefault('_p3_media', 'movie')
				fs = _fetch_tvshows(_mt.TVshows().tmdb_popular_link, True) or []
				for it in fs:
					if isinstance(it, dict):
						it.setdefault('_p3_media', 'tvshow')
				items = []
				for k in range(max(len(fm), len(fs))):
					if k < len(fm): items.append(fm[k])
					if k < len(fs): items.append(fs[k])
			except Exception:
				items = []
		for it in items:
			if isinstance(it, dict):
				it.setdefault('_p3_media', row.get('media') or self.media_type)
		st = self._row_state[idx]
		from resources.lib.windows.bingie_section_home import ROW_PREVIEW, _next_url
		st['items'] = items[:ROW_PREVIEW]
		st['next'] = _next_url(items)
		self._row_loaded[idx] = True

	def _render_row(self, idx):
		# 2.0.3: SIN tarjeta «Página siguiente» (petición expresa): las
		# filas cargan de forma continua al acercarse al final (ver
		# onAction). Misma lógica que la base, sin la tarjeta final.
		try:
			from resources.lib.windows.bingie_section_home import MAX_ROWS
			if idx >= MAX_ROWS: return
			st = self._row_state[idx]
			listitems, kept = [], []
			for i in st['items']:
				li = self._make_li(i)
				if li is not None:
					listitems.append(li); kept.append(i)
			st['items'] = kept
			st['card_pos'] = -1
			ctrl = self.getControl(ROW_BASE_ID + idx)
			ctrl.reset()
			if listitems:
				ctrl.addItems(listitems)
			self.clearProperty('luc_kodi.row_loading.%d' % idx)
		except Exception:
			self.clearProperty('luc_kodi.row_loading.%d' % idx)

	def _load_next_page(self, row_idx):
		try:
			st = self._row_state[row_idx]
			nxt = st.get('next')
			if not nxt:
				return
			row = self.rows[row_idx]
			self.setProperty('luc_kodi.row_loading.%d' % row_idx, '1')
			new_items = _row_fetch(row, nxt) or []
			if not new_items:
				st['next'] = None
				self.clearProperty('luc_kodi.row_loading.%d' % row_idx)
				return
			from resources.lib.windows.bingie_section_home import _next_url
			# 2.0.3: carga CONTINUA — la página nueva se AÑADE al final de
			# la fila (nada de sustituir ni de historial de páginas) y el
			# foco se queda donde estaba.
			try:
				leaving_pos = self.get_position(ROW_BASE_ID + row_idx)
			except Exception:
				leaving_pos = 0
			for it in new_items:
				if isinstance(it, dict):
					it.setdefault('_p3_media', self.rows[row_idx].get('media') or self.media_type)
			st['items'] = (st.get('items') or []) + new_items
			st['next'] = _next_url(new_items)
			self._render_row(row_idx)
			try:
				self.setFocusId(ROW_BASE_ID + row_idx)
				if 0 <= leaving_pos < len(st['items']):
					self.getControl(ROW_BASE_ID + row_idx).selectItem(leaving_pos)
			except Exception:
				pass
			self._active_row = row_idx
			self._refresh_hero()
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()
			self.clearProperty('luc_kodi.row_loading.%d' % row_idx)

	# — tarjetas: media por ítem + marca NUEVO solo si el dato viene —
	def _make_li(self, i):
		if (i.get('_p3_media') or i.get('mediatype')) == 'entry' or i.get('_p3_entry'):
			try:
				li = control.item(label=i.get('title') or '', offscreen=True)
				art = self._addonPoster
				if i.get('_p3_icon'):
					# 2.0.5 (foto de Àngel en su proyector): TODAS las
					# tarjetas de «Más» salían con el logo genérico.
					# Causa: control.artPath() NO admite argumentos
					# (devuelve la CARPETA del tema); llamarla con el
					# nombre de fichero lanzaba TypeError, se tragaba
					# en el except y el arte se quedaba en el póster
					# del addon. Lo correcto: unir carpeta + fichero.
					try:
						import os
						cand = os.path.join(control.artPath(), i['_p3_icon'])
						if os.path.exists(cand):
							art = cand
					except Exception:
						pass
				li.setArt({'poster': art, 'thumb': art, 'fanart': art})
				li.setProperty('luc_entry', '1')
				return li
			except Exception:
				return None
		# mediatype correcto por ítem (la base usa el de la ventana)
		saved = self.media_type
		media = i.get('_p3_media') or saved
		self.media_type = 'tvshow' if media == 'tvshow' else 'movie'
		try:
			li = BingieSectionHomeXML._make_li(self, i)
		finally:
			self.media_type = saved
		if li is not None:
			# 2.0.6: esquinita «sin ver» (Seguimiento) — la propiedad
			# que el skin convierte en la esquinita azul doblada.
			try:
				if i.get('_p3_sinver'):
					li.setProperty(SINVER_PROP, '1')
			except Exception:
				pass
			# 2.0.6: «Próximos estrenos» — la fecha de estreno va
			# VISIBLE en la etiqueta de la tarjeta («Título · 24 dic
			# 2026»), en vez del año entre paréntesis de la base.
			try:
				if i.get('_p3_fecha'):
					titulo = i.get('title') or i.get('tvshowtitle') or ''
					if titulo:
						li.setLabel('%s · %s' % (titulo, i['_p3_fecha']))
			except Exception:
				pass
			# «NUEVO» SOLO si el ítem trae la marca en los datos; en vivo
			# el motor no la trae, así que normalmente no se pinta nada.
			try:
				if i.get('is_new') or i.get('nuevo') or i.get('_is_new'):
					li.setProperty('luc_new', '1')
			except Exception:
				pass
		return li

	def onAction(self, action):
		# 2.0.3: (a) «atrás» dentro de una lista larga vuelve a la
		# PRIMERA miniatura; un segundo «atrás» ya sí sale (lo gestiona
		# la base). (b) Al acercarse al final de una fila (3 últimas
		# tarjetas) se añade sola la página siguiente: carga continua,
		# sin tarjeta «Página siguiente» que pulsar.
		try:
			action_id = action.getId()
			# 2.0.9: navegación de la barra POR TECLAS, nunca por foco.
			# Al pulsar arriba/abajo, cuando el callback lee el foco,
			# Kodi YA lo ha movido al botón destino (comprobado en el
			# banco: con la aritmética de «siguiente botón» el contenido
			# avanzaba DOS apartados por tecla). Así que el cambio es
			# al apartado del botón que tiene el foco AHORA. Buscar y
			# Ajustes no cambian (se abren con OK). Las acciones solo
			# nacen del mando: sin teclas no hay cambios, y es
			# imposible que se mueva solo — el bucle de la 2.0.7 venía
			# de hacerlo desde onFocus. El foco no se toca.
			if action_id in (3, 4) and not getattr(self, '_nav_switching', False):
				try:
					fid = self.getFocusId()
				except Exception:
					fid = 0
				if fid in SIDEBAR_BY_ID:
					target = SIDEBAR_BY_ID[fid][1]
					if target not in ('buscar', 'ajustes') and target != self.section:
						self._nav_switching = True
						try:
							self.switch_section(target, keep_focus_on=-1)
						finally:
							self._nav_switching = False
			if action_id in self.back_actions:
				ar = self._active_row
				if 0 <= ar < len(self.rows):
					try:
						pos = self.get_position(ROW_BASE_ID + ar)
					except Exception:
						pos = 0
					if pos > 0:
						try:
							self.getControl(ROW_BASE_ID + ar).selectItem(0)
							self.setFocusId(ROW_BASE_ID + ar)
							self._refresh_hero()
						except Exception:
							pass
						return
		except Exception:
			pass
		BingieSectionHomeXML.onAction(self, action)
		try:
			action_id = action.getId()
			if action_id in (2, 3) and not self._paging:  # izquierda/derecha
				ar = self._active_row
				if 0 <= ar < len(self.rows):
					st = self._row_state[ar]
					if st.get('next') and st.get('items'):
						pos = self.get_position(ROW_BASE_ID + ar)
						if pos >= len(st['items']) - 3:
							self._paging = True
							try:
								self._load_next_page(ar)
							finally:
								self._paging = False
		except Exception:
			pass

	def _refresh_hero(self):
		BingieSectionHomeXML._refresh_hero(self)
		# Título/tipo legibles para el héroe de la piel (la sinopsis y el
		# fanart salen del ListItem enfocado vía $INFO en el XML).
		try:
			row_idx = self._active_row
			st = self._row_state[row_idx] if row_idx < len(self._row_state) else None
			if not st:
				return
			pos = self.get_position(ROW_BASE_ID + row_idx)
			if pos == st.get('card_pos') or not (0 <= pos < len(st['items'])):
				self.setProperty('p3.hero_kind', '')
				# 2.0.3: sin tarjeta de página, el héroe de la base
				# escribía «Página siguiente» al coincidir pos=-1 con
				# card_pos=-1 en filas vacías: se limpia.
				self.clearProperty('luc_kodi.meta_line')
				for _k in ('rating_imdb', 'rating_rt', 'rating_tmdb', 'rating_trakt'):
					self.clearProperty('luc_kodi.%s' % _k)
				return
			i = st['items'][pos]
			media = i.get('_p3_media') or self.media_type
			self.setProperty('p3.hero_kind', 'Serie' if media == 'tvshow' else 'Película')
			rating = self._fmt(i.get('rating'))
			self.setProperty('p3.hero_rating', rating)
		except Exception:
			pass

	# — cambio de sección EN SITIO (una sola ventana-carcasa) —
	def switch_section(self, section, keep_focus_on=None):
		"""La barra lateral cambia el contenido de ESTA ventana, sin
		cerrarla: «atrás» sale de la app una sola vez y nunca se cae a
		la ventana de vídeo de Kodi entre secciones."""
		if section == self.section:
			if keep_focus_on is None:
				try:
					self.setFocusId(ROW_BASE_ID)
				except Exception:
					pass
			return
		from resources.lib.windows.bingie_section_home import MAX_ROWS
		title, rows, media_type = _section_spec(section)
		self.section = section
		self.section_title = title
		self.media_type = media_type
		self.rows = rows
		self._active_row = 0
		self._row_state = [{'items': [], 'next': None, 'card_pos': -1,
							'page': 0, 'history': []} for _ in rows]
		self._row_loaded = [False for _ in rows]
		self._row_rendered = [False for _ in rows]
		try:
			self.setProperty('luc_kodi.section_title', title)
			self.setProperty('p3.section', section)
			self.setProperty('p3.section_title', title)
		except Exception:
			pass
		for idx in range(MAX_ROWS):
			try:
				self.setProperty('luc_kodi.row_label.%d' % idx,
								 rows[idx].get('label', '') if idx < len(rows) else '')
				self.clearProperty('luc_kodi.row_loading.%d' % idx)
			except Exception:
				pass
			try:
				self.getControl(ROW_BASE_ID + idx).reset()
			except Exception:
				pass
		for idx in range(min(len(rows), MAX_ROWS)):
			try:
				self.setProperty('luc_kodi.row_loading.%d' % idx, '1')
			except Exception:
				pass
			self._load_row(idx)
			self._render_row(idx)
			self._row_rendered[idx] = True
		if keep_focus_on == -1:
			pass  # 2.0.9 (teclas): el foco no se toca; Kodi lo mueve
			# al botón destino de la barra tras procesar el onAction.
		elif keep_focus_on is not None:
			try:
				self.setFocusId(keep_focus_on)
			except Exception:
				pass
		elif rows and self._row_state and self._row_state[0]['items']:
			try:
				self.setFocusId(ROW_BASE_ID)
			except Exception:
				pass
		self._refresh_hero()

	# — clics: barra lateral + filas —
	def onClick(self, controlId):
		if controlId in SIDEBAR_BY_ID:
			action, section = SIDEBAR_BY_ID[controlId]
			if section in ('principal', 'peliculas', 'series', 'mas'):
				self.switch_section(section)
				return
			# Colección / Mi lista / Buscar / Ajustes: ventanas propias
			# que se abren ENCIMA; al cerrarlas se vuelve aquí (la
			# ventana NO se cierra, el estado se reevalúa en onInit).
			control.execute('RunPlugin(%s?action=%s)' % (ADDON, action))
			return
		BingieSectionHomeXML.onClick(self, controlId)

	def _select(self, row_idx):
		try:
			if self._paging:
				return
			self._active_row = row_idx
			st = self._row_state[row_idx]
			pos = self.get_position(ROW_BASE_ID + row_idx)
			if pos == st.get('card_pos'):
				self._paging = True
				try:
					self._load_next_page(row_idx)
				finally:
					import xbmc
					xbmc.sleep(150)
					self._paging = False
				return
			items = st['items']
			if not (0 <= pos < len(items)):
				return
			chosen = items[pos]
			if chosen.get('_p3_entry'):
				# Las entradas abren otra ventana/ruta ENCIMA; al
				# cerrarla se vuelve a esta (que no se cierra).
				control.execute(chosen['_p3_entry'])
				return
			# Clic en póster = FICHA (no reproduce directo).
			self._save_resume_position()
			from resources.lib.windows import p3_detail
			p3_detail.show_detail(chosen)
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()


# ─────────────────────── constructores de sección ───────────────────────

def _open(section, section_title, rows, media_type='movie'):
	window = P3HomeXML('p3_home.xml', control.addonPath(control.addonId()),
					   rows=rows, section_title=section_title,
					   media_type=media_type, section=section)
	window.run()
	del window


def _row(label, url, kind, media):
	return {'label': label, 'url': url, 'tmdb': (kind == 'tmdb'), 'media': media}


def _section_spec(section):
	"""(título, filas, media_type) de cada sección de la carcasa."""
	if section == 'peliculas':
		# 2.0.5 (peticiones de Àngel, 23/11): «Películas por terminar»
		# y las vistas/valoradas de Trakt y TMDB. «Más valoradas» es
		# la fila de TMDB top_rated que ya existía como «Mejor
		# valoradas», con el nombre que pidió Àngel. Las «más vistas»
		# salen de las listas públicas de Trakt (watched/monthly y
		# watched/all): no hace falta tener Trakt vinculado.
		return ('Películas', [
			_row('Novedades', 'tmdb_nowplaying', 'tmdb', 'movie'),
			_row('Populares', 'traktpopular', 'trakt', 'movie'),
			_row('Películas por terminar', 'p3_porterminar', 'local', 'porterminar'),
			_row('Más vistas este mes', 'traktwatchedmonthly', 'trakt', 'movie'),
			_row('Más vistas de todos los tiempos', 'traktwatchedall', 'trakt', 'movie'),
			_row('Más valoradas', 'tmdb_toprated', 'tmdb', 'movie'),
			_row('Próximamente', 'tmdb_upcoming', 'tmdb', 'movie'),
			# 2.0.6: la Colección, dentro de la propia sección.
			_row('Colección', 'colmenu:peliculas', 'local', 'coleccion'),
		], 'movie')
	if section == 'series':
		# 2.0.5: mismos apartados nuevos que en Películas (listas
		# públicas de Trakt watched/monthly y watched/all, y las
		# mejor valoradas de TMDB), además de los que ya había.
		return ('Series', [
			_row('Últimas actualizaciones', 'tmdb_ontheair', 'tmdb', 'tvshow'),
			_row('Series nuevas', 'tmdb_airingtoday', 'tmdb', 'tvshow'),
			_row('Seguimiento', 'p3_seguimiento', 'local', 'seguimiento'),
			_row('Recomendadas', 'traktrecommendations', 'trakt', 'tvshow'),
			_row('Populares', 'traktpopular', 'trakt', 'tvshow'),
			_row('Más vistas este mes', 'traktwatchedmonthly', 'trakt', 'tvshow'),
			_row('Más vistas de todos los tiempos', 'traktwatchedall', 'trakt', 'tvshow'),
			_row('Más valoradas', 'tmdb_toprated', 'tmdb', 'tvshow'),
			# 2.0.6: la Colección, dentro de la propia sección
			# (novena fila: el skin trae 9 grupos desde la 2.0.6 y
			# el MAX_ROWS del motor es 12, así que cabe sin tocarlo).
			_row('Colección', 'colmenu:series', 'local', 'coleccion'),
		], 'tvshow')
	if section == 'mas':
		return ('Más', [_row('Más', 'p3_entries', 'local', 'entry')], 'movie')
	return ('Inicio', [
		# 2.0.7 (petición de Àngel): «Seguimiento» arriba del todo
		# en Inicio, como acceso directo a sus series en curso.
		_row('Seguimiento', 'p3_seguimiento', 'local', 'seguimiento'),
		_row('Tendencias', 'p3_tendencias', 'trakt', 'mixed'),
		# 2.0.6 (petición de Àngel): «Próximos estrenos» en Inicio,
		# películas y series ordenadas por fecha, con la fecha
		# visible en cada tarjeta.
		_row('Próximos estrenos', 'p3_proximos', 'local', 'proximos'),
		_row('Novedades en películas', 'tmdb_nowplaying', 'tmdb', 'movie'),
		_row('Novedades en series', 'tmdb_airingtoday', 'tmdb', 'tvshow'),
	], 'movie')


def show_principal():
	title, rows, media_type = _section_spec('principal')
	_open('principal', title, rows, media_type=media_type)


def show_peliculas():
	title, rows, media_type = _section_spec('peliculas')
	_open('peliculas', title, rows, media_type=media_type)


def show_series():
	title, rows, media_type = _section_spec('series')
	_open('series', title, rows, media_type=media_type)


def show_mas():
	title, rows, media_type = _section_spec('mas')
	_open('mas', title, rows, media_type=media_type)
