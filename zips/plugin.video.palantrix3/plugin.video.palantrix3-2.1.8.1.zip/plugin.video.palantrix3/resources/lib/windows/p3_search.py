# -*- coding: utf-8 -*-
"""
	PalAntriX 2.0.6 — Buscador estilo Netflix (piel negro/azul).

	Teclado COMPLETO en pantalla a la izquierda (minúsculas, dígitos
	y vocales acentuadas; requisito expreso de Àngel, sin recortes y
	sin la caja de búsqueda típica de Kodi) y resultados EN VIVO a
	la derecha desde las primeras 2 letras: cada tecla actualiza la
	consulta y relanza la búsqueda al momento.

	Resultados con PREVALENCIA de la Colección: primero los del
	catálogo/bóveda (coleccion_runtime.search_catalog, marcados
	«Colección») y después los en vivo de TMDB (la vía real del
	motor: indexers/tmdb.py, clase TMDb y su get_request).

	Clic en resultado de la Colección -> play_vault (película) o
	Temporadas/Episodios de la Colección (serie).
	Clic en resultado en vivo -> RunPlugin play_Item (película) o
	bingie_launcher.open_seasons_window (serie).

	Sin búsqueda por voz: aparcada por decisión de Àngel (P5); no se
	implementa ni se pinta el botón.
"""

from json import dumps as jsdumps
from urllib.parse import quote_plus

import xbmc
import xbmcgui

from resources.lib.modules import control
from resources.lib.modules import coleccion_runtime
from resources.lib.modules import log_utils
from resources.lib.windows.base import BaseDialog
from resources.lib.windows import coleccion_ui

ADDON_ID = 'plugin.video.palantrix3'

LIST_RESULTADOS = 401
LBL_QUERY = 402
LBL_ESTADO = 403

# Teclado en pantalla: ids 5000..5041 (6 filas x 7 columnas, en el
# mismo orden que p3_search.xml) y acciones.
TECLAS = 'abcdefg' 'hijklmn' 'opqrstu' 'vwxyzñ0' '1234567' '89áéíóú'
KEY_FIRST = 5000
KEY_LAST = KEY_FIRST + len(TECLAS) - 1
KEY_ESPACIO = 5100
KEY_BORRAR = 5101
KEY_LIMPIAR = 5102
MIN_LETRAS = 2


def search_live_tmdb(query, limit=20):
	"""Búsqueda en vivo contra TMDB con el indexer del motor
	(indexers/tmdb.py: TMDb.get_request, su clave y su idioma).
	Devuelve dicts con la forma que consumen play_Item y
	bingie_launcher.open_seasons_window."""
	out = []
	try:
		from resources.lib.indexers.tmdb import TMDb
		t = TMDb()
		lang = getattr(t, 'lang', '') or 'es-ES'
		url = ('https://api.themoviedb.org/3/search/multi?api_key=%s'
			   '&language=%s&query=%s&page=1&include_adult=false'
			   % (t.API_key, lang, quote_plus(query)))
		res = t.get_request(url)
		if not res or not isinstance(res, dict):
			return out
		for item in res.get('results') or []:
			mt = item.get('media_type')
			if mt not in ('movie', 'tv'):
				continue
			tmdb_id = item.get('id')
			if not tmdb_id:
				continue
			title = item.get('title') or item.get('name') or ''
			if not title:
				continue
			fecha = item.get('release_date') or item.get('first_air_date') or ''
			poster = item.get('poster_path') or ''
			fanart = item.get('backdrop_path') or ''
			d = {
				'title': title,
				'tvshowtitle': title if mt == 'tv' else '',
				'year': (fecha or '')[:4],
				'imdb': '',
				'tmdb': str(tmdb_id),
				'tvdb': '',
				'poster': ('https://image.tmdb.org/t/p/w500' + poster) if poster else '',
				'poster2': ('https://image.tmdb.org/t/p/w500' + poster) if poster else '',
				'poster3': ('https://image.tmdb.org/t/p/w500' + poster) if poster else '',
				'fanart': ('https://image.tmdb.org/t/p/w1280' + fanart) if fanart else '',
				'fanart2': ('https://image.tmdb.org/t/p/w1280' + fanart) if fanart else '',
				'fanart3': ('https://image.tmdb.org/t/p/w1280' + fanart) if fanart else '',
				'plot': item.get('overview') or '',
				'premiered': fecha,
				'mediatype': 'movie' if mt == 'movie' else 'tvshow',
				'_kind': 'pelicula' if mt == 'movie' else 'serie',
				'_vivo': True,
			}
			out.append(d)
			if len(out) >= limit:
				break
	except Exception:
		log_utils.error()
	return out


class SearchWindow(BaseDialog):
	"""Buscador Netflix: teclado a la izquierda, resultados en vivo
	a la derecha. La consulta también puede llegar por
	kwargs['query'] (router p3_search): se precarga y se busca."""

	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, args)
		self.query = (kwargs.get('query') or '').strip()
		self.results = []      # dicts con '_origen': 'coleccion'|'vivo'
		self._inited = False

	def onInit(self):
		coleccion_ui.sidebar_init(self, 'search')
		try:
			self.getControl(coleccion_ui.LBL_STATUS).setLabel(coleccion_ui.status_text())
		except Exception:
			pass
		self._pintar_teclas()
		if self._inited:
			return
		self._inited = True
		self._pintar_query()
		if len(self.query) >= MIN_LETRAS:
			self._do_search(foco=False)
		else:
			self._pintar_estado(
				'Escribe con el teclado: los resultados salen en vivo.')
		self.setFocusId(KEY_FIRST)

	def _pintar_teclas(self):
		"""Fija las etiquetas del teclado desde Python: en la piel, una
		etiqueta XML puramente numérica («0»…«9») la resuelve Kodi como
		id de cadena localizada y salía «Programs», «Pictures», etc."""
		for i, tecla in enumerate(TECLAS):
			try:
				self.getControl(KEY_FIRST + i).setLabel(tecla)
			except Exception:
				pass

	# ── consulta y resultados en vivo ──
	def _pintar_query(self):
		try:
			self.getControl(LBL_QUERY).setLabel(
				'«%s»' % self.query if self.query else 'Buscar…')
		except Exception:
			pass

	def _pintar_estado(self, texto):
		try:
			self.getControl(LBL_ESTADO).setLabel(texto)
		except Exception:
			pass

	def _tras_tecla(self):
		"""Cada tecla actualiza la consulta y, con 2+ letras, busca
		EN VIVO; con menos, limpia los resultados."""
		self._pintar_teclas()
		self._pintar_query()
		if len(self.query) >= MIN_LETRAS:
			self._do_search(foco=False)
		else:
			self.results = []
			try:
				self.getControl(LIST_RESULTADOS).reset()
			except Exception:
				pass
			self._pintar_estado(
				'Escribe al menos %d letras para buscar.' % MIN_LETRAS
				if self.query else
				'Escribe con el teclado: los resultados salen en vivo.')

	def _do_search(self, foco=True):
		self._pintar_estado('Cargando…')
		self.results = []
		# 1) Colección primero (prevalencia = ORDEN, no exclusión)
		try:
			coleccion_runtime.ensure_data()
			for row in coleccion_runtime.search_catalog(self.query):
				row = dict(row)
				row['_origen'] = 'coleccion'
				self.results.append(row)
		except Exception:
			log_utils.error()
		# 2) En vivo (TMDB) detrás, TAMBIÉN los que están en la
		# Colección: son el respaldo de luc alcanzable desde aquí si
		# la bóveda no tiene enlaces de ese título o fallan (P3).
		for item in search_live_tmdb(self.query):
			item['_origen'] = 'vivo'
			self.results.append(item)
		lst = self.getControl(LIST_RESULTADOS)
		lst.reset()
		items = []
		for r in self.results:
			if r.get('_origen') == 'coleccion':
				kind = r.get('kind') or 'pelicula'
				li = xbmcgui.ListItem(label=r.get('titulo') or '')
				poster = coleccion_ui._img(r.get('poster'))
				li.setArt({'poster': poster, 'thumb': poster,
						   'fanart': coleccion_ui._img(r.get('fondo'), 'w1280')})
				partes = ['Colección',
						  'Película' if kind == 'pelicula' else 'Serie']
				if r.get('fecha'):
					partes.append(str(r.get('fecha'))[:4])
				li.setLabel2(' · '.join(partes))
			else:
				li = xbmcgui.ListItem(label=r.get('title') or '')
				li.setArt({'poster': r.get('poster') or '',
						   'thumb': r.get('poster') or '',
						   'fanart': r.get('fanart') or ''})
				partes = ['En vivo',
						  'Película' if r.get('_kind') == 'pelicula' else 'Serie']
				if r.get('year'):
					partes.append(str(r.get('year')))
				li.setLabel2(' · '.join(partes))
			items.append(li)
		lst.addItems(items)
		self._pintar_estado(
			'%d resultados · primero la Colección' % len(self.results)
			if self.results else
			'Sin resultados para «%s».' % self.query)
		if foco and self.results:
			self.setFocusId(LIST_RESULTADOS)

	def onClick(self, control_id):
		if coleccion_ui.sidebar_click(self, control_id, 'search'):
			return
		if KEY_FIRST <= control_id <= KEY_LAST:
			self.query += TECLAS[control_id - KEY_FIRST]
			self._tras_tecla()
			return
		if control_id == KEY_ESPACIO:
			if self.query and not self.query.endswith(' '):
				self.query += ' '
				self._tras_tecla()
			return
		if control_id == KEY_BORRAR:
			if self.query:
				self.query = self.query[:-1]
				self._tras_tecla()
			return
		if control_id == KEY_LIMPIAR:
			if self.query:
				self.query = ''
				self._tras_tecla()
			return
		if control_id != LIST_RESULTADOS:
			return
		pos = self.getControl(LIST_RESULTADOS).getSelectedPosition()
		if not (0 <= pos < len(self.results)):
			return
		r = self.results[pos]
		if r.get('_origen') == 'coleccion':
			coleccion_ui.open_title(r)
			return
		# En vivo: película -> play_Item; serie -> temporadas de luc
		if r.get('_kind') == 'pelicula':
			cmd = ('RunPlugin(plugin://%s/?action=play_Item&title=%s&year=%s'
				   '&imdb=%s&tmdb=%s&meta=%s&bingie=1)' % (
					   ADDON_ID, quote_plus(r.get('title') or ''),
					   r.get('year') or '', r.get('imdb') or '',
					   r.get('tmdb') or '', quote_plus(jsdumps(r))))
			control.execute(cmd)
		else:
			from resources.lib.modules import bingie_launcher
			bingie_launcher.open_seasons_window(r)


def show_search(query=''):
	w = SearchWindow('p3_search.xml', coleccion_ui._addon_path(),
					 'Default', '1080i', query=query)
	w.doModal()
	del w
