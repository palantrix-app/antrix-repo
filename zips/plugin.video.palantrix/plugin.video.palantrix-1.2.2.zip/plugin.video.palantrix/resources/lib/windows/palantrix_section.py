# -*- coding: utf-8 -*-
"""
	PalAntriX Add-on — Menú visual de sección (1.1.1)

	Al entrar en Películas o Series desde la portada, la navegación
	sigue en el mismo estilo visual: fondo con fanart, menú en texto
	que se ilumina al pasar por encima y, a la derecha, las miniaturas
	(pósters) del apartado enfocado. La lista de apartados es corta a
	propósito (los más usados); al clicar uno se abre su listado
	clásico de siempre. «Atrás» vuelve a la portada.

	Las miniaturas son una vista previa de TMDB (la misma fuente de
	metadatos del addon); el listado que se abre al clicar es el real
	del apartado (Trakt/TMDB según el caso).
"""

import json
from threading import Thread
from urllib.request import Request, urlopen

from resources.lib.modules import control
from resources.lib.modules import log_utils
from resources.lib.windows.base import BaseDialog

homeWindow = control.homeWindow

BTN_BASE = 2001  # botones del menú: 2001..2008
POSTER_BASE = 4010  # miniaturas: 4010..4015 (rejilla 3x2)
MAX_POSTERS = 6

BASE_URL = 'plugin://plugin.video.palantrix/?action=%s'
TMDB_API = 'https://api.themoviedb.org/3%s?api_key=%s&language=es-ES'
TMDB_POSTER = 'https://image.tmdb.org/t/p/w342%s'
TMDB_BACKDROP = 'https://image.tmdb.org/t/p/w1280%s'
TMDB_KEY_FALLBACK = 'f2e500501d9fa3bd1637bfd00f11583a'

# (etiqueta, acción del listado clásico, endpoint TMDB de la vista previa)
SECTIONS = {
	'movies': ('Películas', [
		('Tendencias', 'movies&url=trakttrending', '/trending/movie/week'),
		('Populares', 'movies&url=traktpopular', '/movie/popular'),
		('En cartelera', 'tmdbmovies&url=tmdb_nowplaying', '/movie/now_playing'),
		('Mejor valoradas', 'tmdbmovies&url=tmdb_toprated', '/movie/top_rated'),
		('Próximamente', 'tmdbmovies&url=tmdb_upcoming', '/movie/upcoming'),
		('Géneros', 'movieGenres&url=tmdb_genre', None),
		('Años', 'movieYears&url=tmdb_year', None),
		('Buscar', 'movieSearch', None),
	]),
	'tv': ('Series', [
		('Tendencias', 'tvshows&url=trakttrending', '/trending/tv/week'),
		('Populares', 'tvshows&url=traktpopular', '/tv/popular'),
		('Mejor valoradas', 'tmdbTvshows&url=tmdb_toprated', '/tv/top_rated'),
		('En emisión', 'tmdbTvshows&url=tmdb_ontheair', '/tv/on_the_air'),
		('Se emiten hoy', 'tmdbTvshows&url=tmdb_airingtoday', '/tv/airing_today'),
		('Géneros', 'tvGenres&url=tmdb_genre', None),
		('Años', 'tvYears&url=tmdb_year', None),
		('Buscar', 'tvSearch', None),
	]),
}

_PREVIEW_CACHE = {}


def _fetch_preview(endpoint):
	"""Descarga la vista previa de un apartado desde TMDB: hasta 6
	pósters y el fondo del primer título."""
	key = control.setting('tmdb.api.key') or TMDB_KEY_FALLBACK
	req = Request(TMDB_API % (endpoint, key),
				  headers={'User-Agent': 'Kodi PalAntriX', 'Accept': 'application/json'})
	with urlopen(req, timeout=8) as resp:
		data = json.loads(resp.read().decode('utf-8'))
	posters, backdrop = [], ''
	for row in (data.get('results') or []):
		if row.get('poster_path'):
			posters.append(TMDB_POSTER % row['poster_path'])
		if not backdrop and row.get('backdrop_path'):
			backdrop = TMDB_BACKDROP % row['backdrop_path']
		if len(posters) >= MAX_POSTERS:
			break
	return {'posters': posters, 'backdrop': backdrop}


class PalantrixSectionXML(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, args)
		self.section = kwargs.get('section', 'tv')
		self.title, self.items = SECTIONS.get(self.section, SECTIONS['tv'])
		self.navigated = False
		self.closed = False
		self.focus_idx = 0
		self.previews = {}

	def onInit(self):
		try:
			self.setProperty('palantrix.section.title', self.title)
			for idx, (label, _action, _ep) in enumerate(self.items):
				self.setProperty('palantrix.section.label%d' % idx, label)
			for idx in range(len(self.items), 8):
				try:
					self.getControl(BTN_BASE + idx).setVisible(False)
				except Exception:
					pass
			self.setProperty('palantrix.section.fanart', control.addonFanart())
			thread = Thread(target=self._load_previews)
			thread.daemon = True
			thread.start()
			self._apply_focus(0)
		except Exception:
			log_utils.error()

	def _load_previews(self):
		for idx, (_label, _action, endpoint) in enumerate(self.items):
			if self.closed or endpoint is None:
				continue
			try:
				if endpoint in _PREVIEW_CACHE:
					self.previews[idx] = _PREVIEW_CACHE[endpoint]
				else:
					self.previews[idx] = _fetch_preview(endpoint)
					_PREVIEW_CACHE[endpoint] = self.previews[idx]
			except Exception:
				self.previews[idx] = {'posters': [], 'backdrop': ''}
			if not self.closed and idx == self.focus_idx:
				try:
					self._apply_focus(idx)
				except Exception:
					pass

	def _apply_focus(self, idx):
		preview = self.previews.get(idx)
		if not preview or not preview.get('posters'):
			# Sin vista previa (Géneros, Años, Buscar o fallo de red):
			# se oculta la rejilla y el fondo vuelve al del addon.
			self.setProperty('palantrix.section.thumbs', '')
			if preview is not None:
				self.setProperty('palantrix.section.fanart', control.addonFanart())
			return
		if preview.get('backdrop'):
			self.setProperty('palantrix.section.fanart', preview['backdrop'])
		for j in range(MAX_POSTERS):
			try:
				img = self.getControl(POSTER_BASE + j)
				if j < len(preview['posters']):
					img.setImage(preview['posters'][j])
					img.setVisible(True)
				else:
					img.setVisible(False)
			except Exception:
				pass
		self.setProperty('palantrix.section.thumbs', '1')

	def onFocus(self, control_id):
		try:
			idx = control_id - BTN_BASE
			if 0 <= idx < len(self.items):
				self.focus_idx = idx
				self._apply_focus(idx)
		except Exception:
			pass

	def onClick(self, control_id):
		try:
			idx = control_id - BTN_BASE
			if 0 <= idx < len(self.items):
				self.navigated = True
				control.execute('Container.Update(%s)' % (BASE_URL % self.items[idx][1]))
				self.doClose()
		except Exception:
			log_utils.error()

	def onAction(self, action):
		if action in self.closing_actions:
			self.doClose()

	def doClose(self):
		self.closed = True
		self.close()
