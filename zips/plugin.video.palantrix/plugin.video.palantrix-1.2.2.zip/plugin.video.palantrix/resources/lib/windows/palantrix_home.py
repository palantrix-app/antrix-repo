# -*- coding: utf-8 -*-
"""
	PalAntriX Add-on — Portada visual (1.1.0)

	Ventana de inicio propia: fondo con el fanart del título destacado,
	menú en texto (Películas, Series, Trakt, Buscar) que se ilumina al
	pasar por encima, fila «Seguir viendo» desde los marcadores locales
	de Trakt (sincronizados por el servicio) y un engranaje discreto
	arriba a la derecha con Herramientas y Servicios Premium.

	Al elegir una sección, la propia ventana navega (Container.Update
	o RunPlugin para reproducir) antes de cerrarse; el router solo
	cierra el directorio raíz vacío. Si el usuario sale con «atrás» sin
	elegir nada, no se navega y el router pinta el menú clásico de
	siempre como red de seguridad.
"""

from urllib.parse import quote_plus

import xbmcgui

from resources.lib.modules import control
from resources.lib.modules import log_utils
from resources.lib.windows.base import BaseDialog

homeWindow = control.homeWindow

# Controles (ver palantrix_home.xml)
BTN_GEAR = 1200
BTN_MOVIES, BTN_SHOWS, BTN_TRAKT, BTN_SEARCH = 2001, 2002, 2003, 2004
POSTER_BASE = 3010  # por celda i (base = 3010 + 11*i): imagen +0, botón +1, marco +2, progreso +3, etiqueta +4
POSTER_STEP = 11
MAX_ITEMS = 5

BASE_URL = 'plugin://plugin.video.palantrix/?action=%s'
METAHUB_POSTER = 'https://images.metahub.space/poster/medium/%s/img'
METAHUB_BACKGROUND = 'https://images.metahub.space/background/large/%s/img'


def _play_url(item):
	"""URL play_Item (patrón Bingie: RunPlugin con bingie=1) para un
	marcador de «Seguir viendo»."""
	if item['kind'] == 'episode':
		return ('plugin://plugin.video.palantrix/?action=play_Item'
				'&title=%s&year=&imdb=%s&tmdb=%s&tvdb=%s'
				'&season=%s&episode=%s&tvshowtitle=%s&premiered=&meta=&select=1&bingie=1'
				% (quote_plus(item['title']), item['imdb'], item['tmdb'], item['tvdb'],
				   item['season'], item['episode'], quote_plus(item['tvshowtitle'])))
	return ('plugin://plugin.video.palantrix/?action=play_Item'
			'&title=%s&year=&imdb=%s&tmdb=%s&select=1&bingie=1'
			% (quote_plus(item['title']), item['imdb'], item['tmdb']))


def _load_items():
	"""Lee los marcadores locales de Trakt (tabla bookmarks de
	traktsync) y devuelve hasta MAX_ITEMS mezclando episodios y
	películas, lo más reciente primero (paused_at descendente)."""
	items = []
	try:
		from resources.lib.database import traktsync
		for row in traktsync.fetch_bookmarks('', ret_all=True, ret_type='episodes') or []:
			try:
				items.append({
					'kind': 'episode',
					'name': row.get('tvshowtitle') or '',
					'sub': 'T%s · E%s' % (row.get('season'), row.get('episode')),
					'title': row.get('title') or '',
					'tvshowtitle': row.get('tvshowtitle') or '',
					'imdb': row.get('imdb') or '', 'tmdb': row.get('tmdb') or '',
					'tvdb': row.get('tvdb') or '',
					'season': row.get('season'), 'episode': row.get('episode'),
					'progress': row.get('progress'), 'paused_at': row.get('paused_at') or '',
				})
			except Exception:
				pass
		for row in traktsync.fetch_bookmarks('', ret_all=True, ret_type='movies') or []:
			try:
				items.append({
					'kind': 'movie',
					'name': row.get('title') or '',
					'sub': 'Película',
					'title': row.get('title') or '',
					'tvshowtitle': '',
					'imdb': row.get('imdb') or '', 'tmdb': row.get('tmdb') or '',
					'tvdb': '',
					'season': None, 'episode': None,
					'progress': row.get('progress'), 'paused_at': row.get('paused_at') or '',
				})
			except Exception:
				pass
	except Exception:
		log_utils.error()
	items = [i for i in items if i['imdb'] and i['name']]
	items.sort(key=lambda i: i['paused_at'], reverse=True)
	return items[:MAX_ITEMS]


class PalantrixHomeXML(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, args)
		self.navigated = False
		self.closed = False
		self.next_section = None
		self.items = []

	def onInit(self):
		try:
			self.items = _load_items()
			self._fill()
		except Exception:
			log_utils.error()

	def _fill(self):
		if not self.items:
			self.setProperty('palantrix.cw.visible', '')
			return
		self.setProperty('palantrix.cw.visible', '1')
		featured = self.items[0]
		self.setProperty('palantrix.home.fanart', METAHUB_BACKGROUND % featured['imdb'])
		for idx, item in enumerate(self.items):
			base = POSTER_BASE + idx * POSTER_STEP
			try:
				self.getControl(base).setImage(METAHUB_POSTER % item['imdb'])
			except Exception:
				pass
			# Las etiquetas van por propiedades de ventana (patrón $INFO
			# del propio addon): setText sobre estas etiquetas no se
			# pintaba. Nombre en la primera línea y, en episodios, la
			# temporada/capítulo en una segunda línea atenuada (como en
			# la maqueta aprobada: nada de textos sobre el póster).
			try:
				self.setProperty('palantrix.cw.label%d' % idx, item['name'])
				self.setProperty('palantrix.cw.sub%d' % idx,
								 item['sub'] if item['kind'] == 'episode' else '')
			except Exception:
				pass
			try:
				progress = float(item.get('progress') or 0)
			except (TypeError, ValueError):
				progress = 0
			try:
				self.getControlProgress(base + 3).setPercent(progress)
			except Exception:
				pass
		# Celdas sin título: ocultar sus controles (la barra de progreso
		# por defecto se pintaba también en las celdas vacías).
		for idx in range(len(self.items), MAX_ITEMS):
			base = POSTER_BASE + idx * POSTER_STEP
			for cid in (base, base + 1, base + 3, base + 4, base + 5):
				try:
					self.getControl(cid).setVisible(False)
				except Exception:
					pass

	def onFocus(self, control_id):
		# Al pasar por un póster, el fondo pasa a ser su fanart.
		try:
			rel = control_id - (POSTER_BASE + 1)
			if rel >= 0 and rel % POSTER_STEP == 0:
				idx = rel // POSTER_STEP
				if 0 <= idx < len(self.items):
					self.setProperty('palantrix.home.fanart',
									 METAHUB_BACKGROUND % self.items[idx]['imdb'])
		except Exception:
			pass

	def _navigate(self, builtin):
		self.navigated = True
		control.execute(builtin)
		self.doClose()

	def _select(self, heading, options, routes):
		choice = xbmcgui.Dialog().select(heading, options)
		if choice is None or choice < 0:
			return
		self._navigate('Container.Update(%s)' % (BASE_URL % routes[choice]))

	def onClick(self, control_id):
		try:
			if control_id == BTN_MOVIES:
				# Películas y Series abren su menú visual de sección
				# (1.1.1); show_home() encadena las dos ventanas.
				self.next_section = 'movies'
				self.doClose()
			elif control_id == BTN_SHOWS:
				self.next_section = 'tv'
				self.doClose()
			elif control_id == BTN_TRAKT:
				self._select('Trakt', ['Películas de Trakt', 'Series de Trakt'],
							 ['mymovieNavigator', 'mytvNavigator'])
			elif control_id == BTN_SEARCH:
				self._navigate('Container.Update(%s)' % (BASE_URL % 'tools_searchNavigator'))
			elif control_id == BTN_GEAR:
				self._select('Opciones', ['Herramientas', 'Servicios Premium'],
							 ['tools_toolNavigator', 'premiumNavigator'])
			else:
				rel = control_id - (POSTER_BASE + 1)
				if rel >= 0 and rel % POSTER_STEP == 0:
					idx = rel // POSTER_STEP
					if 0 <= idx < len(self.items):
						self._navigate('RunPlugin(%s)' % _play_url(self.items[idx]))
		except Exception:
			log_utils.error()

	def onAction(self, action):
		if action in self.closing_actions:
			self.doClose()

	def doClose(self):
		self.closed = True
		self.close()


def show_home():
	"""Muestra la portada. Devuelve True si el usuario eligió una
	sección (la navegación ya la ejecutó la propia ventana) y el
	router debe limitarse a cerrar el directorio raíz. Devuelve False
	si salió con «atrás» sin elegir o si no procede abrirla (guard de
	reentrada): el router pinta entonces el menú clásico."""
	if homeWindow.getProperty('palantrix.home_open') == 'true':
		return False
	homeWindow.setProperty('palantrix.home_open', 'true')
	try:
		section = None
		while True:
			if section is None:
				win = PalantrixHomeXML('palantrix_home.xml', control.addonPath(control.addonId()), 'Default')
				win.doModal()
				navigated, section = win.navigated, win.next_section
				del win
				if navigated:
					return True
				if not section:
					return False
			else:
				from resources.lib.windows.palantrix_section import PalantrixSectionXML
				win = PalantrixSectionXML('palantrix_section.xml', control.addonPath(control.addonId()), 'Default', section=section)
				win.doModal()
				navigated = win.navigated
				del win
				if navigated:
					return True
				section = None  # «atrás» en la sección: volver a la portada
	except Exception:
		log_utils.error()
		return False
	finally:
		homeWindow.clearProperty('palantrix.home_open')
