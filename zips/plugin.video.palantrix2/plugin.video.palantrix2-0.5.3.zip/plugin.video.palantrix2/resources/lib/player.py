# -*- coding: utf-8 -*-
"""Reproducción (Fase 4) — la cadena del mapa, del clic al vídeo.

Todo pasa por la pantalla de carga de la casa (playui.LoadingWindow):
fanart del título y UN solo texto de fase. Dentro de ese flujo:

1. Si la bóveda está bloqueada, el desbloqueo se pide ahí dentro (una
   vez por sesión); cancelar vuelve al origen con su foco.
2. Cadena silenciosa con pre-terminación: enlaces de la base en orden
   de calidad del mapa (DV > HDR10+ > HDR10 > 4K > 1080p), castellano
   primero (el latino SOLO nunca entra en la cadena automática; el dual
   vale). En cuanto un enlace vivo alcanza la calidad preferida del
   ajuste, se reproduce y no se prueba ni se desbloquea ninguno más.
3. Si la base se agota sin alcanzar la preferida pero hay enlaces vivos
   de menor calidad: selector por excepción, agrupado por origen
   (Palantir / En vivo). No se reproduce el menor en silencio.
4. Fallo = siguiente: si un enlace falla al arrancar, la cadena
   continúa en silencio; agotada la base, la capa en vivo entra sola
   («Buscando en vivo…»). Sin nada: «Sin enlaces disponibles» y vuelta.
5. Siguiente episodio precargado mientras se ve el actual (solo en
   memoria, con la bóveda abierta) y diálogo propio al terminar, sin
   cuenta atrás que reproduzca sola.
6. Higiene: visto al ~88 %; menos de 1 minuto no se registra; el
   progreso se guarda siempre en local; Trakt recibe scrobble de
   inicio/pausa/fin si está vinculado. La URL resuelta de un título a
   medias se recuerda en memoria durante la sesión (reanudar
   instantáneo) y se olvida al bloquear la bóveda o cerrar la app.
"""
import re
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui

from alldebrid import AllDebrid, LinkDown, AllDebridError
from db import img
import dialogs

ADDON = xbmcaddon.Addon()

PREF_NOMBRE = {"1": "DV", "2": "4K", "3": "1080p"}
VISTO_PCT = 88.0          # visto al ~85-90 % (mapa)
MIN_REGISTRO_SEG = 60     # menos de 1 minuto no se registra


def _setting(name):
    # Instancia nueva en cada lectura: la de módulo se crea al
    # importar y su foto de ajustes no ve lo que otro módulo guarda
    # durante la sesión — sin esto, vincular AllDebrid en Servicios y
    # reproducir sin reiniciar la app leía la clave vacía (misma
    # familia que el aviso caducado de la principal, 0.5.2/0.5.3).
    return xbmcaddon.Addon().getSetting(name)


def _log(msg):
    xbmc.log("PalAntriX cadena: %s" % msg, xbmc.LOGINFO)


# ---------------------------------------------------------------------------
# Calidad y audio (orden del mapa)
# ---------------------------------------------------------------------------
def _tier(calidad):
    """Escalón de calidad según el mapa: DV > HDR10+ > HDR10 > 4K >
    1080p > HD > SD. Menor número = mejor."""
    c = (calidad or "").upper()
    if "DV" in c:
        return 0
    if "HDR10+" in c or "HDR10 PLUS" in c:
        return 1
    if "HDR" in c:
        return 2
    if "4K" in c or "2160" in c or "8K" in c:
        return 3
    if "1080" in c:
        return 4
    if "720" in c or " HD" in c or c.strip() == "HD":
        return 5
    if "SD" in c or "480" in c:
        return 6
    return 7


def _audio_tokens(audio):
    return set(t for t in re.split(r"[^a-z]+", (audio or "").lower()) if t)


def _es_castellano(audio):
    toks = _audio_tokens(audio)
    return "esp" in toks or "spa" in toks or \
        "castellano" in (audio or "").lower()


def _es_latino_solo(audio):
    return "lat" in _audio_tokens(audio) and not _es_castellano(audio)


def _target_tier():
    """Escalón que hay que alcanzar según el ajuste «calidad».
    None = automática: la preferida es la mejor viva, la cadena se
    detiene en el primer enlace vivo."""
    return {"1": 0, "2": 3, "3": 4}.get(_setting("calidad") or "0")


def _order_chain(links, excluir_latino=True):
    """Orden de prueba de la cadena: calidad descendente y, dentro del
    mismo escalón, castellano primero. Estable sobre el orden de la
    bóveda. El latino solo queda fuera de la cadena automática (regla
    de la casa); sigue elegible a mano desde «Enlaces»."""
    pool = []
    for i, l in enumerate(links):
        if excluir_latino and _es_latino_solo(l.get("audio")):
            continue
        pool.append((i, l))
    pool.sort(key=lambda p: (_tier(p[1].get("calidad")),
                             0 if _es_castellano(p[1].get("audio")) else 1,
                             p[0]))
    return [l for _i, l in pool]


def _audio_label(audio):
    if _es_castellano(audio):
        return "Castellano"
    if "lat" in _audio_tokens(audio):
        return "Latino"
    return "Sin castellano"


# ---------------------------------------------------------------------------
# Vigilante del reproductor
# ---------------------------------------------------------------------------
class _Watcher(xbmc.Player):
    def __init__(self):
        super(_Watcher, self).__init__()
        self._on_started = None
        self._on_end = None
        self._on_failed = None

    def onPlayBackStarted(self):
        if self._on_started:
            self._on_started()

    def onPlayBackEnded(self):
        if self._on_end:
            self._on_end(True)

    def onPlayBackStopped(self):
        if self._on_end:
            self._on_end(False)

    def onPlayBackFailed(self):
        if self._on_failed:
            self._on_failed()


# ---------------------------------------------------------------------------
class Playback(object):
    def __init__(self, catalog, userdata, vault=None, addon_path=None,
                 profile=""):
        self.catalog = catalog
        self.userdata = userdata
        self.vault = vault
        self.addon_path = addon_path or ADDON.getAddonInfo("path")
        self.profile = profile or ""
        self._cache = {}          # (kind, tmdb, t, e) -> url de stream resuelta
        self._preload = None      # {"key", "stream", "src"} del siguiente ep.
        self._session_seq = 0     # invalida ofertas de siguiente episodio viejas
        self._vault_gen = None    # generación de la bóveda vista (sup4-H2)

    # ---------------- construcción de trabajos ----------------
    def _key(self, job):
        return (job["kind"], job["tmdb"], job.get("temporada"),
                job.get("episodio"))

    def _movie_job(self, tmdb, link_rowid=None):
        row = self.catalog.detail("pelicula", tmdb)
        if not row:
            return None
        prog = self.catalog.progreso_peli(tmdb)
        return {"kind": "pelicula", "tmdb": tmdb, "temporada": None,
                "episodio": None, "row": row,
                "titulo_display": row.get("titulo") or "",
                "link_rowid": link_rowid,
                "resume_pct": (prog or {}).get("progress") or 0,
                "save": lambda pct, rt, fin: self.userdata.save_movie(
                    tmdb, pct, rt, fin),
                "live_args": {"kind": "pelicula", "tmdb": tmdb,
                              "titulo": row.get("titulo", ""),
                              "fecha": row.get("fecha", "")}}

    def _episode_job(self, tmdb, temporada, episodio, link_rowid=None):
        row = self.catalog.detail("serie", tmdb)
        if not row:
            return None
        prog = self.catalog.progreso_ep(tmdb, temporada, episodio)
        row2 = dict(row)
        row2["titulo"] = "%s %dx%02d" % (row.get("titulo") or "",
                                         temporada, episodio)
        return {"kind": "serie", "tmdb": tmdb, "temporada": temporada,
                "episodio": episodio, "row": row2,
                "titulo_display": row2["titulo"],
                "link_rowid": link_rowid,
                "resume_pct": (prog or {}).get("progress") or 0,
                "save": lambda pct, rt, fin: self.userdata.save_episode(
                    tmdb, temporada, episodio, pct, rt, fin),
                "live_args": {"kind": "serie", "tmdb": tmdb,
                              "temporada": temporada, "episodio": episodio,
                              "titulo": row.get("titulo", "")}}

    def _reset_job_state(self, job):
        job.setdefault("tried", set())
        job.setdefault("idx", 0)
        job.setdefault("alive_lower", [])
        job.setdefault("links_ready", False)
        job.setdefault("candidates", [])
        job.setdefault("live_cands", None)
        job.setdefault("live_auto_done", False)
        job.setdefault("start_fails", 0)
        job.setdefault("ad", None)

    # ---------------- API (ventanas) ----------------
    def play_movie(self, tmdb, link_rowid=None):
        job = self._movie_job(tmdb, link_rowid)
        if job is None:
            dialogs.notify("Título no encontrado")
            return False
        return self._launch(job)

    def play_episode(self, tmdb, temporada, episodio, link_rowid=None):
        job = self._episode_job(tmdb, temporada, episodio, link_rowid)
        if job is None:
            dialogs.notify("Título no encontrado")
            return False
        return self._launch(job)

    # ---------------- lanzamiento (pantalla de carga) ----------------
    def _launch(self, job):
        apikey = _setting("alldebrid_apikey")
        if not apikey:
            dialogs.ok(
                "PalAntriX",
                "Falta vincular AllDebrid. Ve a Servicios > AllDebrid y "
                "vincúlalo para poder reproducir.")
            return False
        self._reset_job_state(job)
        gen = self.vault.generation if self.vault is not None else None
        if gen != self._vault_gen:
            # La sesión de la bóveda cambió (bloqueo y/o desbloqueo)
            # desde la última reproducción: la memoria de sesión —URLs
            # resueltas y precarga— queda invalidada DE VERDAD en este
            # momento, no perezosamente (sup4-H2 / sup2-M3). Así,
            # bloquear → desbloquear sin reproducir en medio → reproducir
            # NO reutiliza URLs de la sesión anterior.
            self._cache.clear()
            self._preload = None
            self._vault_gen = gen
        if self.vault is not None and not self.vault.unlocked:
            # Con la bóveda bloqueada, la memoria de sesión no vale.
            self._cache.clear()
            self._preload = None
        elif job.get("link_rowid") is None:
            cached = self._cache.get(self._key(job))
            if cached:
                job["cached_stream"] = cached
        from playui import LoadingWindow
        win = LoadingWindow("loading.xml", self.addon_path, "Default",
                            "1080i", playback=self, job=job)
        win.doModal()
        outcome = win.outcome
        canceled = win.user_canceled
        del win
        if canceled or not outcome:
            return False
        if outcome[0] == "play":
            return self._start_stream(job, outcome[1])
        if outcome[0] == "error":
            dialogs.notify(outcome[1], ms=4000)
        return False

    # ---------------- la cadena (corre en el hilo de la carga) ----------------
    def _fetch_links(self, job, ui):
        """Enlaces descifrados del título, en orden de cadena.
        Devuelve None si el usuario cancela el desbloqueo."""
        if self.vault is None:
            return []
        if not self.vault.unlocked:
            ui.set_phase("Bóveda bloqueada")
            if not ui.ask_unlock():
                return None
        if job["kind"] == "pelicula":
            links = self.vault.links_peli(job["tmdb"])
        else:
            links = self.vault.links_ep(job["tmdb"], job["temporada"],
                                        job["episodio"])
        ordered = _order_chain(links)
        rowid = job.get("link_rowid")
        if rowid is not None:
            # «Enlaces»: el enlace elegido va primero TAL CUAL (aunque
            # sea latino: lo ha elegido el usuario a mano); si falla, la
            # cadena sigue con el resto en su orden.
            chosen = [l for l in links if l.get("rowid") == rowid]
            if chosen:
                ordered = chosen + [l for l in ordered
                                    if l.get("rowid") != rowid]
        return ordered

    def _live_enabled(self):
        return (_setting("fallback_vivo") or "true") == "true"

    def _live_query(self, job):
        la = job["live_args"]
        if la.get("kind") == "serie":
            return "%s S%02dE%02d" % (la.get("titulo") or "",
                                      la.get("temporada") or 1,
                                      la.get("episodio") or 1)
        # Película: «Título Año». Apibay no responde a consultas de una
        # palabra («Avatar» → 0) y sí con el año («Avatar 2009»)
        # (sup4-H7); el catálogo no guarda título original, el año es
        # el único enriquecimiento posible en local.
        titulo = la.get("titulo") or ""
        ano = (la.get("fecha") or "")[:4]
        return ("%s %s" % (titulo, ano)) if ano else titulo

    def _live_candidates(self, job):
        """Candidatos en vivo del trabajo; si la consulta con año da
        cero, se reintenta con el título solo."""
        import live
        cands = live.search_candidates(self._live_query(job))
        la = job["live_args"]
        if not cands and la.get("kind") != "serie" and la.get("fecha"):
            cands = live.search_candidates(la.get("titulo") or "")
        return cands

    def _run_chain(self, job, ui):
        """Devuelve ("play", url) / ("abort",) / ("fail", texto) /
        ("error", texto). Reentrante: si un stream falla al arrancar,
        _launch vuelve a entrar con el mismo trabajo y la cadena sigue
        donde iba (lo ya probado está en job['tried'])."""
        if job.get("cached_stream") and \
                job["cached_stream"] not in job["tried"] and \
                job["cached_stream"] != job.get("failed_url"):
            job["tried"].add(job["cached_stream"])
            _log("reanudar instantáneo desde la memoria de sesión")
            return ("play", job["cached_stream"])
        if not job["links_ready"]:
            links = self._fetch_links(job, ui)
            if links is None:
                return ("abort",)
            job["candidates"] = links
            job["links_ready"] = True
            _log("%s: %d enlaces en la base" %
                 (job["titulo_display"], len(links)))
        if job["ad"] is None:
            job["ad"] = AllDebrid(_setting("alldebrid_apikey"))
        ad = job["ad"]
        target = _target_tier()
        ui.set_phase("Resolviendo enlace…")
        while job["idx"] < len(job["candidates"]):
            if ui.is_canceled():
                return ("abort",)
            link = job["candidates"][job["idx"]]
            job["idx"] += 1
            src = "vault:%s" % link.get("rowid")
            if src in job["tried"]:
                continue
            job["tried"].add(src)
            try:
                stream = ad.unlock(link["url"])
            except LinkDown:
                _log("enlace caído (%s)" % link.get("calidad"))
                continue
            except AllDebridError as e:
                if getattr(e, "transport", False):
                    # Corte de red transitorio en ESTE enlace: la
                    # cadena salta al siguiente en vez de morir
                    # (sup4-H1). El mensaje del error es fijo y no
                    # lleva la URL ni la clave (sup2-B2).
                    _log("fallo de red en un enlace: se prueba el "
                         "siguiente")
                    continue
                return ("error", str(e))
            if not stream or not stream.get("link"):
                continue
            if target is None or _tier(link.get("calidad")) <= target:
                ad.delete_history()
                _log("pre-terminación: %s (%s) tras %d intentos" %
                     (link.get("calidad"), link.get("audio"), job["idx"]))
                return ("play", stream["link"])
            job["alive_lower"].append({"link": link,
                                       "stream": stream["link"]})
            _log("vivo pero bajo la preferida: %s" % link.get("calidad"))
        if job["alive_lower"]:
            return self._selector_flow(job, ui, ad)
        return self._live_auto(job, ui, ad)

    # ---------------- selector por excepción ----------------
    def _selector_rows(self, job):
        rows = []
        if job["alive_lower"]:
            rows.append({"dest": "header", "titulo": "Palantir"})
            for ent in job["alive_lower"]:
                if ent.get("stream") == job.get("failed_url"):
                    continue    # ese stream ya falló al arrancar
                l = ent["link"]
                lab = l.get("calidad") or "?"
                al = _audio_label(l.get("audio"))
                rows.append({"dest": "row",
                             "titulo": "%s · %s" % (lab, al),
                             "nota": l.get("info") or "",
                             "payload": {"origen": "palantir", "ent": ent}})
        cands = [c for c in (job.get("live_cands") or [])
                 if "live:" + c["magnet"].split("btih:")[-1].split("&")[0].lower()
                 not in job["tried"]]
        if cands:
            rows.append({"dest": "header", "titulo": "En vivo"})
            import live
            qn = {0: "DV", 1: "HDR10+", 2: "HDR", 3: "4K", 4: "1080p",
                  5: "720p", 6: "SD"}
            for cand in cands[:6]:
                lab = qn.get(live._quality_rank(cand["name"]), "?")
                if live._is_spanish(cand["name"]):
                    lab += " · Castellano"
                else:
                    lab += " · Sin castellano"
                nota = []
                if cand.get("size"):
                    nota.append("%.1f GB" % (cand["size"] / 1e9))
                if cand.get("seeders"):
                    nota.append("%d semillas" % cand["seeders"])
                rows.append({"dest": "row", "titulo": lab,
                             "nota": " · ".join(nota),
                             "payload": {"origen": "vivo", "cand": cand}})
        return rows

    def _selector_flow(self, job, ui, ad):
        if self._live_enabled() and job.get("live_cands") is None:
            ui.set_phase("Buscando en vivo…")
            job["live_cands"] = self._live_candidates(job)
        pref = PREF_NOMBRE.get(_setting("calidad") or "0", "")
        sub = ("La calidad preferida (%s) no está viva en la base · "
               "elige un enlace" % pref) if pref else "Elige un enlace"
        while True:
            if ui.is_canceled():
                return ("abort",)
            rows = self._selector_rows(job)
            if not any(r.get("dest") == "row" for r in rows):
                return ("fail", "Sin enlaces disponibles")
            choice = ui.ask_selector(rows, "Elige un enlace", sub)
            if choice is None:
                return ("abort",)
            if choice.get("origen") == "palantir":
                return ("play", choice["ent"]["stream"])
            cand = choice["cand"]
            key = "live:" + cand["magnet"].split("btih:")[-1] \
                .split("&")[0].lower()
            job["tried"].add(key)
            ui.set_phase("Resolviendo enlace…")
            import live
            try:
                stream = live.resolve_magnet(
                    ad, cand["magnet"],
                    cancel=lambda: ui.is_canceled())
            except AllDebridError:
                stream = None
            if stream and stream.get("link"):
                ad.delete_history()
                return ("play", stream["link"])
            dialogs.notify("Ese enlace en vivo no está disponible ahora")

    # ---------------- capa en vivo automática ----------------
    def _live_auto(self, job, ui, ad):
        import live
        if not self._live_enabled():
            return ("fail", "Sin enlaces disponibles")
        # Reentradas (fallo al arrancar): los candidatos ya resueltos
        # están en job['tried'] y se saltan; se sigue con los demás.
        ui.set_phase("Buscando en vivo…")
        cands = job.get("live_cands")
        if cands is None:
            cands = self._live_candidates(job)
            job["live_cands"] = cands
        _log("capa en vivo automática: %d candidatos" % len(cands))
        for cand in cands[:4]:
            if ui.is_canceled():
                return ("abort",)
            key = "live:" + cand["magnet"].split("btih:")[-1] \
                .split("&")[0].lower()
            if key in job["tried"]:
                continue
            job["tried"].add(key)
            try:
                stream = live.resolve_magnet(
                    ad, cand["magnet"],
                    cancel=lambda: ui.is_canceled())
            except AllDebridError:
                stream = None
            if stream and stream.get("link"):
                ad.delete_history()
                _log("capa en vivo: enlace resuelto")
                return ("play", stream["link"])
        return ("fail", "Sin enlaces disponibles")

    # ---------------- arranque del stream ----------------
    def _start_stream(self, job, stream_url):
        row = job["row"] or {}
        job["stream_url"] = stream_url
        if job["kind"] == "serie" and self.vault is not None:
            job["next"] = self._next_episode(job["tmdb"],
                                             job["temporada"],
                                             job["episodio"])
        li = xbmcgui.ListItem(label=row.get("titulo") or "")
        li.setArt({"poster": img(row.get("poster"), "w500"),
                   "fanart": img(row.get("fondo"), "w1280"),
                   "thumb": img(row.get("poster"), "w500")})
        li.setInfo("video", {"title": row.get("titulo") or "",
                             "plot": row.get("plot") or "",
                             "year": int((row.get("fecha") or "0")[:4] or 0)})
        self._session_seq += 1
        seq = self._session_seq
        state = {"ended": False, "started": False, "t0": time.time(),
                 "max_pos": 0.0}
        job["state"] = state
        player = _Watcher()
        player._on_started = lambda: self._ev_started(job, player, state)
        player._on_end = lambda fin: self._ev_end(job, player, state,
                                                  fin, seq)
        player._on_failed = lambda: self._ev_failed(job, state)
        player.play(stream_url, li)
        t = threading.Thread(target=self._progress_loop,
                             args=(job, player, state))
        t.daemon = True
        t.start()
        self._preload_run_async(job)
        return True

    def _ev_started(self, job, player, state):
        state["started"] = True
        try:
            total = player.getTotalTime()
            # «opened»: el stream llegó a abrirse de verdad (hay
            # duración). Kodi anuncia Started antes de abrir, así que
            # sin esto un enlace caído parece una reproducción normal.
            state["opened"] = total > 0
            pct = job.get("resume_pct") or 0
            if pct and 1 < pct < 97 and total > 0:
                player.seekTime(total * pct / 100.0)
        except Exception:
            pass
        # Reanudar instantáneo la próxima vez, dentro de la sesión:
        # SOLO si el stream se abrió de verdad. Kodi anuncia Started
        # antes de abrir y el aviso puede llegar incluso después del
        # Stopped del fallo; cachear ahí guardaría la URL muerta y la
        # continuación la repetiría en vez de pasar al siguiente.
        if job.get("stream_url") and state.get("opened"):
            self._cache[self._key(job)] = job["stream_url"]
        try:
            import trakt
            trakt.scrobble_start(job["kind"], job["tmdb"],
                                 job.get("temporada"), job.get("episodio"),
                                 job.get("resume_pct") or 0)
        except Exception:
            pass

    def _ev_end(self, job, player, state, finished, seq):
        if state.get("ended"):
            return
        state["ended"] = True
        try:
            total = player.getTotalTime()
            cur = player.getTime()
        except Exception:
            total, cur = 0, 0
        # Al parar (y en muchos aparatos también al terminar), Kodi
        # ya ha desmontado el reproductor y getTotalTime()/getTime()
        # devuelven 0 — el mismo hecho que el arreglo del stop de la
        # 0.4.0 documentó para la firma de «nunca abrió». Sin relevo,
        # el porcentaje salía 0 y la regla de visto al 88 % no se
        # disparaba NUNCA al parar: ni guardado local ni scrobble, y
        # el capítulo quedaba «a medias» para siempre (defecto
        # 0.5.2, caso Outlander T2E8). El relevo es lo que el
        # vigilante vio durante la reproducción: la duración
        # (last_total, mantenida por _progress_loop) y la posición
        # más avanzada (max_pos). En un stream que nunca abrió,
        # ambos valen 0 y la firma de abajo queda intacta.
        total = total or state.get("last_total") or 0
        cur = max(cur or 0, state.get("max_pos") or 0)
        pct = (cur * 100.0 / total) if total > 0 else 0
        jugado = max(time.time() - state["t0"], state.get("max_pos") or 0,
                     cur or 0)
        if not finished and not state.get("opened") \
                and not (state.get("max_pos") or 0) \
                and total <= 0 and cur <= 0:
            # El stream nunca llegó a abrirse (enlace caído al
            # arrancar): Kodi lo anuncia como Started y después
            # Stopped, SIN onPlayBackFailed. Es un fallo de arranque:
            # la cadena continúa en silencio con el siguiente enlace
            # y no se registra nada en el historial. La evidencia de
            # «nunca abrió» ha de ser COMPLETA: ni el vigilante vio
            # duración/posición en ningún sondeo (opened lo mantiene
            # también _progress_loop) ni se registró posición alguna
            # (max_pos). Sin esto, una parada del usuario tras ver
            # el contenido se confundía con un fallo de arranque —
            # getTotalTime() devuelve 0 tanto en el aviso de Started
            # como ya parado el reproductor — y la cadena relanzaba
            # la reproducción tras el stop.
            self._continue_chain(job, state)
            return
        fin = bool(finished or (total > 0 and pct >= VISTO_PCT))
        try:
            if fin:
                job["save"](100.0, int(total) if total else None, True)
                try:
                    import trakt
                    trakt.scrobble_stop(job["kind"], job["tmdb"],
                                        job.get("temporada"),
                                        job.get("episodio"),
                                        pct if total > 0 else 100.0)
                except Exception:
                    pass
            elif jugado >= MIN_REGISTRO_SEG and pct > 1:
                job["save"](pct, int(total) if total else None, False)
                try:
                    import trakt
                    trakt.scrobble_progress(job["kind"], job["tmdb"],
                                            job.get("temporada"),
                                            job.get("episodio"), pct)
                except Exception:
                    pass
            # Menos de 1 minuto y sin terminar: no se registra nada
            # (ni progreso, ni scrobble): no ensucia el historial.
        except Exception:
            pass
        if finished and job["kind"] == "serie" and job.get("next"):
            t = threading.Thread(target=self._offer_next,
                                 args=(job, seq))
            t.daemon = True
            t.start()

    def _ev_failed(self, job, state):
        """El stream no llegó a arrancar (onPlayBackFailed antes de
        abrirse): la cadena continúa en silencio con el siguiente
        enlace. Si el stream ya se había abierto, no es un fallo de
        arranque y no se continúa."""
        if state.get("ended") or state.get("opened"):
            return
        state["ended"] = True
        self._continue_chain(job, state)

    def _continue_chain(self, job, state):
        """Continuación tras un fallo de arranque: se descarta la URL
        que falló y la cadena se relanza donde iba (máx. 3 veces)."""
        self._cache.pop(self._key(job), None)
        job["failed_url"] = job.get("stream_url")
        if job.get("start_fails", 0) >= 3:
            _log("fallo de arranque sin más continuación")
            return
        job["start_fails"] = job.get("start_fails", 0) + 1
        _log("fallo al arrancar: la cadena continúa (intento %d)"
             % job["start_fails"])

        def again():
            mon = xbmc.Monitor()
            mon.waitForAbort(1.2)
            # Kodi muestra su propio diálogo modal «Playback failed»
            # cuando un stream no abre, y el diálogo de ocupado puede
            # sobrevivirlo unos instantes; si alguno siguiera activo,
            # la reactivación de la pantalla de carga sería rechazada
            # («active modal dialogs») y la continuación se perdería:
            # se cierra el de fallo y se espera a que no quede modal.
            try:
                xbmc.executebuiltin("Dialog.Close(12002)")
            except Exception:
                pass
            for _ in range(40):
                if mon.abortRequested():
                    return
                try:
                    modal = xbmc.getCondVisibility(
                        "Window.IsActive(12002)") or \
                        xbmc.getCondVisibility("Window.IsActive(10138)")
                except Exception:
                    modal = False
                if not modal:
                    break
                mon.waitForAbort(0.25)
            try:
                self._launch(job)
            except Exception as e:
                _log("continuación fallida (%s)" % type(e).__name__)

        t = threading.Thread(target=again)
        t.daemon = True
        t.start()

    def _progress_loop(self, job, player, state):
        mon = xbmc.Monitor()
        ticks = 0
        while not state.get("ended") and not mon.abortRequested():
            # Primer sondeo a ~1 s: la evidencia de apertura llega
            # pronto; el resto, cada 5 s como siempre.
            if mon.waitForAbort(1 if ticks == 0 else 5):
                break
            ticks += 1
            try:
                if not player.isPlaying():
                    continue
                total = player.getTotalTime()
                cur = player.getTime()
                if total > 0 or cur > 0:
                    # El stream SÍ se abrió y está sonando. opened no
                    # puede depender solo del sondeo de onPlayBack
                    # Started: ahí getTotalTime() aún devuelve 0 en
                    # streams que después reproducen sin problema.
                    state["opened"] = True
                if total > 0:
                    # Duración vista durante la reproducción: al
                    # parar, el reproductor ya no la informa y
                    # _ev_end la necesita para el % de visto (0.5.2).
                    state["last_total"] = total
                if cur and cur > (state.get("max_pos") or 0):
                    state["max_pos"] = cur
                if ticks % 3 == 0 and total > 0:
                    pct = cur * 100.0 / total
                    if time.time() - state["t0"] >= MIN_REGISTRO_SEG \
                            and 1 < pct < 97:
                        job["save"](pct, int(total), False)
            except Exception:
                break

    # ---------------- siguiente episodio ----------------
    def _next_episode(self, tmdb, temporada, episodio):
        try:
            seasons = self.vault.seasons(tmdb)
            eps = [x["episodio"] for x in
                   self.vault.episodes(tmdb, temporada)]
            nxt = [x for x in eps if x > episodio]
            if nxt:
                return (temporada, nxt[0])
            later = [s["temporada"] for s in seasons
                     if s["temporada"] > temporada]
            if later:
                eps2 = self.vault.episodes(tmdb, later[0])
                if eps2:
                    return (later[0], eps2[0]["episodio"])
        except Exception:
            pass
        return None

    def _preload_run_async(self, job):
        """Precarga del primer enlace del siguiente episodio: se
        resuelve en segundo plano mientras se ve el actual, solo en
        memoria y solo con la bóveda abierta."""
        if job["kind"] != "serie" or self.vault is None:
            return
        nxt = job.get("next")
        if not nxt:
            return
        t2, e2 = nxt

        def run():
            try:
                if not self.vault.unlocked:
                    return
                links = self.vault.links_ep(job["tmdb"], t2, e2)
                cands = _order_chain(links)
                if not cands:
                    return
                ad = AllDebrid(_setting("alldebrid_apikey"))
                for link in cands[:6]:
                    if not self.vault.unlocked:
                        self._preload = None
                        return
                    src = "vault:%s" % link.get("rowid")
                    try:
                        stream = ad.unlock(link["url"])
                    except LinkDown:
                        continue
                    except AllDebridError:
                        return
                    if stream and stream.get("link"):
                        self._preload = {
                            "key": (job["tmdb"], t2, e2),
                            "stream": stream["link"], "src": src,
                            "gen": self.vault.generation}
                        _log("precarga lista: T%d E%d (%s)" %
                             (t2, e2, link.get("calidad")))
                        return
            except Exception as e:
                # Solo el TIPO de la excepción (sup2-B2, defensa en
                # profundidad): el texto podría llevar una URL.
                _log("precarga fallida (%s)" % type(e).__name__)

        t = threading.Thread(target=run)
        t.daemon = True
        t.start()

    def _offer_next(self, job, seq):
        """Al terminar un episodio: diálogo propio «Siguiente · Tx Ey»
        con el botón enfocado y sin cuenta atrás. OK arranca al
        instante con la precarga si sigue válida."""
        t2, e2 = job["next"]
        mon = xbmc.Monitor()
        probe = xbmc.Player()
        for _ in range(20):
            if mon.waitForAbort(0.3) or not probe.isPlaying():
                break
        if mon.waitForAbort(0.8):
            return
        if seq != self._session_seq:
            return        # ya hay otra reproducción en marcha
        row = job["row"] or {}
        pre = self._preload
        # La precarga solo vale dentro de la MISMA generación de
        # sesión: un bloqueo intermedio la invalida (sup4-H2).
        listo = bool(pre and pre.get("key") == (job["tmdb"], t2, e2)
                     and self.vault is not None and self.vault.unlocked
                     and pre.get("gen") == self.vault.generation)
        from playui import NextEpWindow
        win = NextEpWindow(
            "nextep.xml", self.addon_path, "Default", "1080i",
            etiqueta="Siguiente · T%d E%d" % (t2, e2),
            titulo=(job["live_args"].get("titulo") or ""),
            nota="Listo para reproducir" if listo else "",
            fondo=row.get("fondo"))
        win.doModal()
        ok = win.result
        del win
        if not ok:
            return
        if listo:
            job2 = self._episode_job(job["tmdb"], t2, e2)
            if job2 is not None:
                self._reset_job_state(job2)
                job2["tried"].add(pre["src"])
                self._preload = None
                _log("siguiente episodio: arranque con la precarga")
                self._start_stream(job2, pre["stream"])
                return
        self.play_episode(job["tmdb"], t2, e2)
