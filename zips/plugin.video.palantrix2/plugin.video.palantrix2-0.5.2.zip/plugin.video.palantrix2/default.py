# -*- coding: utf-8 -*-
"""PalAntriX — arranque: asegura catálogo + bóveda cifrada y abre la Home.

El catálogo (metadatos públicos) viaja en un zip; la bóveda de enlaces viaja
cifrada (AES-256-GCM, SPEC §10) en partes y NUNCA se escribe en claro: en el
disco del dispositivo solo queda el fichero cifrado, y los enlaces se
descifran en memoria, de uno en uno, al reproducir.
"""
import json
import os
import sys

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo("path")
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
CAT_FILE = os.path.join(PROFILE, "catalogo.db")
VAULT_FILE = os.path.join(PROFILE, "boveda.db")
VER_FILE = os.path.join(PROFILE, "catalog_version.txt")
PKG_URL = "https://antrix.pages.dev/palantrix_pkg.json"

sys.path.append(os.path.join(ADDON_PATH, "resources", "lib"))


def _local_version():
    try:
        with open(VER_FILE) as f:
            return f.read().strip()
    except Exception:
        return None


def ensure_files():
    have = (os.path.exists(CAT_FILE) and os.path.getsize(CAT_FILE) > 1000000
            and os.path.exists(VAULT_FILE) and os.path.getsize(VAULT_FILE) > 1000000)
    import requests
    manifest = None
    try:
        r = requests.get(PKG_URL, timeout=15)
        manifest = json.loads(r.text)
    except Exception:
        manifest = None
    if manifest is None:
        return have  # sin conexión: vale lo que haya en disco
    remote = str(manifest.get("version") or "")
    if have and _local_version() == remote:
        return True
    if "complete" in manifest and not manifest.get("complete"):
        # Solo se instalan/mezclan fotos COMPLETAS de la base; un
        # paquete parcial no debe tocar un dispositivo (sup3-B1).
        return have
    if not os.path.isdir(PROFILE):
        os.makedirs(PROFILE)
    dlg = xbmcgui.DialogProgress()
    dlg.create("PalAntriX", "Cargando…")
    tmp_zip = os.path.join(PROFILE, "catalogo.zip")
    tmp_vault = os.path.join(PROFILE, "boveda.tmp")
    ok = False
    try:
        # Descarga compartida con Servicios: verifica cada parte
        # (longitud siempre; tamaño y sha256 si el manifiesto los trae).
        from update import download_parts, extract_catalog_zip, \
            merge_vault, stamp_check
        if download_parts(manifest["catalog"], tmp_zip, dlg,
                          "Cargando…", 0, 40,
                          manifest=manifest):
            dlg.update(45, "Cargando…")
            # Del zip SOLO puede salir catalogo.db (sup2-B1): ninguna
            # otra entrada toca el perfil jamás.
            extract_catalog_zip(tmp_zip, PROFILE)
            os.remove(tmp_zip)
            if download_parts(manifest["vault"], tmp_vault, dlg,
                              "Cargando…", 45, 50,
                              manifest=manifest):
                dlg.update(97, "Cargando…")
                if os.path.exists(VAULT_FILE):
                    # Corrección Fase 3: jamás sustituir la bóveda de un
                    # dispositivo ya instalado (dentro viven su maestra
                    # y sus accesos): se mezclan las filas de enlaces del
                    # paquete sin tocar la tabla wraps (update.merge_vault).
                    merge_vault(VAULT_FILE, tmp_vault)
                    os.remove(tmp_vault)
                else:
                    os.rename(tmp_vault, VAULT_FILE)
                try:
                    stamp_check(PROFILE)
                except Exception:
                    pass
                with open(VER_FILE, "w") as f:
                    f.write(remote)
                dlg.update(100, "Cargando…")
                ok = True
    except Exception as e:
        xbmc.log("PalAntriX: error descargando el paquete: %s" % e, xbmc.LOGERROR)
        ok = False
    finally:
        dlg.close()
        # Higiene (sup2-M6): los temporales no quedan en el perfil ni
        # siquiera cuando la descarga/mezcla falla a mitad.
        for tmp in (tmp_zip, tmp_vault):
            try:
                if os.path.exists(tmp):
                    os.remove(tmp)
            except Exception:
                pass
    if ok:
        return os.path.exists(CAT_FILE) and os.path.exists(VAULT_FILE)
    if have:
        # Corrección 0.3.1: una actualización fallida (red, disco o
        # mezcla) NUNCA deja al usuario fuera de la app si ya tiene una
        # base usable: se abre con la anterior y se avisa con una
        # notificación que no bloquea. La actualización se reintentará
        # en el próximo arranque o desde Servicios.
        xbmc.log("PalAntriX: actualización a v%s fallida; se abre con "
                 "la base anterior (v%s)" % (remote, _local_version()),
                 xbmc.LOGWARNING)
        try:
            xbmcgui.Dialog().notification(
                "PalAntriX",
                "No se ha podido actualizar la base; sigues con la anterior",
                xbmcgui.NOTIFICATION_WARNING, 6000)
        except Exception:
            pass
        return True
    xbmcgui.Dialog().ok("PalAntriX", "No se ha podido descargar el catálogo. Revisa la conexión e inténtalo de nuevo.")
    return False


def main():
    # Pancarta de arranque (0.3.1): entorno y versiones en el registro,
    # para que cualquier log futuro diga qué corría y con qué datos.
    try:
        xbmc.log("PalAntriX %s: arranque (Kodi %s, SO %s, datos locales v%s)"
                 % (ADDON.getAddonInfo("version"),
                    xbmc.getInfoLabel("System.BuildVersion"),
                    os.uname(),
                    _local_version() or "—"), xbmc.LOGINFO)
    except Exception:
        pass
    try:
        _main_inner()
    except Exception:
        # Nunca el aviso genérico de Kodi sin más (0.3.1): el traceback
        # entero queda en el registro y el usuario ve un aviso propio.
        import traceback
        xbmc.log("PalAntriX: error al abrir la app:\n%s"
                 % traceback.format_exc(), xbmc.LOGERROR)
        try:
            xbmcgui.Dialog().ok(
                "PalAntriX",
                "Ha habido un error al abrir la app. "
                "El detalle ha quedado en el registro de Kodi.")
        except Exception:
            pass


def _main_inner():
    # Higiene (SPEC §10): la 0.1.0 dejaba una base con enlaces en claro;
    # si queda ese fichero de una instalación anterior, se elimina.
    legacy = os.path.join(PROFILE, "palantrix.db")
    if os.path.exists(legacy):
        try:
            os.remove(legacy)
        except Exception:
            pass
    if not ensure_files():
        return
    from db import Catalog
    from progress import UserData
    from player import Playback
    from vault import Vault
    from home import HomeWindow
    user_file = os.path.join(PROFILE, "userdata.db")
    userdata = UserData(user_file, CAT_FILE)
    catalog = Catalog(CAT_FILE, user_file, VAULT_FILE)
    vault = Vault(VAULT_FILE)
    playback = Playback(catalog, userdata, vault,
                        addon_path=ADDON_PATH, profile=PROFILE)
    # Kodi abre la ventana de vídeos con el diálogo «ocupado» modal mientras
    # el plugin no cierre el directorio: sin soltarlo, ningún diálogo ni la
    # ventana propia pueden activarse («refused… active modal dialogs»).
    try:
        handle = int(sys.argv[1])
    except Exception:
        handle = -1
    if handle >= 0:
        try:
            xbmcplugin.endOfDirectory(handle, succeeded=False)
        except Exception:
            pass
        mon = xbmc.Monitor()
        for _ in range(30):
            if not xbmc.getCondVisibility("Window.IsActive(10138)"):
                break
            if mon.waitForAbort(0.1):
                break
    # Accesos remotos (0.4.0): descarga silenciosa del sobre de la
    # lista y de las activaciones a la caché del perfil, en segundo
    # plano y sin bloquear jamás la apertura (lección 0.3.1). La lista
    # solo se verifica y se aplica al desbloquear (hace falta la DEK),
    # en remote.post_unlock_sync.
    try:
        import threading
        import remote
        t = threading.Thread(target=remote.prefetch, args=(PROFILE,))
        t.daemon = True
        t.start()
    except Exception:
        pass
    # D1 (mapa aprobado): la bóveda NO se pide al arrancar. Navegar es libre
    # con la bóveda bloqueada; el desbloqueo se pide solo al reproducir
    # (player.py) o desde Servicios/Ajustes.
    win = HomeWindow("home.xml", ADDON_PATH, "Default", "1080i",
                     catalog=catalog, userdata=userdata, playback=playback,
                     vault=vault, addon_path=ADDON_PATH, profile=PROFILE)
    win.doModal()
    vault.lock()
    vault.close()
    catalog.close()
    userdata.close()
    del win
    xbmc.executebuiltin("ActivateWindow(home)")


if __name__ == "__main__":
    main()
