# -*- coding: utf-8 -*-
"""Navegación compartida: abrir Buscar / Ajustes desde cualquier ventana."""

def open_search(win, amb=None):
    from search import SearchWindow
    w = SearchWindow("search.xml", win.addon_path, "Default", "1080i",
                     catalog=win.catalog, userdata=getattr(win, "userdata", None),
                     playback=getattr(win, "playback", None), vault=getattr(win, "vault", None), addon_path=win.addon_path,
                     profile=getattr(win, "profile", ""), ambito=amb)
    w.doModal()
    del w

def open_settings(win):
    from settings_ui import SettingsWindow
    w = SettingsWindow("settings.xml", win.addon_path, "Default", "1080i",
                       catalog=win.catalog, vault=getattr(win, "vault", None), profile=getattr(win, "profile", ""),
                       userdata=getattr(win, "userdata", None),
                       playback=getattr(win, "playback", None),
                       addon_path=win.addon_path)
    w.doModal()
    del w

def open_services(win):
    from services import ServicesWindow
    w = ServicesWindow("services.xml", win.addon_path, "Default", "1080i",
                       catalog=win.catalog, userdata=getattr(win, "userdata", None),
                       playback=getattr(win, "playback", None), vault=getattr(win, "vault", None),
                       addon_path=win.addon_path, profile=getattr(win, "profile", ""),
                       screen="root")
    w.doModal()
    del w

# ---------------------------------------------------------------------------
# Botón de casa (812, §1 punto 10): volver al menú principal desde
# cualquier pantalla. La ventana donde se clica se cierra y deja la
# orden puesta; cada ventana de la pila que se reactiva la ve y se
# cierra también, hasta llegar a la principal, que la consume.
# ---------------------------------------------------------------------------
_go_home = {"pending": False}


def request_home(win):
    _go_home["pending"] = True
    win.close()


def unwind_home(win):
    """Al reactivarse una ventana con la orden de ir a la principal:
    se cierra y devuelve True (la orden sigue viva para la de abajo)."""
    if _go_home["pending"]:
        win.close()
        return True
    return False


def clear_home():
    _go_home["pending"] = False


def topbar_click(win, control_id):
    if control_id == 812:
        request_home(win)
        return True
    if control_id == 810:
        open_search(win)
        return True
    if control_id == 811:
        open_settings(win)
        return True
    return False
