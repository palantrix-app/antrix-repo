# -*- coding: utf-8 -*-
"""Diálogos de desbloqueo de la bóveda (teclado oculto de Kodi)."""
import xbmc
import xbmcgui

import dialogs


def _ask(heading, hidden=True):
    """Entrada de texto/PIN con el TECLADO PROPIO de la casa (§7):
    sustituye a xbmc.Keyboard, que pintaba el teclado de Kodi."""
    val = dialogs.ask_text(heading, hidden=hidden)
    if val is None:
        return None
    return val.strip()


def _notify(text):
    dialogs.notify(text)


def verify_master(vault):
    """Pide la contraseña maestra ACTUAL y la verifica contra su wrap
    (sin tocar la sesión). True si coincide; si no, avisa y False.
    Es el paso previo obligatorio al CAMBIO de maestra (sup5-B1)."""
    pw = _ask("Tu contraseña maestra actual")
    if pw is None:
        return False
    if vault.verify_master(pw):
        return True
    _notify("La contraseña actual no coincide")
    return False


def setup_master(vault):
    """Crea la contraseña maestra (doble entrada). True si se creó."""
    pw1 = _ask("Crea tu contraseña maestra (solo tuya, no se comparte)")
    if not pw1:
        return False
    if len(pw1) < 4:
        _notify("La maestra necesita al menos 4 caracteres")
        return False
    pw2 = _ask("Repite la contraseña maestra")
    if pw2 != pw1:
        _notify("Las dos entradas no coinciden")
        return False
    if vault.create_master(pw1):
        _notify("Maestra creada · la instalación queda cerrada")
        return True
    return False


def prompt_unlock(vault, allow_setup=True, profile=None):
    """Pide PIN/contraseña hasta acertar (máx. 3 intentos) o cancelar.

    Con `profile`, tras un desbloqueo correcto se sincronizan los
    accesos remotos en silencio (remote.post_unlock_sync): es el único
    momento en que existe la DEK para verificar la firma de la lista.
    Si el acceso propio de un aparato invitado fue revocado, la sesión
    se bloquea y se avisa con honestidad; la sincronización jamás
    impide desbloquear por un fallo de red."""
    if vault.unlocked:
        return True
    import remote
    from vault import CryptoUnavailable
    for _ in range(3):
        secret = _ask("PalAntriX bloqueado · tu PIN o contraseña")
        if secret is None:
            return False
        try:
            unlocked = vault.unlock(secret)
        except CryptoUnavailable:
            # Sin módulo de cifrado no hay bóveda en este aparato
            # (corrección 0.4.0-C1): aviso claro y salida limpia,
            # sin propagar la excepción ni matar la app.
            dialogs.ok(
                "PalAntriX",
                "Este aparato no puede cargar el módulo de cifrado; "
                "la bóveda no está disponible aquí.")
            return False
        if unlocked:
            if vault.mode == "bootstrap" and allow_setup:
                # Primera instalación: la maestra es obligatoria.
                if not setup_master(vault):
                    vault.lock()
                    _notify("Sin maestra no se puede reproducir · créala en Ajustes")
                    return False
            if profile:
                estado = remote.post_unlock_sync(vault, profile)
                if estado == "own_revoked":
                    dialogs.ok(
                        "PalAntriX",
                        "Tu acceso ha sido retirado por el "
                        "administrador. Este dispositivo ya no puede "
                        "abrir la bóveda.")
                    return False
            return True
        # En un invitado cuyo acceso fue revocado (detectado en una
        # sincronización anterior), el PIN ya no existe en el aparato:
        # el aviso honesto sustituye al «incorrecto» genérico.
        if profile and remote.is_guest(profile) \
                and remote.take_revocado_aviso(profile):
            dialogs.ok(
                "PalAntriX",
                "Tu acceso ha sido retirado por el administrador. "
                "Este dispositivo ya no puede abrir la bóveda.")
            return False
        _notify("PIN o contraseña incorrectos")
    return False
