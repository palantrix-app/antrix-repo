# -*- coding: utf-8 -*-
"""Ventana Sección (1301) — catálogo completo en rejilla con carga por lotes.

Fase 2: memoria de posición exacta al volver de una ficha, Top 10 numerado
en Populares, salto de página (Channel +/− / PgUp/PgDn), indicador de
posición «n / total», salto por letra sin salir de la rejilla A–Z, sagas
con progreso y foco en el siguiente título no visto, y las hojas de la
cola Up Next (seguimiento / sin terminar) con reproducción directa (D5)
y menú contextual de la casa.
"""
import xbmc
import xbmcgui

from db import img

CHIPS_ID = 200
GRID_ID = 210
LBL_TITULO = 920
LBL_COUNT = 921
IMG_FANART = 9000
BTN_BUSCAR = 810
BTN_AJUSTES = 811
BTN_CASA = 812
BATCH = 60
COLS = 6            # 1728 px de panel / 264 px por celda
PAGE = COLS * 2     # dos filas visibles por «página»

ACTION_MOVE_LEFT = 1
ACTION_PAGE_UP = 5
ACTION_PAGE_DOWN = 6
# Canal +/−: medido en banco (JSON-RPC y ButtonTranslator de Kodi 20):
# «channelup» llega como 184 y «channeldown» como 185 (el enum no es
# 185/186 como se asumió al principio). Se acepta también 186 como
# «siguiente» por compatibilidad con mandos que lo emitan.
ACTION_CHANNEL_UP = 184
ACTION_CHANNEL_DOWN = 185
ACTION_CHANNEL_DOWN_ALT = 186
ACTION_CONTEXT = 117

def fmt_num(n):
    return "{:,}".format(n).replace(",", ".")

class SectionWindow(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        super(SectionWindow, self).__init__(*args)
        self.catalog = kwargs.get("catalog")
        self.userdata = kwargs.get("userdata")
        self.playback = kwargs.get("playback")
        self.vault = kwargs.get("vault")
        self.addon_path = kwargs.get("addon_path")
        self.profile = kwargs.get("profile", "")
        self.kind = kwargs.get("kind", "pelicula")
        # Fase 1 (menús de texto): la rejilla puede venir ya filtrada por la
        # especificación de un nodo del mapa (menus.py). Sin spec, se comporta
        # como siempre (chips de la sección).
        self.spec = kwargs.get("spec")
        self.titulo = kwargs.get("titulo")
        self.mode = "spec" if self.spec else "todo"
        self.sub = None          # None | "generos" | "ano"
        self.genero = None
        self.year = None
        self.coleccion_id = None
        self.loaded = 0
        self.total = 0
        self._rows = []          # filas cargadas, en paralelo a la rejilla
        self._grid_pos = 0       # memoria de foco exacta de la rejilla
        self._inited = False
        self._fanart_actual = ""

    # ---------------- fondo (regla §1.8) ----------------
    def _sync_fanart(self):
        """Fondo propio salvo cuando el foco está sobre una miniatura
        concreta de la rejilla: entonces manda SU fanart."""
        fondo = ""
        if self.getFocusId() == GRID_ID \
                and 0 <= self._grid_pos < len(self._rows):
            fondo = img(self._rows[self._grid_pos].get("fondo"), "w1280")
        if fondo != self._fanart_actual:
            self._fanart_actual = fondo
            try:
                self.getControl(IMG_FANART).setImage(fondo, False)
            except Exception:
                pass

    # ---------------- chips ----------------
    def _main_chips(self):
        # «Seguir viendo» NO es menú ni categoría (corrección de Àngel):
        # es solo el rail de la Home, con su título justo encima de las miniaturas.
        if self.kind == "pelicula":
            return ["Todo", "Novedades", "Géneros", "Año", "Más vistas", "Colecciones", "A–Z"]
        return ["Todo", "Novedades", "Géneros", "Año", "Más vistas", "A–Z"]

    def _fill_chips(self, labels, active_idx=0):
        lst = self.getControl(CHIPS_ID)
        lst.reset()
        items = []
        for i, lab in enumerate(labels):
            li = xbmcgui.ListItem(label=lab)
            li.setProperty("chip", lab)
            if i == active_idx:
                li.setLabel("[COLOR FFFF7800]%s[/COLOR]" % lab)
            items.append(li)
        lst.addItems(items)

    def _show_main_chips(self):
        chips = self._main_chips()
        active = 0
        mode_chip = {"todo": "Todo", "novedades": "Novedades", "generos": "Géneros",
                     "ano": "Año", "vistas": "Más vistas", "colecciones": "Colecciones",
                     "az": "A–Z"}
        want = mode_chip.get(self.mode, "Todo")
        if want in chips:
            active = chips.index(want)
        self._fill_chips(chips, active)

    # ---------------- rejilla ----------------
    def _query(self, offset, limit):
        cat = self.catalog
        if self.spec:
            return cat.spec_rows(self.spec, offset, limit)
        if self.mode == "colecciones" and not self.coleccion_id:
            return cat.colecciones(offset, limit)
        if self.coleccion_id:
            rows = cat.coleccion(self.coleccion_id)
            return rows[offset:offset + limit]
        if self.mode == "seguimiento":
            return cat.en_seguimiento(offset, limit)
        order = {"todo": "rating", "novedades": "updated", "vistas": "rating",
                 "az": "titulo", "generos": "updated", "ano": "fecha"}.get(self.mode, "updated")
        return cat.grid(self.kind, offset=offset, limit=limit, genero=self.genero,
                        year=self.year, order=order)

    def _count(self):
        cat = self.catalog
        if self.spec:
            return cat.spec_count(self.spec)
        if self.mode == "colecciones" and not self.coleccion_id:
            return cat.colecciones_count()
        if self.coleccion_id:
            return len(cat.coleccion(self.coleccion_id))
        if self.mode == "seguimiento":
            return cat.en_seguimiento_count()
        return cat.grid_count(self.kind, genero=self.genero, year=self.year)

    def _es_upnext(self):
        return bool(self.spec) and self.spec.get("tipo") in ("seguimiento", "sin_terminar")

    def _item(self, row, idx=0):
        if row.get("_coleccion") or (self.mode == "colecciones" and not self.coleccion_id
                                     and not self.spec):
            li = xbmcgui.ListItem(label=row.get("titulo") or "")
            li.setLabel2("%d películas" % (row.get("num") or 0))
            li.setArt({"poster": img(row.get("poster"), "w500"),
                       "fanart": img(row.get("fondo"), "w1280")})
            li.setProperty("coleccion", str(row.get("id")))
            li.setProperty("titulo", row.get("titulo") or "")
            return li
        li = xbmcgui.ListItem(label=row.get("titulo") or "")
        if row.get("label2"):
            # fila de la cola Up Next: nombra episodio y pendientes
            li.setLabel2(row["label2"])
        else:
            li.setLabel2((row.get("fecha") or "")[:4])
        li.setArt({"poster": img(row.get("poster"), "w500"),
                   "fanart": img(row.get("fondo"), "w1280")})
        li.setProperty("tmdb", str(row.get("tmdb") or ""))
        li.setProperty("kind", row.get("kind") or self.kind)
        li.setProperty("titulo", row.get("titulo") or "")
        if row.get("nuevo") or self.catalog.es_nuevo(
                row.get("kind") or self.kind, row.get("tmdb")):
            li.setProperty("nuevo", "1")
        if self.spec and self.spec.get("order") == "populares" and idx < 10:
            # Top 10 numerado DENTRO de la lista (mapa aprobado, D2)
            li.setProperty("rank", str(idx + 1))
        if row.get("temporada") is not None and row.get("kind") == "serie":
            # D5: esta fila ES un episodio concreto; OK lo reproduce
            li.setProperty("play_t", str(row["temporada"]))
            li.setProperty("play_e", str(row["episodio"]))
        elif row.get("kind") == "pelicula" and self._es_upnext():
            li.setProperty("play_movie", "1")
        return li

    def _load_batch(self, first=False):
        rows = self._query(self.loaded, BATCH)
        if not rows:
            return
        base = self.loaded
        items = [self._item(r, base + i) for i, r in enumerate(rows)]
        grid = self.getControl(GRID_ID)
        if first:
            grid.reset()
            self._rows = []
        grid.addItems(items)
        self._rows += rows
        self.loaded += len(rows)

    # ---------------- contador / posición / saga ----------------
    def _es_coleccion(self):
        return bool(self.spec) and self.spec.get("tipo") == "coleccion"

    def _saga_progreso(self):
        """(vistas, total) de la saga abierta, desde el userdata."""
        rows = self.catalog.coleccion(self.spec.get("coleccion"))
        mapa = self.catalog.vistos_pelis_mapa()
        vistas = 0
        for r in rows:
            v = mapa.get(r["tmdb"]) or {}
            if (v.get("playcount") or 0) > 0 or (v.get("progress") or 0) >= 97:
                vistas += 1
        return vistas, len(rows)

    def _saga_foco(self):
        """Índice del siguiente título NO visto de la saga (0 si no hay)."""
        rows = self.catalog.coleccion(self.spec.get("coleccion"))
        mapa = self.catalog.vistos_pelis_mapa()
        for i, r in enumerate(rows):
            v = mapa.get(r["tmdb"]) or {}
            if not ((v.get("playcount") or 0) > 0 or (v.get("progress") or 0) >= 97):
                return i
        return 0

    def _update_count(self):
        if self._es_coleccion():
            vistas, total = self._saga_progreso()
            self.getControl(LBL_COUNT).setLabel(
                "%d de %d vistas" % (vistas, total))
            return
        self.getControl(LBL_COUNT).setLabel(
            "%s / %s" % (fmt_num(self._grid_pos + 1) if self.total else "0",
                         fmt_num(self.total)))

    def _reload(self, keep=False):
        pos_prev = self._grid_pos
        self.loaded = 0
        self.total = self._count()
        self._load_batch(first=True)
        if self._es_coleccion():
            foco = self._saga_foco()
            while self.loaded <= foco and self.loaded < self.total:
                self._load_batch()
            self._grid_pos = foco
            if self.total:
                self.getControl(GRID_ID).selectItem(foco)
        elif keep and self.total:
            self._grid_pos = min(pos_prev, self.total - 1)
            while self.loaded <= self._grid_pos and self.loaded < self.total:
                self._load_batch()
            self.getControl(GRID_ID).selectItem(self._grid_pos)
        else:
            self._grid_pos = 0
        self._update_count()

    # ---------------- ventana ----------------
    def onInit(self):
        if self._inited:
            from nav import unwind_home
            if unwind_home(self):
                return
            # Reactivación tras cerrarse una ventana hija (ficha, otra
            # sección): la rejilla sigue cargada; se restaura la posición
            # exacta en vez de recargar desde cero, y el foco vuelve al
            # CONTENEDOR del que se salió (chips o rejilla, sup1-M16).
            try:
                if self.total:
                    self.getControl(GRID_ID).selectItem(
                        min(self._grid_pos, self.total - 1))
                self.setFocusId(getattr(self, "_focus_ctl", None) or GRID_ID)
                self._update_count()
            except Exception:
                pass
            return
        self._inited = True
        self.getControl(LBL_TITULO).setLabel(
            self.titulo or ("Películas" if self.kind == "pelicula" else "Series"))
        if self.spec:
            # Con spec: «‹ Volver» + la exploración de la casa (Géneros,
            # A–Z, Año, Calidad) para el tipo del bloque (§2b/§2c: ya no
            # son bloques del hub, viven aquí).
            chips = ["‹ Volver"]
            if (self.spec.get("kind") or self.kind) in ("pelicula", "serie"):
                chips += ["Géneros", "A–Z", "Año", "Calidad"]
            self._fill_chips(chips)
        else:
            self._show_main_chips()
        self._reload()
        if self.spec:
            self.setFocusId(GRID_ID)

    def onFocus(self, control_id):
        if control_id in (CHIPS_ID, GRID_ID):
            self._focus_ctl = control_id
        if control_id == GRID_ID:
            pos = self.getControl(GRID_ID).getSelectedPosition()
            if 0 <= pos:
                self._grid_pos = pos
                self._update_count()
            if pos > self.loaded - 24 and self.loaded < self.total:
                self._load_batch()
        self._sync_fanart()

    # ---------------- tecla Play (sup1-M7) ----------------
    def _next_ep(self, tmdb):
        """Siguiente episodio a reproducir de una serie (el a medias, el
        siguiente al último visto o el primero): la misma regla que la
        Ficha."""
        if self.vault is None:
            return None
        last = self.catalog.ultimo_visto_ep(tmdb)
        seasons = self.vault.seasons(tmdb)
        if not seasons:
            return None
        if last:
            t, e, prog = last["temporada"], last["episodio"], \
                last.get("progress") or 0
            if 1 < prog < 97:
                return (t, e)
            eps = [x["episodio"] for x in self.vault.episodes(tmdb, t)]
            nxt = [x for x in eps if x > e]
            if nxt:
                return (t, nxt[0])
            later = [s["temporada"] for s in seasons if s["temporada"] > t]
            if later:
                eps2 = self.vault.episodes(tmdb, later[0])
                if eps2:
                    return (later[0], eps2[0]["episodio"])
            return (t, e)
        t0 = seasons[0]["temporada"]
        eps0 = self.vault.episodes(tmdb, t0)
        return (t0, eps0[0]["episodio"]) if eps0 else None

    def _play_row(self, row):
        """Play sobre un póster: reproduce directo, sin pasar por la
        ficha (en series, su siguiente episodio)."""
        if not self.playback or not row or row.get("_coleccion"):
            return
        if self.mode == "colecciones" and not self.coleccion_id \
                and not self.spec:
            return  # una colección no se reproduce
        kind = row.get("kind") or self.kind
        tmdb = row.get("tmdb")
        if not tmdb:
            return
        if kind == "serie" and row.get("temporada") is not None:
            self.playback.play_episode(int(tmdb), int(row["temporada"]),
                                       int(row["episodio"]))
        elif kind == "pelicula":
            self.playback.play_movie(int(tmdb))
        else:
            nxt = self._next_ep(int(tmdb))
            if nxt:
                self.playback.play_episode(int(tmdb), nxt[0], nxt[1])

    # ---------------- acciones especiales de la rejilla ----------------
    def _salto_pagina(self, direccion, base):
        """Salto de exactamente una pantalla (PAGE ítems) desde `base`,
        la posición ANTES de la acción (Kodi mueve la selección dentro
        del contenedor antes de que onAction corra; la posición previa
        es la que mantiene _grid_pos, ver onAction)."""
        if not self.total:
            return
        target = base + direccion * PAGE
        target = max(0, min(target, self.total - 1))
        while self.loaded <= target and self.loaded < self.total:
            self._load_batch()
        self._grid_pos = target
        self.getControl(GRID_ID).selectItem(target)
        self._update_count()

    def _salto_letra(self):
        """En una hoja A–Z: saltar a otra letra sin salir de la rejilla
        (la columna de letras de la ponencia de navegación, servida con
        el diálogo de la casa)."""
        base = {"kind": self.spec.get("kind", "pelicula"),
                "categorias": self.spec.get("categorias")}
        conteos = self.catalog.letras_con_conteo(base["kind"], base["categorias"])
        letras = [l for l in conteos if conteos.get(l)]
        if not letras:
            return
        opts = ["%s · %s títulos" % (l, fmt_num(conteos[l])) for l in letras]
        import dialogs
        sel = dialogs.select("Ir a la letra", opts)
        if sel < 0:
            return
        nueva = letras[sel]
        if nueva == self.spec.get("letra"):
            return
        spec = dict(self.spec)
        spec["letra"] = nueva
        self.spec = spec
        self.titulo = nueva
        self.getControl(LBL_TITULO).setLabel(nueva)
        self._reload()
        self.setFocusId(GRID_ID)

    def _context_upnext(self, pos):
        """Menú contextual de la casa en las hojas Up Next (Fase 2)."""
        if not (0 <= pos < len(self._rows)) or not self.userdata:
            return
        row = self._rows[pos]
        opts = ["Quitar de aquí", "Marcar visto", "Ir a la ficha"]
        import dialogs
        sel = dialogs.select(row.get("titulo") or "", opts)
        if sel == 0:
            self.userdata.descartar(row.get("kind") or self.kind, row["tmdb"])
            self._reload(keep=True)
        elif sel == 1:
            if row.get("kind") == "serie" and row.get("temporada") is not None:
                self.userdata.save_episode(row["tmdb"], row["temporada"],
                                           row["episodio"], 0, finished=True)
            else:
                self.userdata.save_movie(row["tmdb"], 0, finished=True)
            self._reload(keep=True)
        elif sel == 2:
            self._open_detail(row)

    def _open_detail(self, row):
        from detail import DetailWindow
        win = DetailWindow("detail.xml", self.addon_path, "Default", "1080i",
                           catalog=self.catalog, userdata=self.userdata,
                           playback=self.playback, vault=self.vault,
                           addon_path=self.addon_path, profile=self.profile,
                           kind=row.get("kind") or self.kind,
                           tmdb=int(row["tmdb"]))
        win.doModal()
        del win

    def onAction(self, action):
        aid = action.getId() if hasattr(action, "getId") else 0
        fid = self.getFocusId()
        if aid in (79, 229) and fid == GRID_ID:
            # Tecla Play (sup1-M7): reproduce el póster enfocado.
            if 0 <= self._grid_pos < len(self._rows):
                self._play_row(self._rows[self._grid_pos])
            return
        if fid == GRID_ID:
            # Kodi mueve la selección dentro del contenedor ANTES de que
            # este onAction corra (medido en banco): getSelectedPosition()
            # ya es la posición POSTERIOR a la acción. La posición previa
            # —la que vale para saltos y contextos— es self._grid_pos, que
            # mantienen onFocus y el bloque tras super() de cada acción.
            prev = self._grid_pos
            pos = self.getControl(GRID_ID).getSelectedPosition()
            if aid in (ACTION_PAGE_DOWN, ACTION_PAGE_UP):
                self._salto_pagina(1 if aid == ACTION_PAGE_DOWN else -1, prev)
                return
            if aid in (ACTION_CHANNEL_DOWN, ACTION_CHANNEL_DOWN_ALT):
                self._salto_pagina(1, prev)
                return
            if aid == ACTION_CHANNEL_UP:
                self._salto_pagina(-1, prev)
                return
            if aid == ACTION_CONTEXT and self._es_upnext():
                self._context_upnext(prev)
                return
            if (aid == ACTION_MOVE_LEFT and self.spec
                    and self.spec.get("letra") and prev % COLS == 0):
                # si el diálogo se cancela, la posición real es la que
                # Kodi ya había movido (pos); si se elige letra, _reload
                # la reinicia. Se sincroniza antes de abrirlo.
                if 0 <= pos:
                    self._grid_pos = pos
                self._salto_letra()
                return
            if 0 <= pos:
                self._grid_pos = pos
            if pos > self.loaded - 24 and self.loaded < self.total:
                self._load_batch()
        super(SectionWindow, self).onAction(action)
        if self.getFocusId() == GRID_ID:
            # tras el movimiento real: indicador «n / total» al día
            pos2 = self.getControl(GRID_ID).getSelectedPosition()
            if 0 <= pos2 and pos2 != self._grid_pos:
                self._grid_pos = pos2
                self._update_count()
                if pos2 > self.loaded - 24 and self.loaded < self.total:
                    self._load_batch()
        self._sync_fanart()

    def _chip_action(self, label):
        cat = self.catalog
        if self.spec:
            plain = label.replace("[COLOR FFFF7800]", "").replace("[/COLOR]", "")
            if plain in ("Géneros", "A–Z", "Año", "Calidad"):
                # Exploración del bloque (§2b/§2c): menús de la casa
                # con la base del tipo (y la categoría, si la spec
                # del bloque la trae).
                import menus as _menus
                kind = self.spec.get("kind") or self.kind
                base = {"kind": kind}
                if self.spec.get("categorias"):
                    base["categorias"] = self.spec["categorias"]
                builder = {"Géneros": "generos", "A–Z": "letras",
                           "Año": "anos", "Calidad": "calidades"}[plain]
                titulo = "%s · %s" % (
                    plain, "Películas" if kind == "pelicula" else "Series")
                _menus.open_menu(self, builder,
                                 {"titulo": titulo, "base": base})
                return
            self.close()
            return
        if self.sub == "generos":
            if label.startswith("←"):
                self.sub = None
                self._show_main_chips()
                return
            self.genero = label.replace("[COLOR FFFF7800]", "").replace("[/COLOR]", "")
            self.mode = "generos"
            self.sub = None
            self._show_main_chips()
            self._reload()
            self.setFocusId(GRID_ID)
            return
        if self.sub == "ano":
            if label.startswith("←"):
                self.sub = None
                self._show_main_chips()
                return
            self.year = label.replace("[COLOR FFFF7800]", "").replace("[/COLOR]", "")
            self.mode = "ano"
            self.sub = None
            self._show_main_chips()
            self._reload()
            self.setFocusId(GRID_ID)
            return
        plain = label.replace("[COLOR FFFF7800]", "").replace("[/COLOR]", "")
        if plain == "Géneros":
            self.sub = "generos"
            self._fill_chips(["← Volver"] + cat.generos(self.kind))
            return
        if plain == "Año":
            self.sub = "ano"
            self._fill_chips(["← Volver"] + cat.years(self.kind))
            return
        self.genero = None
        self.year = None
        self.coleccion_id = None
        self.mode = {"Todo": "todo", "Novedades": "novedades", "Más vistas": "vistas",
                     "Colecciones": "colecciones",
                     "A–Z": "az"}.get(plain, "todo")
        self._show_main_chips()
        self._reload()
        self.setFocusId(GRID_ID)

    def onClick(self, control_id):
        from nav import topbar_click
        if topbar_click(self, control_id):
            return
        if control_id == CHIPS_ID:
            item = self.getControl(CHIPS_ID).getSelectedItem()
            if item:
                self._chip_action(item.getProperty("chip") or item.getLabel())
            return
        if control_id == GRID_ID:
            item = self.getControl(GRID_ID).getSelectedItem()
            if item is None:
                return
            pos = self.getControl(GRID_ID).getSelectedPosition()
            if 0 <= pos:
                self._grid_pos = pos
            if item.getProperty("coleccion"):
                if self.spec:
                    win = SectionWindow("section.xml", self.addon_path, "Default", "1080i",
                                        catalog=self.catalog, userdata=self.userdata,
                                        playback=self.playback, vault=self.vault,
                                        addon_path=self.addon_path, profile=self.profile,
                                        kind="pelicula",
                                        spec={"tipo": "coleccion",
                                              "coleccion": item.getProperty("coleccion")},
                                        titulo=item.getProperty("titulo"))
                    win.doModal()
                    del win
                    return
                self.coleccion_id = item.getProperty("coleccion")
                self._reload()
                self.setFocusId(GRID_ID)
                return
            if item.getProperty("play_t") and self.playback:
                # D5: OK sobre una fila de seguimiento reproduce el episodio
                self.playback.play_episode(int(item.getProperty("tmdb")),
                                           int(item.getProperty("play_t")),
                                           int(item.getProperty("play_e")))
                return
            if item.getProperty("play_movie") and self.playback:
                # Películas sin terminar: OK reanuda en el punto exacto
                self.playback.play_movie(int(item.getProperty("tmdb")))
                return
            tmdb = item.getProperty("tmdb")
            if tmdb:
                if 0 <= pos < len(self._rows):
                    self._open_detail(self._rows[pos])
                else:
                    self._open_detail({"kind": item.getProperty("kind") or self.kind,
                                       "tmdb": int(tmdb)})
