# -*- coding: utf-8 -*-
"""Cliente mínimo de AllDebrid para PalAntriX (unlock de los enlaces de la bóveda)."""
import requests

API = "https://api.alldebrid.com/v4"
AGENT = "PalAntriX"

class LinkDown(Exception):
    pass

class AllDebridError(Exception):
    """Error de AllDebrid con mensaje seguro (nunca lleva URL ni clave).

    `transport=True` marca un fallo de red (sin respuesta de la API):
    la cadena de reproducción lo trata como «este enlace no está
    disponible, siguiente» en vez de rendirse (sup4-H1)."""
    def __init__(self, message="", transport=False):
        super(AllDebridError, self).__init__(message)
        self.transport = transport

class AllDebrid(object):
    def __init__(self, apikey):
        self.apikey = (apikey or "").strip()
        self.session = requests.Session()

    def _get(self, path, _timeout=45, **params):
        params["agent"] = AGENT
        params["apikey"] = self.apikey
        try:
            r = self.session.get(API + path, params=params, timeout=_timeout)
        except requests.RequestException:
            # JAMÁS propagar la excepción de transporte: su texto lleva
            # la URL completa de la petición (la clave API y, en el
            # unlock, el enlace descifrado de la bóveda) y acabaría impresa
            # en kodi.log (sup2-B2). Se relanza un error fijo, sin datos.
            raise AllDebridError("Sin conexión con AllDebrid", transport=True)
        try:
            return r.json()
        except Exception:
            raise AllDebridError("Respuesta no válida de AllDebrid (HTTP %s)" % r.status_code)

    def configured(self):
        return len(self.apikey) >= 10

    def user(self, timeout=45):
        d = self._get("/user", _timeout=timeout)
        if d.get("status") != "success":
            raise AllDebridError((d.get("error") or {}).get("message", "Error de cuenta"))
        return d.get("data", {}).get("user", {})

    def unlock(self, url):
        """Devuelve {'link': url_de_streaming, 'filename': nombre} o lanza LinkDown."""
        d = self._get("/link/unlock", link=url)
        if d.get("status") == "success":
            data = d.get("data") or {}
            return {"link": data.get("link"), "filename": data.get("filename", "")}
        err = (d.get("error") or {}).get("code", "")
        if err in ("LINK_DOWN", "LINK_NOT_AVAILABLE", "LINK_ERROR"):
            # La excepción NO transporta la dirección (sup2-M1): quien
            # la atrape no debe poder volcarla a un registro.
            raise LinkDown()
        raise AllDebridError((d.get("error") or {}).get("message", err or "Error al desbloquear"))

    def delete_history(self):
        try:
            self._get("/user/history/delete")
        except Exception:
            pass

    # ---------- magnets (capa viva) ----------
    def _post(self, url, data):
        try:
            r = self.session.post(url, params={"agent": AGENT, "apikey": self.apikey},
                                  data=data, timeout=45)
        except requests.RequestException:
            # Igual que en _get: la excepción de transporte lleva la URL
            # (con la clave) en su texto; no debe propagarse (sup2-B2).
            raise AllDebridError("Sin conexión con AllDebrid", transport=True)
        try:
            return r.json()
        except Exception:
            raise AllDebridError("Respuesta no válida de AllDebrid (HTTP %s)" % r.status_code)

    def magnet_upload(self, magnet):
        d = self._get("/magnet/upload", magnets=magnet)
        if d.get("status") == "success":
            mags = (d.get("data") or {}).get("magnets") or []
            if mags and mags[0].get("id"):
                return mags[0]["id"]
        raise AllDebridError((d.get("error") or {}).get("message", "Magnet rechazado"))

    def magnet_status(self, magnet_id):
        """API v4.1: fullsync y filtrado por id. Devuelve el dict del magnet o {}."""
        d = self._post("https://api.alldebrid.com/v4.1/magnet/status", {})
        if d.get("status") != "success":
            raise AllDebridError((d.get("error") or {}).get("message", "Estado no disponible"))
        for m in (d.get("data") or {}).get("magnets") or []:
            if str(m.get("id")) == str(magnet_id):
                return m
        return {}

    def magnet_files(self, magnet_id):
        """Árbol de archivos del magnet: nodos {n, s, l} y carpetas {n, e[]}."""
        d = self._post("https://api.alldebrid.com/v4/magnet/files",
                       [("id[]", str(magnet_id))])
        if d.get("status") != "success":
            raise AllDebridError((d.get("error") or {}).get("message", "Archivos no disponibles"))
        mags = (d.get("data") or {}).get("magnets") or []
        if mags:
            return mags[0].get("files") or []
        return []


# ---------- vinculación por código PIN (sin clave previa) ----------
def pin_get():
    """Pide un código de vinculación. Devuelve
    {'pin', 'check', 'expires_in'} o None si AllDebrid no responde."""
    try:
        r = requests.get(API + "/pin/get", params={"agent": AGENT}, timeout=20)
        d = r.json()
    except Exception:
        return None
    if d.get("status") != "success":
        return None
    data = d.get("data") or {}
    if not data.get("pin") or not data.get("check"):
        return None
    return {"pin": data["pin"], "check": data["check"],
            "expires_in": int(data.get("expires_in") or 600)}


def pin_check(check, pin):
    """Sondea el código: devuelve la clave API cuando el usuario ya lo ha
    confirmado en alldebrid.com/pin; None mientras sigue pendiente;
    False si la API responde error (código no válido o caducado).

    OJO: /pin/check exige TRES parámetros (check, pin, agent) — los de
    la check_url que devuelve /pin/get. Sin `pin`, la API responde
    PIN_INVALID en cada sondeo y la vinculación se quedaba colgada
    para siempre (probado en vivo el 21/11)."""
    try:
        r = requests.get(API + "/pin/check",
                         params={"agent": AGENT, "check": check, "pin": pin},
                         timeout=20)
        d = r.json()
    except Exception:
        return None
    if d.get("status") != "success":
        return False
    data = d.get("data") or {}
    if data.get("activated"):
        return data.get("apikey") or None
    return None
