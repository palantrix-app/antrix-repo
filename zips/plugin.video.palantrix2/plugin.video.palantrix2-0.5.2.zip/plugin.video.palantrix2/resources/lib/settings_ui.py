# -*- coding: utf-8 -*-
"""Ventana Ajustes (1305) — TODA la configuración (§1 punto 3).

Desde el repaso de la Principal, Ajustes contiene también las
cuentas y las llaves: AllDebrid, Trakt y la Bóveda se abren desde
aquí (sus pantallas de Servicios, sin perder ninguna función), y
Servicios sigue existiendo como nodo propio en «Más».

«Ajustes avanzados» ya NO abre el diálogo de ajustes de Kodi
(requisito global §7: ningún menú con estilo Kodi): es una
pantalla propia con las claves y campos que antes vivían en ese
diálogo, escrita con el diseño de la app y etiquetas claras.
"""
import xbmc
import xbmcaddon
import xbmcgui

import dialogs
import menus

ADDON = xbmcaddon.Addon()
LIST_ID = 500
CALIDADES = ["Automática (DV primero)", "DV", "4K", "1080p"]


def _version():
    try:
        return ADDON.getAddonInfo("version")
    except Exception:
        return ""


class SettingsWindow(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        super(SettingsWindow, self).__init__(*args)
        self.catalog = kwargs.get("catalog")
        self.userdata = kwargs.get("userdata")
        self.playback = kwargs.get("playback")
        self.vault = kwargs.get("vault")
        self.addon_path = kwargs.get("addon_path")
        self.profile = kwargs.get("profile") or ""
        self.display = []   # dicts {'dest': 'header'|'row'} para corregir
        self._pos = 0

    # ---------- notas de estado (sin red: lo que ya se sepa) ----------
    def _ad_nota(self):
        import services
        key = (ADDON.getSetting("alldebrid_apikey") or "").strip()
        if not key:
            return "Sin vincular ›"
        cached = services._AD_CACHE.get("info")
        if cached:
            return cached["texto"] + " ›"
        return "Vinculado ›"

    def _trakt_nota(self):
        import services
        return services.trakt_state_text() + " ›"

    def _boveda_nota(self):
        import services
        return services.vault_state_text(self.vault) + " ›"

    def _rows(self):
        calidad = CALIDADES[int(ADDON.getSetting("calidad") or 0)]
        autoplay = "Sí" if ADDON.getSetting("autoplay") == "true" else "No"
        fallback = "Sí" if ADDON.getSetting("fallback_vivo") == "true" else "No"
        return [
            ("header", "REPRODUCCIÓN", "", None),
            ("row", "Calidad preferida", calidad + " ›", "calidad"),
            ("row", "Autoplay", autoplay + " ›", "autoplay"),
            ("row", "Si el enlace falla, buscar en vivo", fallback + " ›", "fallback"),
            ("header", "CUENTAS Y BÓVEDA", "", None),
            ("row", "AllDebrid", self._ad_nota(), "svc_alldebrid"),
            ("row", "Trakt", self._trakt_nota(), "svc_trakt"),
            ("row", "Bóveda de enlaces", self._boveda_nota(), "svc_boveda"),
            ("row", "Catálogo y más servicios", "›", "svc_root"),
            ("header", "SISTEMA", "", None),
            ("row", "Ajustes avanzados", "›", "avanzados"),
            ("row", "Acerca de PalAntriX", "v%s ›" % _version(), "acerca"),
        ]

    def _fill(self, keep_pos=True):
        rows = self._rows()
        self.display = [{"dest": kind} for kind, _l, _v, _a in rows]
        lst = self.getControl(LIST_ID)
        pos = lst.getSelectedPosition() if keep_pos else self._first_actionable()
        lst.reset()
        items = []
        for kind, label, value, action in rows:
            if kind == "header":
                li = xbmcgui.ListItem(label="[COLOR FFFF7800]%s[/COLOR]" % label)
                li.setProperty("header", "1")
            else:
                li = xbmcgui.ListItem(label=label)
                li.setLabel2(value)
                li.setProperty("action", action or "")
            items.append(li)
        lst.addItems(items)
        if items:
            pos = min(max(pos, 0), len(items) - 1)
            if self.display[pos]["dest"] == "header":
                pos = menus.corregir_posicion(self.display, pos, None,
                                              menus.ACTION_MOVE_DOWN)
            lst.selectItem(pos)
            self._pos = lst.getSelectedPosition()

    def _first_actionable(self):
        for i, d in enumerate(self.display):
            if d["dest"] != "header":
                return i
        return 0

    def onInit(self):
        if getattr(self, "_inited", False):
            from nav import unwind_home
            if unwind_home(self):
                return
        self._inited = True
        try:
            self.getControl(920).setLabel("Ajustes")
        except Exception:
            pass
        self._fill(keep_pos=False)
        self.setFocusId(LIST_ID)

    def onAction(self, action):
        super(SettingsWindow, self).onAction(action)
        try:
            lst = self.getControl(LIST_ID)
            pos = lst.getSelectedPosition()
        except Exception:
            return
        if not (0 <= pos < len(self.display)):
            return
        aid = action.getId() if hasattr(action, "getId") else 0
        buena = menus.corregir_posicion(self.display, pos, self._pos, aid)
        if buena != pos:
            lst.selectItem(buena)
            pos = buena
        self._pos = pos

    # ---------- apertura de las pantallas de Servicios ----------
    def _open_services(self, screen):
        from services import ServicesWindow
        w = ServicesWindow("services.xml", self.addon_path, "Default", "1080i",
                           catalog=self.catalog, userdata=self.userdata,
                           playback=self.playback, vault=self.vault,
                           addon_path=self.addon_path, profile=self.profile,
                           screen=screen)
        w.doModal()
        del w
        self._fill()

    def _svc_alldebrid(self):
        import services
        if not (ADDON.getSetting("alldebrid_apikey") or "").strip():
            services.alldebrid_link_flow(self)
            self._fill()
        else:
            self._open_services("alldebrid")

    def _svc_trakt(self):
        import services
        import trakt
        if not trakt.configured():
            self._open_trakt_setup()
        elif not trakt.linked():
            services.trakt_link_flow(self)
            self._fill()
        else:
            self._open_services("trakt")

    def _open_trakt_setup(self):
        from services import TraktSetupWindow
        w = TraktSetupWindow("trakt_setup.xml", self.addon_path, "Default",
                             "1080i", catalog=self.catalog,
                             userdata=self.userdata, playback=self.playback,
                             vault=self.vault, addon_path=self.addon_path,
                             profile=self.profile)
        w.doModal()
        del w
        self._fill()

    def onClick(self, control_id):
        from nav import topbar_click
        if topbar_click(self, control_id):
            return
        if control_id != LIST_ID:
            return
        item = self.getControl(LIST_ID).getSelectedItem()
        if item is None or item.getProperty("header"):
            return
        action = item.getProperty("action")
        if action == "avanzados":
            w = AvanzadosWindow("settings.xml", self.addon_path, "Default",
                                "1080i", catalog=self.catalog,
                                userdata=self.userdata,
                                playback=self.playback, vault=self.vault,
                                addon_path=self.addon_path,
                                profile=self.profile)
            w.doModal()
            del w
            self._fill()
        elif action == "calidad":
            sel = dialogs.select("Calidad preferida", CALIDADES)
            if sel >= 0:
                ADDON.setSetting("calidad", str(sel))
                self._fill()
        elif action in ("autoplay", "fallback"):
            key = "autoplay" if action == "autoplay" else "fallback_vivo"
            ADDON.setSetting(key, "false" if ADDON.getSetting(key) == "true" else "true")
            self._fill()
        elif action == "svc_alldebrid":
            self._svc_alldebrid()
        elif action == "svc_trakt":
            self._svc_trakt()
        elif action == "svc_boveda":
            self._open_services("boveda")
        elif action == "svc_root":
            self._open_services("root")
        elif action == "acerca":
            dialogs.ok("PalAntriX",
                "PalAntriX v%s — tu catálogo, como Apple TV.\n"
                "Enlaces cifrados en bóveda (AES-256) con accesos por ranura.\n"
                "Base rescatada de Palantir + búsqueda en vivo de respaldo.\n\n"
                "Toda la configuración vive aquí, en Ajustes: "
                "reproducción, AllDebrid, Trakt y la bóveda."
                % _version())


# ---------------------------------------------------------------------------
# Ajustes avanzados PROPIOS (§7): lo que antes abría el diálogo de Kodi
# ---------------------------------------------------------------------------
_CAMPOS = [
    # (setting, etiqueta clara, oculto)
    ("alldebrid_apikey", "AllDebrid · Clave API", True),
    ("trakt_user", "Trakt · Nombre de usuario", False),
    ("trakt_client_id", "Trakt · Client ID de tu app propia", False),
    ("trakt_client_secret", "Trakt · Client Secret de tu app propia", True),
]


class AvanzadosWindow(xbmcgui.WindowXML):
    """Las claves y campos «de experto» del addon, con el diseño de
    la app: cada fila dice si hay algo guardado y se edita con el
    teclado propio. Los campos internos (tokens de Trakt, fecha de
    sincronización) los gestiona la propia app y no se tocan aquí,
    igual que en el diálogo antiguo salían como nivel interno."""

    def __init__(self, *args, **kwargs):
        super(AvanzadosWindow, self).__init__(*args)
        self.catalog = kwargs.get("catalog")
        self.userdata = kwargs.get("userdata")
        self.playback = kwargs.get("playback")
        self.vault = kwargs.get("vault")
        self.addon_path = kwargs.get("addon_path")
        self.profile = kwargs.get("profile") or ""
        self.display = []
        self._pos = 0

    def _rows(self):
        rows = [("header", "AJUSTES AVANZADOS", "", None),
                ("row", "Qué es esto", "claves y campos de experto", "info")]
        for setting, etiqueta, oculto in _CAMPOS:
            valor = (ADDON.getSetting(setting) or "").strip()
            if oculto:
                nota = "guardada ›" if valor else "sin guardar ›"
            else:
                nota = (valor[:26] + " ›") if valor else "sin guardar ›"
            rows.append(("row", etiqueta, nota, "campo:" + setting))
        rows.append(("row", "Volver", "", "back"))
        return rows

    def _fill(self, keep_pos=True):
        rows = self._rows()
        self.display = [{"dest": kind} for kind, _l, _v, _a in rows]
        lst = self.getControl(LIST_ID)
        pos = lst.getSelectedPosition() if keep_pos else 1
        lst.reset()
        items = []
        for kind, label, value, action in rows:
            if kind == "header":
                li = xbmcgui.ListItem(label="[COLOR FFFF7800]%s[/COLOR]" % label)
                li.setProperty("header", "1")
            else:
                li = xbmcgui.ListItem(label=label)
                li.setLabel2(value)
                li.setProperty("action", action or "")
            items.append(li)
        lst.addItems(items)
        if items:
            pos = min(max(pos, 0), len(items) - 1)
            if self.display[pos]["dest"] == "header":
                pos = menus.corregir_posicion(self.display, pos, None,
                                              menus.ACTION_MOVE_DOWN)
            lst.selectItem(pos)
            self._pos = lst.getSelectedPosition()

    def onInit(self):
        if getattr(self, "_inited", False):
            from nav import unwind_home
            if unwind_home(self):
                return
        self._inited = True
        try:
            self.getControl(920).setLabel("Ajustes avanzados")
        except Exception:
            pass
        self._fill(keep_pos=False)
        self.setFocusId(LIST_ID)

    def onAction(self, action):
        super(AvanzadosWindow, self).onAction(action)
        try:
            lst = self.getControl(LIST_ID)
            pos = lst.getSelectedPosition()
        except Exception:
            return
        if not (0 <= pos < len(self.display)):
            return
        aid = action.getId() if hasattr(action, "getId") else 0
        buena = menus.corregir_posicion(self.display, pos, self._pos, aid)
        if buena != pos:
            lst.selectItem(buena)
            pos = buena
        self._pos = pos

    def onClick(self, control_id):
        from nav import topbar_click
        if topbar_click(self, control_id):
            return
        if control_id != LIST_ID:
            return
        item = self.getControl(LIST_ID).getSelectedItem()
        if item is None or item.getProperty("header"):
            return
        action = item.getProperty("action")
        if action == "back":
            self.close()
        elif action == "info":
            dialogs.ok(
                "Ajustes avanzados",
                "Aquí viven las claves que la app usa por dentro.\n\n"
                "No hace falta tocar nada: AllDebrid y Trakt se "
                "vinculan con código desde Ajustes, y la app ya trae "
                "las claves de su propio proyecto de Trakt. Estos "
                "campos solo sirven si quieres usar TU propia app "
                "de Trakt o pegar una clave de AllDebrid a mano.")
        elif action.startswith("campo:"):
            setting = action.split(":", 1)[1]
            etiqueta, oculto = next(
                (e, o) for s, e, o in _CAMPOS if s == setting)
            actual = (ADDON.getSetting(setting) or "").strip()
            nuevo = dialogs.ask_text(etiqueta,
                                     inicial="" if oculto else actual,
                                     hidden=oculto)
            if nuevo is None:
                return
            nuevo = nuevo.strip()
            if nuevo == actual:
                return
            if setting == "alldebrid_apikey":
                import services
                services._AD_CACHE.update(
                    {"key": None, "t": 0.0, "info": None})
            if setting in ("trakt_client_id", "trakt_client_secret") \
                    and nuevo != actual:
                # Unas claves nuevas invalidan el token de la app
                # anterior (misma regla que el asistente de Trakt).
                import trakt
                ADDON.setSetting(setting, nuevo)
                trakt.unlink()
            else:
                ADDON.setSetting(setting, nuevo)
            self._fill()
