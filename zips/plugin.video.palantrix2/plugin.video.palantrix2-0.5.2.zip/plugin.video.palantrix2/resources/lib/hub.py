# -*- coding: utf-8 -*-
"""Ventana Hub (1318) — Series y Películas con el MISMO sistema (§2b/§2c).

Cinco bloques en horizontal, ~20 miniaturas por bloque, lo más nuevo
primero:
  1. Últimas actualizaciones   (order=updated)
  2. Nuevas                    (order=fecha, novedad)
  3. Seguimiento               (series: en seguimiento por recencia de
                                visionado; películas: sin terminar)
  4. Recomendadas              (order=recomendadas)
  5. Populares                 (order=populares)
El último ítem de cada carril es «Ver todas ›», que abre la rejilla
completa del bloque (SectionWindow con su spec). Desde esa rejilla,
la fila de chips da acceso a Géneros / A–Z / Año / Calidad (los
antiguos «Descubrir/Explorar/Buscar por» ya no son bloques aquí).

Regla del fondo (§1.8): fondo propio de PalAntriX mientras el foco no
está sobre una miniatura concreta; al posarse en una miniatura, el
fondo pasa a ser SU fanart; al salir (título de bloque, barra
superior), vuelve el fondo propio. El título enfocado se nombra en
la etiqueta superior derecha.
"""
import xbmc
import xbmcgui

from db import img

RAILS = (200, 201, 202, 203, 204)
LBL_TITULOS = (950, 951, 952, 953, 954)
LBL_SECCION = 920
LBL_FOCO = 930
IMG_FANART = 9000
BTN_BUSCAR = 810
BTN_AJUSTES = 811
BTN_CASA = 812
MAX_RAIL = 20

BLOQUES = {
    "serie": [
        ("Últimas actualizaciones", {"tipo": "grid", "kind": "serie",
                                     "order": "updated"}),
        ("Series nuevas", {"tipo": "grid", "kind": "serie",
                           "order": "fecha", "novedad": True}),
        ("Seguimiento", {"tipo": "seguimiento"}),
        ("Recomendadas", {"tipo": "grid", "kind": "serie",
                          "order": "recomendadas"}),
        ("Populares", {"tipo": "grid", "kind": "serie",
                       "order": "populares"}),
    ],
    "pelicula": [
        ("Últimas actualizaciones", {"tipo": "grid", "kind": "pelicula",
                                     "order": "updated"}),
        ("Películas nuevas", {"tipo": "grid", "kind": "pelicula",
                              "order": "fecha", "novedad": True}),
        ("Seguimiento", {"tipo": "sin_terminar", "kind": "pelicula"}),
        ("Recomendadas", {"tipo": "grid", "kind": "pelicula",
                          "order": "recomendadas"}),
        ("Populares", {"tipo": "grid", "kind": "pelicula",
                       "order": "populares"}),
    ],
}

TITULOS = {"serie": "Series", "pelicula": "Películas"}


class HubWindow(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        super(HubWindow, self).__init__(*args)
        self.catalog = kwargs.get("catalog")
        self.userdata = kwargs.get("userdata")
        self.playback = kwargs.get("playback")
        self.vault = kwargs.get("vault")
        self.addon_path = kwargs.get("addon_path")
        self.profile = kwargs.get("profile", "")
        self.kind = kwargs.get("kind", "serie")
        self.blocks = []       # [{titulo, spec, rows}] por carril visible
        self._fanart_actual = ""
        self._focus = (0, 0)   # (carril, posición)
        self._inited = False

    # ---------- construcción ----------
    def _item(self, row):
        li = xbmcgui.ListItem(label=row.get("titulo") or "")
        if row.get("label2"):
            li.setLabel2(row["label2"])
        li.setArt({
            "poster": img(row.get("poster"), "w500"),
            # La baldosa es apaisada: manda el fanart; si un título no
            # tiene, se usa su póster (recortado) en vez de un hueco.
            "fanart": img(row.get("fondo") or row.get("poster"), "w500"),
            "thumb": img(row.get("poster"), "w500"),
        })
        li.setProperty("tmdb", str(row.get("tmdb") or ""))
        li.setProperty("kind", row.get("kind") or self.kind)
        li.setProperty("fondo", img(row.get("fondo"), "w1280"))
        if row.get("nuevo") or self.catalog.es_nuevo(
                row.get("kind") or self.kind, row.get("tmdb")):
            li.setProperty("nuevo", "1")
        if row.get("temporada") is not None:
            li.setProperty("play_t", str(row["temporada"]))
            li.setProperty("play_e", str(row["episodio"]))
        return li

    def _fill(self):
        self.getControl(LBL_SECCION).setLabel(TITULOS[self.kind])
        self.blocks = []
        for i, (titulo, spec) in enumerate(BLOQUES[self.kind]):
            try:
                rows = self.catalog.spec_rows(spec, 0, MAX_RAIL)
            except Exception:
                rows = []
            lst = self.getControl(RAILS[i])
            lst.reset()
            items = [self._item(r) for r in rows]
            if rows:
                vt = xbmcgui.ListItem(label="Ver todas")
                vt.setProperty("vertodo", "1")
                items.append(vt)
            lst.addItems(items)
            self.getControl(LBL_TITULOS[i]).setLabel(titulo if rows else "")
            self.blocks.append({"titulo": titulo, "spec": spec,
                                "rows": rows})

    # ---------- fondo (regla §1.8) ----------
    def _set_fanart(self, fondo):
        if (fondo or "") != self._fanart_actual:
            self._fanart_actual = fondo or ""
            self.getControl(IMG_FANART).setImage(self._fanart_actual, False)

    def _on_item_focus(self, rail, pos):
        self._focus = (rail, pos)
        blk = self.blocks[rail]
        if 0 <= pos < len(blk["rows"]):
            row = blk["rows"][pos]
            self._set_fanart(img(row.get("fondo"), "w1280"))
            nota = row.get("titulo") or ""
            if row.get("label2"):
                nota += "  ·  " + row["label2"]
            self.getControl(LBL_FOCO).setLabel(nota)
        else:
            # «Ver todas» o fuera de rango: no es una miniatura
            # concreta → fondo propio.
            self._set_fanart("")
            self.getControl(LBL_FOCO).setLabel("")

    # ---------- ventana ----------
    def onInit(self):
        if self._inited:
            from nav import unwind_home
            if unwind_home(self):
                return
            try:
                rail, pos = self._focus
                lst = self.getControl(RAILS[rail])
                lst.selectItem(min(pos, max(len(self.blocks[rail]["rows"]), 0)))
                self.setFocusId(RAILS[rail])
                self._on_item_focus(rail, pos)
            except Exception:
                pass
            return
        self._inited = True
        self._fill()
        xbmc.sleep(150)
        self.setFocusId(RAILS[0])
        self._on_item_focus(0, 0)

    def onFocus(self, control_id):
        if control_id in (BTN_BUSCAR, BTN_AJUSTES, BTN_CASA):
            self._set_fanart("")
            self.getControl(LBL_FOCO).setLabel("")

    def onAction(self, action):
        super(HubWindow, self).onAction(action)
        aid = action.getId() if hasattr(action, "getId") else 0
        fid = self.getFocusId()
        if fid in RAILS:
            rail = RAILS.index(fid)
            pos = self.getControl(fid).getSelectedPosition()
            if (rail, pos) != self._focus and 0 <= pos:
                self._on_item_focus(rail, pos)
            if aid in (79, 229) and self.playback:
                if 0 <= pos < len(self.blocks[rail]["rows"]):
                    self._play_row(self.blocks[rail]["rows"][pos])
                return

    def _play_row(self, row):
        if not row:
            return
        kind = row.get("kind") or self.kind
        tmdb = row.get("tmdb")
        if not tmdb:
            return
        if kind == "serie" and row.get("temporada") is not None:
            self.playback.play_episode(int(tmdb), int(row["temporada"]),
                                       int(row["episodio"]))
        elif kind == "pelicula":
            self.playback.play_movie(int(tmdb))
        else:
            from detail import DetailWindow
            win = DetailWindow("detail.xml", self.addon_path, "Default",
                               "1080i", catalog=self.catalog,
                               userdata=self.userdata,
                               playback=self.playback, vault=self.vault,
                               addon_path=self.addon_path,
                               profile=self.profile, kind=kind,
                               tmdb=int(tmdb))
            win.doModal()
            del win

    def onClick(self, control_id):
        from nav import topbar_click
        if topbar_click(self, control_id):
            return
        if control_id not in RAILS:
            return
        rail = RAILS.index(control_id)
        lst = self.getControl(control_id)
        pos = lst.getSelectedPosition()
        blk = self.blocks[rail]
        self._focus = (rail, pos)
        if pos >= len(blk["rows"]):
            # «Ver todas ›»: la rejilla completa del bloque.
            from section import SectionWindow
            win = SectionWindow("section.xml", self.addon_path, "Default",
                                "1080i", catalog=self.catalog,
                                userdata=self.userdata,
                                playback=self.playback, vault=self.vault,
                                addon_path=self.addon_path,
                                profile=self.profile, kind=self.kind,
                                spec=blk["spec"], titulo=blk["titulo"])
            win.doModal()
            del win
            return
        row = blk["rows"][pos]
        from detail import DetailWindow
        win = DetailWindow("detail.xml", self.addon_path, "Default", "1080i",
                           catalog=self.catalog, userdata=self.userdata,
                           playback=self.playback, vault=self.vault,
                           addon_path=self.addon_path, profile=self.profile,
                           kind=row.get("kind") or self.kind,
                           tmdb=int(row["tmdb"]))
        win.doModal()
        del win
