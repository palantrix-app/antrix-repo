# -*- coding: utf-8 -*-
"""Diálogos PROPIOS de PalAntriX (requisito global §7 del repaso).

Ningún diálogo de Kodi (xbmcgui.Dialog, DialogProgress, xbmc.Keyboard)
puede aparecer en la app: todo lo que el usuario ve — mensajes,
confirmaciones, selectores, avisos, esperas y entradas de texto —
usa las ventanas de la casa, con el fondo, la tipografía y los
botones de la app.

API:
- ok(titulo, texto)                     mensaje con «Aceptar»
- confirm(titulo, texto, si, no) -> bool
- select(titulo, opciones, sub) -> int  selector visual de la casa
                                        (playui.SelectorWindow); -1 si sale
- notify(texto, ms=3000)                aviso breve no bloqueante (toast)
- Busy()                                sustituto de DialogProgress:
                                        create/update/iscanceled/close
- ask_text(titulo, inicial, hidden)     teclado propio de la casa;
                                        None si se cancela
"""
import threading

import xbmc
import xbmcaddon
import xbmcgui

ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo("path")

ATRAS = (9, 10, 92)


def _win(name, cls, **kwargs):
    return cls(name, ADDON_PATH, "Default", "1080i", **kwargs)


# ---------------------------------------------------------------------------
# Mensaje / confirmación (1314)
# ---------------------------------------------------------------------------
class MessageWindow(xbmcgui.WindowXML):
    LBL_TITULO = 920
    TXT_TEXTO = 930
    BTN_A = 940
    BTN_B = 941

    def __init__(self, *args, **kwargs):
        super(MessageWindow, self).__init__(*args)
        self.titulo = kwargs.get("titulo") or "PalAntriX"
        self.texto = kwargs.get("texto") or ""
        self.label_a = kwargs.get("label_a") or "Aceptar"
        self.label_b = kwargs.get("label_b")  # None = sin segundo botón
        self.result = False

    def onInit(self):
        self.getControl(self.LBL_TITULO).setLabel(self.titulo)
        self.getControl(self.TXT_TEXTO).setText(self.texto)
        a = self.getControl(self.BTN_A)
        a.setLabel(self.label_a)
        b = self.getControl(self.BTN_B)
        if self.label_b:
            b.setLabel(self.label_b)
            b.setVisible(True)
            # Confirmación: el foco arranca en la opción que NO hace
            # nada (la prudente), como en los diálogos clásicos.
            self.setFocusId(self.BTN_B)
        else:
            b.setVisible(False)
            self.setFocusId(self.BTN_A)

    def onAction(self, action):
        aid = action.getId() if hasattr(action, "getId") else 0
        if aid in ATRAS:
            self.result = False
            self.close()
            return
        super(MessageWindow, self).onAction(action)

    def onClick(self, control_id):
        if control_id == self.BTN_A:
            self.result = True
            self.close()
        elif control_id == self.BTN_B:
            self.result = False
            self.close()


def ok(titulo, texto):
    w = _win("dialog.xml", MessageWindow, titulo=titulo, texto=texto)
    w.doModal()
    del w


def confirm(titulo, texto, si="Sí", no="No"):
    w = _win("dialog.xml", MessageWindow, titulo=titulo, texto=texto,
             label_a=si, label_b=no)
    w.doModal()
    res = w.result
    del w
    return res


# ---------------------------------------------------------------------------
# Selector (el de la casa: playui.SelectorWindow, 1312)
# ---------------------------------------------------------------------------
def select(titulo, opciones, subtitulo=""):
    from playui import SelectorWindow
    rows = [{"dest": "row", "titulo": str(o), "nota": "", "payload": i}
            for i, o in enumerate(opciones)]
    if not rows:
        return -1
    w = SelectorWindow("selector.xml", ADDON_PATH, "Default", "1080i",
                       rows=rows, titulo=titulo, subtitulo=subtitulo)
    w.doModal()
    choice = w.choice
    del w
    return -1 if choice is None else int(choice)


# ---------------------------------------------------------------------------
# Aviso breve (toast propio, 1315): no bloquea a quien llama
# ---------------------------------------------------------------------------
class ToastWindow(xbmcgui.WindowXMLDialog):
    LBL_TEXTO = 950

    def __init__(self, *args, **kwargs):
        super(ToastWindow, self).__init__(*args)
        self.texto = kwargs.get("texto") or ""
        self.ms = int(kwargs.get("ms") or 3000)

    def onInit(self):
        try:
            self.getControl(self.LBL_TEXTO).setLabel(self.texto)
        except Exception:
            pass
        t = threading.Thread(target=self._auto)
        t.daemon = True
        t.start()

    def _auto(self):
        mon = xbmc.Monitor()
        mon.waitForAbort(self.ms / 1000.0)
        try:
            self.close()
        except Exception:
            pass

    def onAction(self, action):
        aid = action.getId() if hasattr(action, "getId") else 0
        if aid in ATRAS:
            self.close()
            return
        # Cualquier otra tecla también lo despide: es un aviso, no una
        # pantalla; pero la acción debe seguir su curso en la ventana
        # de debajo, así que solo cerramos con atrás/select.
        if aid in (7,):
            self.close()
            return
        super(ToastWindow, self).onAction(action)


_toast_lock = threading.Lock()


def notify(texto, ms=3000):
    """Aviso breve con el diseño de la casa. Sustituye a
    Dialog().notification en toda la app (§7). Si ya hay un aviso en
    pantalla, el nuevo se descarta (no se apilan)."""
    def run():
        if not _toast_lock.acquire(False):
            return
        try:
            w = ToastWindow("toast.xml", ADDON_PATH, "Default", "1080i",
                            texto=texto, ms=ms)
            w.doModal()
            del w
        except Exception as e:
            xbmc.log("PalAntriX toast: %s" % type(e).__name__,
                     xbmc.LOGWARNING)
        finally:
            _toast_lock.release()
    t = threading.Thread(target=run)
    t.daemon = True
    t.start()


# ---------------------------------------------------------------------------
# Espera con cancelación (sustituto de DialogProgress, 1314 en modo busy)
# ---------------------------------------------------------------------------
class BusyWindow(xbmcgui.WindowXML):
    LBL_TITULO = 920
    LBL_LINEA = 930
    BTN_CANCELAR = 941

    def __init__(self, *args, **kwargs):
        super(BusyWindow, self).__init__(*args)
        self.titulo = kwargs.get("titulo") or "PalAntriX"
        self.linea = kwargs.get("linea") or ""
        self.owner = kwargs.get("owner")
        self.canceled = False

    def onInit(self):
        try:
            self.getControl(self.LBL_TITULO).setLabel(self.titulo)
            self.getControl(self.LBL_LINEA).setLabel(self.linea)
            b = self.getControl(self.BTN_CANCELAR)
            b.setLabel("Cancelar")
            self.setFocusId(self.BTN_CANCELAR)
        except Exception:
            pass
        if self.owner is not None:
            self.owner._ready.set()

    def set_line(self, linea):
        self.linea = linea
        try:
            self.getControl(self.LBL_LINEA).setLabel(linea)
        except Exception:
            pass

    def onAction(self, action):
        aid = action.getId() if hasattr(action, "getId") else 0
        if aid in ATRAS:
            self.canceled = True
            self.close()
            return
        super(BusyWindow, self).onAction(action)

    def onClick(self, control_id):
        if control_id == self.BTN_CANCELAR:
            self.canceled = True
            self.close()


class Busy(object):
    """Misma forma que xbmcgui.DialogProgress (create/update/
    iscanceled/close) pero pintado con la ventana de la casa.
    La ventana vive en su propio hilo (doModal) y las etiquetas se
    actualizan desde el hilo de trabajo, como hace LoadingWindow
    con sus fases."""

    def __init__(self):
        self._win = None
        self._ready = threading.Event()
        self._thread = None

    def create(self, titulo, linea=""):
        self._win = BusyWindow("busy.xml", ADDON_PATH, "Default", "1080i",
                               titulo=titulo, linea=linea, owner=self)
        self._thread = threading.Thread(target=self._run)
        self._thread.daemon = True
        self._thread.start()
        self._ready.wait(5)

    def _run(self):
        try:
            self._win.doModal()
        except Exception as e:
            xbmc.log("PalAntriX busy: %s" % type(e).__name__,
                     xbmc.LOGWARNING)
            self._ready.set()

    def update(self, pct=0, linea=None):
        if linea is not None and self._win is not None:
            self._win.set_line(linea)

    def iscanceled(self):
        return bool(self._win is not None and self._win.canceled)

    def close(self):
        if self._win is not None:
            try:
                self._win.close()
            except Exception:
                pass


# ---------------------------------------------------------------------------
# Entrada de texto con el teclado de la casa (1316)
# ---------------------------------------------------------------------------
KEYS = list("ABCDEFGHIJKLMNOPQRSTUVWXYZ") + list("0123456789") \
    + ["Á", "É", "Í", "Ó", "Ú", "Ñ"]


class InputWindow(xbmcgui.WindowXML):
    KEYS_ID = 400
    LBL_TITULO = 920
    LBL_TEXTO = 950
    BTN_ESPACIO = 420
    BTN_BORRAR = 421
    BTN_HECHO = 440
    BTN_CANCELAR = 441

    def __init__(self, *args, **kwargs):
        super(InputWindow, self).__init__(*args)
        self.titulo = kwargs.get("titulo") or ""
        self.texto = kwargs.get("inicial") or ""
        self.hidden = bool(kwargs.get("hidden"))
        self.result = None

    def _pinta(self):
        txt = "•" * len(self.texto) if self.hidden else self.texto
        self.getControl(self.LBL_TEXTO).setLabel(txt + "|")

    def onInit(self):
        self.getControl(self.LBL_TITULO).setLabel(self.titulo)
        lst = self.getControl(self.KEYS_ID)
        lst.reset()
        items = []
        for k in KEYS:
            li = xbmcgui.ListItem(label=k)
            li.setProperty("key", k)
            items.append(li)
        lst.addItems(items)
        self._pinta()
        self.setFocusId(self.KEYS_ID)

    def onAction(self, action):
        aid = action.getId() if hasattr(action, "getId") else 0
        if aid in ATRAS:
            self.result = None
            self.close()
            return
        super(InputWindow, self).onAction(action)

    def onClick(self, control_id):
        if control_id == self.KEYS_ID:
            item = self.getControl(self.KEYS_ID).getSelectedItem()
            if item:
                self.texto += item.getProperty("key")
                self._pinta()
        elif control_id == self.BTN_ESPACIO:
            self.texto += " "
            self._pinta()
        elif control_id == self.BTN_BORRAR:
            self.texto = self.texto[:-1]
            self._pinta()
        elif control_id == self.BTN_HECHO:
            self.result = self.texto
            self.close()
        elif control_id == self.BTN_CANCELAR:
            self.result = None
            self.close()


def ask_text(titulo, inicial="", hidden=False):
    """Teclado propio: devuelve el texto (sin recortar) o None si se
    cancela. Sustituye a xbmc.Keyboard y a Dialog().input (§7)."""
    w = _win("input.xml", InputWindow, titulo=titulo, inicial=inicial,
             hidden=hidden)
    w.doModal()
    res = w.result
    del w
    return res
