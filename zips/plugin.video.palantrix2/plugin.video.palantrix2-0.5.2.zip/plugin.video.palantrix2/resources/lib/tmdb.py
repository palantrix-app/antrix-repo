# -*- coding: utf-8 -*-
"""TMDB en tiempo real para la ficha (§3).

El catálogo rescatado no trae reparto ni fotogramas de episodios, y
la ficha nueva los necesita (barra inferior: actores en películas,
últimos capítulos en series). Se consulta la API pública de TMDB
con la clave del ecosistema Antrix — la misma que usa la cosecha
diaria — y se cachea por sesión. Sin red o sin datos, devuelve
listas vacías y la ficha cae a sus recursos de siempre.
"""
import requests

TMDB_KEY = "f2e500501d9fa3bd1637bfd00f11583a"  # clave TMDB del ecosistema Antrix
API = "https://api.themoviedb.org/3"
IMG = "https://image.tmdb.org/t/p/"

_cache = {}


def _get(path):
    if path in _cache:
        return _cache[path]
    data = None
    try:
        r = requests.get(API + path,
                         params={"api_key": TMDB_KEY, "language": "es-ES"},
                         timeout=8)
        if r.status_code == 200:
            data = r.json()
    except Exception:
        data = None
    _cache[path] = data
    return data


def movie_cast(tmdb, limit=14):
    """[{id, nombre, foto, personaje}] del reparto principal."""
    d = _get("/movie/%d/credits" % int(tmdb))
    out = []
    for c in (d or {}).get("cast") or []:
        out.append({
            "id": c.get("id"),
            "nombre": c.get("name") or "",
            "foto": (IMG + "w185" + c["profile_path"])
                    if c.get("profile_path") else "",
            "personaje": c.get("character") or "",
        })
        if len(out) >= limit:
            break
    return out


def person_movie_ids(person_id, limit=80):
    """Ids TMDB de las películas de una persona, por popularidad."""
    d = _get("/person/%d/movie_credits" % int(person_id))
    cast = [c for c in (d or {}).get("cast") or [] if c.get("id")]
    cast.sort(key=lambda c: -(c.get("popularity") or 0))
    return [int(c["id"]) for c in cast[:limit]]


def season_episodes(tmdb, temporada):
    """{nº episodio: {nombre, still}} de una temporada."""
    d = _get("/tv/%d/season/%d" % (int(tmdb), int(temporada)))
    out = {}
    for e in (d or {}).get("episodes") or []:
        if e.get("episode_number") is None:
            continue
        out[int(e["episode_number"])] = {
            "nombre": e.get("name") or "",
            "still": (IMG + "w300" + e["still_path"])
                     if e.get("still_path") else "",
        }
    return out
