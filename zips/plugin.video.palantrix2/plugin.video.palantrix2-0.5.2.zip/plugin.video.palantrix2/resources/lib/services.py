# -*- coding: utf-8 -*-
"""Ventana Servicios (1308) — Fase 3 del mapa aprobado (D3).

Servicios es nodo propio de la raíz, separado de Ajustes: aquí viven las
cuentas y las llaves (AllDebrid, Trakt, Bóveda) y el Catálogo. Una fila
por servicio con su estado como parte de la fila; vinculación por código
sin salir de la app (pantalla propia 1309); la configuración inicial de
Trakt va en un asistente en lenguaje llano (1310). La gestión de la
bóveda se muda aquí desde Ajustes reutilizando vault.py / unlock_ui.py
sin tocar su criptografía.
"""
import datetime
import json
import os
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui

import dialogs
import menus
import update
from menus import fmt_num

ADDON = xbmcaddon.Addon()
LIST_ID = 300
LBL_TITULO = 920
TXT_NOTA = 975

ACTION_MOVE_UP = menus.ACTION_MOVE_UP
ACTION_MOVE_DOWN = menus.ACTION_MOVE_DOWN


def _hoy():
    return datetime.datetime.now().strftime("%d/%m/%Y")


def _notify(text):
    dialogs.notify(text)


# ---------------------------------------------------------------------------
# Estados (con caché de sesión: abrir Servicios no debe martillear la red)
# ---------------------------------------------------------------------------
_AD_CACHE = {"key": None, "t": 0.0, "info": None}


def alldebrid_info(force=False):
    """{'texto', 'user', 'premium'} consultando la cuenta de verdad.
    Sin clave: {'texto': 'Sin vincular', ...}. Con la cuenta caducada,
    el texto lo dice («Caducado») en vez de fallar luego al reproducir."""
    key = (ADDON.getSetting("alldebrid_apikey") or "").strip()
    if not key:
        return {"texto": "Sin vincular", "user": "", "premium": False}
    now = time.time()
    if (not force and _AD_CACHE["key"] == key and _AD_CACHE["info"] is not None
            and now - _AD_CACHE["t"] < 60):
        return _AD_CACHE["info"]
    from alldebrid import AllDebrid, AllDebridError
    try:
        u = AllDebrid(key).user(timeout=8)
    except AllDebridError as e:
        # Diagnóstico honesto (sup5-M2): un fallo de red no es lo mismo
        # que una clave rechazada por la API.
        texto = "Sin conexión" if getattr(e, "transport", False) \
            else "Clave no válida"
        info = {"texto": texto, "user": "", "premium": False}
        _AD_CACHE.update({"key": key, "t": now, "info": info})
        return info
    except Exception:
        info = {"texto": "Sin conexión", "user": "", "premium": False}
        _AD_CACHE.update({"key": key, "t": now, "info": info})
        return info
    user = u.get("username") or "tu cuenta"
    if not u.get("isPremium"):
        info = {"texto": "Caducado · %s" % user, "user": user, "premium": False}
    else:
        pu = u.get("premiumUntil") or 0
        try:
            pu = int(pu)
        except Exception:
            pu = 0
        if pu:
            dias = int((pu - now + 86399) // 86400)
            if dias < 0:
                info = {"texto": "Caducado · %s" % user, "user": user,
                        "premium": False}
            else:
                info = {"texto": "Premium · %s · quedan %d días" % (user, dias),
                        "user": user, "premium": True}
        else:
            info = {"texto": "Premium · %s" % user, "user": user, "premium": True}
    _AD_CACHE.update({"key": key, "t": now, "info": info})
    return info


_LIVE_CACHE = {"t": 0.0, "texto": None}


def live_state(force=False):
    """Sondeo ligero de la capa en vivo (los endpoints de live.py)."""
    if not (ADDON.getSetting("alldebrid_apikey") or "").strip():
        return "Necesita AllDebrid"
    now = time.time()
    if not force and _LIVE_CACHE["texto"] is not None and now - _LIVE_CACHE["t"] < 120:
        return _LIVE_CACHE["texto"]
    import requests
    # Operativa = la fuente responde 200 de verdad (sup5-M5): un 404
    # de una fuente caída no cuenta. Zilean ya no se sondea: la capa en
    # vivo dejó de usarla (404 permanente, sup4-H6).
    ok = False
    try:
        r = requests.get("https://apibay.org/q.php?q=a",
                         headers={"User-Agent": "PalAntriX/0.2"}, timeout=4)
        ok = (r.status_code == 200)
    except Exception:
        ok = False
    texto = "Operativa" if ok else "Sin conexión"
    _LIVE_CACHE.update({"t": now, "texto": texto})
    return texto


def trakt_state_text():
    import trakt
    if not trakt.configured():
        return "Pendiente de configuración"
    if not trakt.linked():
        return "Listo para vincular"
    user = (ADDON.getSetting("trakt_user") or "").strip() or "tu cuenta"
    ls = trakt.last_sync()
    if ls:
        return "%s · Sincronizado (%s)" % (user, ls)
    return "%s · Vinculado" % user


def vault_state_text(vault):
    if vault is None:
        return "No disponible"
    if not vault.unlocked:
        return "Bloqueada"
    if vault.mode == "master":
        return "Abierta · Maestra"
    if vault.mode == "bootstrap":
        return "Abierta · Instalación"
    return "Abierta · «%s»" % (vault.slot_name or "Acceso")


# ---------------------------------------------------------------------------
# Metadatos de accesos (creado / último uso) — la tabla wraps no los guarda
# y no se toca; viven en un JSON del perfil, indexados por id de ranura.
# ---------------------------------------------------------------------------
def _meta_path(profile):
    return os.path.join(profile, "accesos_meta.json")


def _meta_load(profile):
    try:
        with open(_meta_path(profile)) as f:
            return json.load(f)
    except Exception:
        return {}


def _meta_save(profile, meta):
    try:
        with open(_meta_path(profile), "w") as f:
            json.dump(meta, f)
    except Exception:
        pass


def _meta_note(profile, slot_id):
    m = _meta_load(profile).get(str(slot_id)) or {}
    partes = []
    if m.get("creado"):
        partes.append("creado el %s" % m["creado"])
    if m.get("uso"):
        partes.append("último uso %s" % m["uso"])
    return " · ".join(partes)


def _meta_stamp_use(profile, vault):
    """Si la sesión es de una ranura, anota su último uso (hoy).
    Se sella por ID de ranura, no por nombre (sup5-M4): dos accesos
    con el mismo nombre no se pisan los metadatos."""
    if vault is None or not vault.unlocked or vault.mode != "slot":
        return
    sid = getattr(vault, "slot_id", None)
    if sid is None:
        return
    meta = _meta_load(profile)
    ent = meta.get(str(sid)) or {}
    if ent.get("uso") != _hoy():
        ent["uso"] = _hoy()
        meta[str(sid)] = ent
        _meta_save(profile, meta)


# ---------------------------------------------------------------------------
# Pantalla de código (1309): vinculación AllDebrid / Trakt
# ---------------------------------------------------------------------------
class PinLinkWindow(xbmcgui.WindowXML):
    LBL_TITULO = 920
    TXT_TEXTO = 930
    BTN_CANCELAR = 940
    LBL_CODIGO = 950
    LBL_CUENTA = 960

    def __init__(self, *args, **kwargs):
        super(PinLinkWindow, self).__init__(*args)
        self.titulo = kwargs.get("titulo") or ""
        self.texto = kwargs.get("texto") or ""
        self.codigo = kwargs.get("codigo") or ""
        self.segundos = int(kwargs.get("segundos") or 600)
        self.intervalo = int(kwargs.get("intervalo") or 5)
        self.poll = kwargs.get("poll")
        self.result = False
        self.expired = False
        self._stop = threading.Event()

    def onInit(self):
        self.getControl(self.LBL_TITULO).setLabel(self.titulo)
        self.getControl(self.TXT_TEXTO).setText(self.texto)
        self.getControl(self.LBL_CODIGO).setLabel(self.codigo)
        self.getControl(self.LBL_CUENTA).setLabel("")
        self.setFocusId(self.BTN_CANCELAR)
        t = threading.Thread(target=self._run)
        t.daemon = True
        t.start()

    def _run(self):
        mon = xbmc.Monitor()
        fin = time.time() + self.segundos
        next_poll = 0.0
        while not self._stop.is_set() and not mon.abortRequested():
            ahora = time.time()
            quedan = fin - ahora
            if quedan <= 0:
                self.expired = True
                break
            try:
                self.getControl(self.LBL_CUENTA).setLabel(
                    "Te quedan %d:%02d para introducirlo"
                    % (int(quedan) // 60, int(quedan) % 60))
            except Exception:
                pass
            if ahora >= next_poll:
                try:
                    res = self.poll() if self.poll else "pending"
                except Exception:
                    res = "pending"
                if res == "ok":
                    self.result = True
                    break
                if res == "error":
                    self.expired = True
                    break
                next_poll = ahora + self.intervalo
            if mon.waitForAbort(0.5):
                break
        if not self._stop.is_set():
            try:
                self.close()
            except Exception:
                pass

    def onAction(self, action):
        aid = action.getId() if hasattr(action, "getId") else 0
        if aid in (9, 92):  # atrás = cancelar la vinculación
            self._stop.set()
            self.close()
            return
        super(PinLinkWindow, self).onAction(action)

    def onClick(self, control_id):
        if control_id == self.BTN_CANCELAR:
            self._stop.set()
            self.close()


def _open_pin(win, titulo, texto, codigo, segundos, intervalo, poll):
    w = PinLinkWindow("pinlink.xml", win.addon_path, "Default", "1080i",
                      titulo=titulo, texto=texto, codigo=codigo,
                      segundos=segundos, intervalo=intervalo, poll=poll)
    w.doModal()
    result, expired = w.result, w.expired
    del w
    return result, expired


# ---------------------------------------------------------------------------
# Flujos de vinculación
# ---------------------------------------------------------------------------
def alldebrid_link_flow(win):
    import alldebrid
    info = alldebrid.pin_get()
    if not info:
        dialogs.ok("AllDebrid",
                            "AllDebrid no responde ahora mismo. Inténtalo en un rato.")
        return False
    holder = {}

    def poll():
        key = alldebrid.pin_check(info["check"], info["pin"])
        if key is False:
            # Error definitivo de la API (código no válido o caducado):
            # la ventana sale con el aviso en vez de colgarse (21/11).
            return "error"
        if key:
            holder["key"] = key
            return "ok"
        return "pending"

    ok, expired = _open_pin(
        win, "Vincular AllDebrid",
        "Entra en [B]alldebrid.com/pin[/B] desde el móvil u ordenador "
        "e introduce este código:",
        info["pin"], info["expires_in"], 5, poll)
    if ok and holder.get("key"):
        ADDON.setSetting("alldebrid_apikey", holder["key"])
        _AD_CACHE.update({"key": None, "t": 0.0, "info": None})
        _notify("AllDebrid · Cuenta vinculada")
        return True
    if expired:
        dialogs.ok("AllDebrid",
                            "El código ha caducado. Vuelve a intentarlo.")
    return False


def _sync_result_dialog(res):
    """El resultado de una sincronización de Trakt, HONESTO (§6):
    si una parte falló, se dice cuál y NO se presenta como completa
    (y la fecha no se sella: eso lo decide quien llama con res['ok'])."""
    if res.get("ok"):
        dialogs.ok(
            "Trakt",
            "Historial sincronizado: %d películas, %d episodios, "
            "%d en tu lista." % (res["movies"], res["episodes"],
                                 res["watchlist"]))
    else:
        fallos = " y ".join(res.get("errors") or ["una parte"])
        dialogs.ok(
            "Trakt",
            "La sincronización NO ha sido completa: ha fallado %s.\n\n"
            "Lo demás sí ha llegado: %d películas, %d episodios, "
            "%d en tu lista. La fecha de sincronización no se marca "
            "como buena; vuelve a intentarlo en un rato."
            % (fallos, res["movies"], res["episodes"], res["watchlist"]))


def trakt_link_flow(win):
    import trakt
    st = trakt.start_link()
    if not st:
        dialogs.ok("Trakt",
                            "Trakt no responde ahora mismo. Inténtalo en un rato.")
        return False
    holder = {}

    def poll():
        r = trakt.poll_link(st["device_code"])
        if r == "denied":
            # Denegación en trakt.tv (403): no es una caducidad
            # (sup5-M3); se anota la causa para el mensaje final.
            holder["denied"] = True
            return "error"
        return {True: "ok", False: "error", None: "pending"}[r]

    url = st.get("verification_url") or "https://auth.trakt.tv/activate"
    host = url.split("://", 1)[-1].rstrip("/")
    ok, expired = _open_pin(
        win, "Vincular Trakt",
        "Entra en [B]%s[/B] desde el móvil u ordenador "
        "e introduce este código:" % host,
        st["user_code"], st["expires_in"], st["interval"], poll)
    if not ok:
        if holder.get("denied"):
            dialogs.ok("Trakt",
                                "Has denegado el acceso en Trakt. Si fue "
                                "sin querer, vuelve a intentarlo y acepta.")
        elif expired:
            dialogs.ok("Trakt",
                                "El código ha caducado. Vuelve a intentarlo.")
        return False
    _notify("Trakt · Cuenta vinculada")
    if getattr(win, "userdata", None):
        res = trakt.sync_in(win.userdata)
        if res.get("ok"):
            trakt.mark_sync()
        _sync_result_dialog(res)
    return True


# ---------------------------------------------------------------------------
# Asistente de configuración de Trakt (1310)
# ---------------------------------------------------------------------------
class TraktSetupWindow(xbmcgui.WindowXML):
    LBL_TITULO = 920
    TXT_PASOS = 930
    BTN_ID = 941
    BTN_SECRET = 942
    BTN_VINCULAR = 943

    PASOS = ("PalAntriX ya trae las claves de su propia app de Trakt: "
             "para vincular tu cuenta basta el código, como en AllDebrid, "
             "sin registrar nada.\n\n"
             "Esta pantalla es solo para quien prefiera usar su propia "
             "app de Trakt registrada a su nombre:\n\n"
             "1. En el móvil u ordenador entra en [B]trakt.tv[/B] > "
             "Settings > API Apps y crea una app (nombre: PalAntriX; "
             "Redirect URI: urn:ietf:wg:oauth:2.0:oob).\n"
             "2. Pega aquí el [B]Client ID[/B] de tu app.\n"
             "3. Si tu app tiene [B]Client Secret[/B], pégalo también "
             "(las apps nuevas de Trakt ya no emiten secreto: es PKCE "
             "y no hace falta).\n"
             "4. Después vincula tu cuenta con el código, como AllDebrid.")

    def __init__(self, *args, **kwargs):
        super(TraktSetupWindow, self).__init__(*args)
        self.catalog = kwargs.get("catalog")
        self.userdata = kwargs.get("userdata")
        self.playback = kwargs.get("playback")
        self.vault = kwargs.get("vault")
        self.addon_path = kwargs.get("addon_path")
        self.profile = kwargs.get("profile", "")
        self._linked_now = False
        self._inited = False
        self._last_btn = self.BTN_ID

    def onInit(self):
        if self._inited:
            from nav import unwind_home
            if unwind_home(self):
                return
            # Reactivación tras cerrar el teclado o la pantalla de
            # código: se conserva el botón donde estaba el usuario
            # (sup1-M12), solo se refrescan las etiquetas.
            self._refresh()
            try:
                self.setFocusId(self._last_btn)
            except Exception:
                pass
            return
        self._inited = True
        self.getControl(self.LBL_TITULO).setLabel("Configurar Trakt")
        self.getControl(self.TXT_PASOS).setText(self.PASOS)
        self._refresh()
        self.setFocusId(self.BTN_ID)

    def onFocus(self, control_id):
        if control_id in (self.BTN_ID, self.BTN_SECRET, self.BTN_VINCULAR):
            self._last_btn = control_id

    def _refresh(self):
        import trakt
        self.getControl(self.BTN_ID).setLabel(
            "Client ID · guardado" if trakt._s("trakt_client_id")
            else "Pegar el Client ID")
        self.getControl(self.BTN_SECRET).setLabel(
            "Client Secret · guardado" if trakt._s("trakt_client_secret")
            else "Pegar el Client Secret")

    def _save_key(self, setting, valor):
        import trakt
        if valor and valor != trakt._s(setting):
            ADDON.setSetting(setting, valor)
            # Unas claves nuevas invalidan el token de la app anterior.
            trakt.unlink()
            self._refresh()

    def onClick(self, control_id):
        from nav import topbar_click
        if topbar_click(self, control_id):
            return
        import trakt
        import unlock_ui
        if control_id == self.BTN_ID:
            val = unlock_ui._ask("Pega el Client ID de tu app de Trakt",
                                 hidden=False)
            if val:
                self._save_key("trakt_client_id", val)
        elif control_id == self.BTN_SECRET:
            val = unlock_ui._ask("Pega el Client Secret de tu app de Trakt",
                                 hidden=True)
            if val:
                self._save_key("trakt_client_secret", val)
        elif control_id == self.BTN_VINCULAR:
            if not trakt.configured():
                dialogs.ok(
                    "Trakt",
                    "Primero pega el Client ID de tu app (paso 2).")
                return
            if trakt_link_flow(self):
                self._linked_now = True
                self.close()


# ---------------------------------------------------------------------------
# Ventana Servicios (1308)
# ---------------------------------------------------------------------------
_NOTAS = {
    "boveda": ("Accesos locales: viven solo en este dispositivo.\n"
               "Accesos remotos: se crean aquí y valen en los aparatos "
               "de tus familiares cuando sincronizan.\n"
               "Un PIN olvidado no se puede ver: se revoca y se crea "
               "otro."),
    "accesos": ("Toca un acceso para revocarlo o, si es remoto, para "
                "darle un código de activación nuevo.\n"
                "Revocar un acceso remoto surte efecto en cada aparato "
                "cuando sincronice al abrir la app."),
}


class ServicesWindow(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        super(ServicesWindow, self).__init__(*args)
        self.catalog = kwargs.get("catalog")
        self.userdata = kwargs.get("userdata")
        self.playback = kwargs.get("playback")
        self.vault = kwargs.get("vault")
        self.addon_path = kwargs.get("addon_path")
        self.profile = kwargs.get("profile", "")
        self.screen = kwargs.get("screen") or "root"
        self.display = []
        self._pos = 0

    # ---------- filas por pantalla ----------
    def _row(self, titulo, nota, action, ayuda=""):
        return {"dest": "row", "titulo": titulo, "nota": nota,
                "action": action, "ayuda": ayuda}

    def _header(self, titulo):
        return {"dest": "header", "titulo": titulo, "nota": "",
                "action": None, "ayuda": ""}

    def _rows(self):
        if self.screen == "alldebrid":
            return self._rows_alldebrid()
        if self.screen == "trakt":
            return self._rows_trakt()
        if self.screen == "boveda":
            return self._rows_boveda()
        if self.screen == "accesos":
            return self._rows_accesos()
        return self._rows_root()

    def _rows_root(self):
        _meta_stamp_use(self.profile, self.vault)
        ver, total, check = update.catalog_info(self.profile)
        ad = alldebrid_info()
        return [
            self._header("CUENTAS"),
            self._row("AllDebrid", ad["texto"], "root_ad",
                      "AllDebrid desbloquea los enlaces de la base para "
                      "poder reproducir."),
            self._row("Trakt", trakt_state_text(), "root_trakt",
                      "Trakt guarda tus Favoritos y sincroniza lo que ves."),
            self._header("BÓVEDA DE ENLACES"),
            self._row("Bóveda", vault_state_text(self.vault), "root_boveda",
                      "Los enlaces viven cifrados: solo se abren al "
                      "reproducir, nunca al navegar."),
            self._header("CATÁLOGO"),
            self._row("Catálogo", "v%s · %s títulos" % (ver, fmt_num(total)),
                      "root_catalogo",
                      "Última comprobación: %s." % (check or "nunca")),
            self._row("Buscar actualizaciones", "", "root_update",
                      "Descarga los títulos nuevos y mezcla los enlaces "
                      "sin tocar tu bóveda."),
            self._row("Capa en vivo", live_state(), "root_live",
                      "El respaldo: si un enlace de la base falla, se "
                      "busca en vivo."),
        ]

    def _rows_alldebrid(self):
        info = alldebrid_info()
        rows = [self._header("CUENTA")]
        rows.append(self._row(info["user"] or "AllDebrid", info["texto"], None))
        rows.append(self._row("Desvincular", "", "ad_unlink",
                              "Sin AllDebrid no se puede reproducir nada."))
        rows.append(self._row("Volver", "", "back"))
        return rows

    def _rows_trakt(self):
        user = (ADDON.getSetting("trakt_user") or "").strip() or "Tu cuenta"
        rows = [self._header("CUENTA"),
                self._row(user, trakt_state_text(), None),
                self._row("Sincronizar ahora", "", "tk_sync",
                          "Trae tus vistos y tu lista de Trakt a esta tele."),
                self._row("Desvincular", "", "tk_unlink",
                          "Lo ya sincronizado en esta tele se queda."),
                self._row("Cambiar las claves de la app", "", "tk_setup",
                          "Por defecto valen las claves de la app de "
                          "PalAntriX; aquí solo si quieres usar tu propia "
                          "app de Trakt."),
                self._row("Volver", "", "back")]
        return rows

    def _rows_boveda(self):
        import remote
        v = self.vault
        rows = [self._header("ESTADO")]
        if v is None:
            rows.append(self._row("Bóveda", "No disponible", None))
            return rows
        guest = remote.is_guest(self.profile)
        estado = vault_state_text(v)
        if guest and not v.unlocked:
            st = remote.load_state(self.profile)
            estado = "Invitado · «%s»" % (st.get("nombre") or "Acceso")
        rows.append(self._row("Estado", estado, "bv_toggle",
                              "Desbloquear pide tu PIN o tu maestra; la "
                              "sesión dura hasta que cierres la app."))
        rows.append(self._row("Sincronizar accesos", "", "bv_sync",
                              "Trae los accesos nuevos y aplica las "
                              "revocaciones. Nunca bloquea la app."))
        if guest:
            rows.append(self._row(
                "Modo invitado", "Sin administración en este aparato",
                None,
                "Este aparato se activó con un código: aquí solo se "
                "entra con su PIN. Los accesos se gestionan desde el "
                "dispositivo del administrador."))
            return rows
        if not v.has_master():
            rows.append(self._row("Crear contraseña maestra", "Solo tuya",
                                  "bv_master"))
            if v.has_bootstrap():
                rows.append(self._row(
                    "Tengo un código de activación", "", "bv_activate",
                    "Si el administrador te ha dado un código, actívalo "
                    "aquí: este aparato quedará en modo invitado, con "
                    "tu PIN y sin contraseña maestra."))
        else:
            rows.append(self._row("Cambiar contraseña maestra", "", "bv_master",
                                  "Pide la actual y la nueva dos veces; no "
                                  "toca enlaces ni accesos."))
        n = len(v.list_slots()) + len(remote.registry_slots(self.profile))
        rows.append(self._row("Gestionar accesos",
                              "%d acceso%s" % (n, "s" if n != 1 else "") if n else "",
                              "bv_accesos",
                              "PINs para familiares: locales de este "
                              "aparato o remotos para los suyos; solo "
                              "con tu maestra."))
        return rows

    def _rows_accesos(self):
        import remote
        rows = [self._header("ACCESOS"),
                self._row("+ Nuevo acceso", "Local o remoto", "acc_new")]
        if self.vault is not None:
            for s in self.vault.list_slots():
                rows.append(self._row(
                    s["name"], _meta_note(self.profile, s["id"]),
                    "acc_revoke:%d" % s["id"],
                    "Acceso local: toca para revocarlo."))
        for s in remote.registry_slots(self.profile):
            nota = "Remoto"
            if s.get("aparato"):
                nota += " · %s" % s["aparato"]
            if s.get("pendiente"):
                nota += " · Pendiente de activación"
            if s.get("creado"):
                nota += " · creado el %s" % s["creado"]
            rows.append(self._row(
                s["name"], nota, "accrem:%s" % s["rid"],
                "Acceso remoto: toca para revocarlo o darle un "
                "código de activación nuevo."))
        return rows

    _TITULOS = {"root": "Servicios", "alldebrid": "AllDebrid",
                "trakt": "Trakt", "boveda": "Bóveda",
                "accesos": "Gestionar accesos"}

    # ---------- lista ----------
    def _fill(self, keep_pos=True):
        self.display = self._rows()
        lst = self.getControl(LIST_ID)
        pos = lst.getSelectedPosition() if keep_pos else self._first_actionable()
        lst.reset()
        items = []
        for node in self.display:
            li = xbmcgui.ListItem(label=node["titulo"])
            if node["dest"] == "header":
                li.setProperty("header", "1")
            else:
                li.setLabel2(node["nota"] or "")
                li.setProperty("action", node["action"] or "")
            items.append(li)
        lst.addItems(items)
        if self.display:
            lst.selectItem(min(max(pos, 0), len(self.display) - 1))
            self._pos = lst.getSelectedPosition()
        nota = _NOTAS.get(self.screen)
        if nota:
            self.getControl(TXT_NOTA).setText(nota)
        else:
            self._preview(self._pos)

    def _first_actionable(self):
        # Primera fila con ACCIÓN real (sup1-M11): las filas de estado
        # (action=None) no reciben el foco inicial.
        for i, node in enumerate(self.display):
            if node["dest"] != "header" and node.get("action"):
                return i
        for i, node in enumerate(self.display):
            if node["dest"] != "header":
                return i
        return 0

    def _preview(self, pos):
        if self.screen in _NOTAS:
            return
        if 0 <= pos < len(self.display):
            self.getControl(TXT_NOTA).setText(
                self.display[pos].get("ayuda") or "")

    def onInit(self):
        self.getControl(LBL_TITULO).setLabel(self._TITULOS.get(self.screen,
                                                              "Servicios"))
        reactivacion = getattr(self, "_inited", False)
        self._inited = True
        if reactivacion:
            from nav import unwind_home
            if unwind_home(self):
                return
        # Al volver de una ventana hija se rellenan los estados (pueden
        # haber cambiado: vincular, bloquear…) conservando la posición.
        self._fill(keep_pos=reactivacion)
        self.setFocusId(LIST_ID)

    def onAction(self, action):
        super(ServicesWindow, self).onAction(action)
        try:
            lst = self.getControl(LIST_ID)
            pos = lst.getSelectedPosition()
        except Exception:
            return
        if not (0 <= pos < len(self.display)):
            return
        aid = action.getId() if hasattr(action, "getId") else 0
        buena = menus.corregir_posicion(self.display, pos, self._pos, aid)
        if buena != pos:
            lst.selectItem(buena)
            pos = buena
        if pos != self._pos:
            self._pos = pos
            self._preview(pos)

    def _open_screen(self, screen):
        w = ServicesWindow("services.xml", self.addon_path, "Default", "1080i",
                           catalog=self.catalog, userdata=self.userdata,
                           playback=self.playback, vault=self.vault,
                           addon_path=self.addon_path, profile=self.profile,
                           screen=screen)
        w.doModal()
        del w
        self._fill()

    def _open_trakt_setup(self):
        w = TraktSetupWindow("trakt_setup.xml", self.addon_path, "Default",
                             "1080i", catalog=self.catalog,
                             userdata=self.userdata, playback=self.playback,
                             vault=self.vault, addon_path=self.addon_path,
                             profile=self.profile)
        w.doModal()
        del w
        self._fill()

    # ---------- clics ----------
    def onClick(self, control_id):
        from nav import topbar_click
        if topbar_click(self, control_id):
            return
        if control_id != LIST_ID:
            return
        lst = self.getControl(LIST_ID)
        pos = lst.getSelectedPosition()
        if not (0 <= pos < len(self.display)):
            return
        node = self.display[pos]
        if node["dest"] == "header":
            return
        self._pos = pos
        action = node.get("action") or ""
        handler = getattr(self, "_do_" + action.split(":")[0], None) \
            if action else None
        if handler is not None:
            handler(action)
        try:
            self._fill()
        except Exception:
            pass  # el handler pudo cerrar la ventana (Desvincular, Volver)

    # ----- raíz -----
    def _do_root_ad(self, action):
        if not (ADDON.getSetting("alldebrid_apikey") or "").strip():
            alldebrid_link_flow(self)
        else:
            self._open_screen("alldebrid")

    def _do_root_trakt(self, action):
        import trakt
        if not trakt.configured():
            self._open_trakt_setup()
        elif not trakt.linked():
            trakt_link_flow(self)
        else:
            self._open_screen("trakt")

    def _do_root_boveda(self, action):
        self._open_screen("boveda")

    def _do_root_catalogo(self, action):
        ver, total, check = update.catalog_info(self.profile)
        dialogs.ok(
            "Catálogo",
            "Base v%s · %s títulos.\nÚltima comprobación: %s.\n\n"
            "Las actualizaciones mezclan los enlaces nuevos en tu bóveda "
            "sin tocar tu contraseña maestra ni tus accesos."
            % (ver, fmt_num(total), check or "nunca"))

    def _do_root_update(self, action):
        dlg = dialogs.Busy()
        dlg.create("PalAntriX", "Actualizando…")
        try:
            code, msg = update.run_update(self.profile, dlg)
        finally:
            dlg.close()
        dialogs.ok("PalAntriX", msg)

    def _do_root_live(self, action):
        texto = live_state(force=True)
        _notify("Capa en vivo · %s" % texto)

    # ----- AllDebrid -----
    def _do_ad_unlink(self, action):
        info = alldebrid_info()
        if dialogs.confirm(
                "AllDebrid",
                "¿Desvincular AllDebrid (cuenta «%s»)?\n"
                "Sin AllDebrid no se puede reproducir nada."
                % (info["user"] or "tu cuenta")):
            ADDON.setSetting("alldebrid_apikey", "")
            _AD_CACHE.update({"key": None, "t": 0.0, "info": None})
            _notify("AllDebrid desvinculado")
            self.close()

    # ----- Trakt -----
    def _do_tk_sync(self, action):
        import trakt
        if not trakt.linked():
            _notify("Primero vincula tu cuenta de Trakt")
            return
        if self.userdata:
            res = trakt.sync_in(self.userdata)
            # La fecha solo se sella si la sincronización fue COMPLETA
            # (§6): si una parte falló, el diálogo lo dice y la fecha
            # no se marca como buena.
            if res.get("ok"):
                trakt.mark_sync()
            _sync_result_dialog(res)

    def _do_tk_unlink(self, action):
        import trakt
        if dialogs.confirm(
                "Trakt",
                "¿Desvincular tu cuenta de Trakt?\n"
                "Lo ya sincronizado en esta tele se queda; se corta lo "
                "que venga después."):
            trakt.unlink()
            _notify("Trakt desvinculado")
            self.close()

    def _do_tk_setup(self, action):
        self._open_trakt_setup()

    # ----- Bóveda -----
    def _do_bv_toggle(self, action):
        import unlock_ui
        v = self.vault
        if v is None:
            return
        if v.unlocked:
            v.lock()
            _notify("Bóveda bloqueada")
        else:
            unlock_ui.prompt_unlock(v, profile=self.profile)

    def _do_bv_master(self, action):
        import unlock_ui
        v = self.vault
        if v is None:
            return
        if not v.unlocked and not unlock_ui.prompt_unlock(
                v, allow_setup=False, profile=self.profile):
            return
        if not v.is_master:
            if v.unlocked:
                _notify("Necesitas tu contraseña maestra, no un PIN de acceso")
            return
        if v.has_master():
            # CAMBIO de maestra (sup5-B1): el mapa exige pedir la
            # actual y verificarla antes de pedir la nueva dos veces;
            # con la sesión abierta (D1) no basta estar dentro.
            if not unlock_ui.verify_master(v):
                return
        # Sin maestra previa es la CREACIÓN inicial: no hay actual.
        unlock_ui.setup_master(v)

    def _do_bv_accesos(self, action):
        import unlock_ui
        v = self.vault
        if v is None:
            return
        if not v.unlocked and not unlock_ui.prompt_unlock(
                v, profile=self.profile):
            return
        if not v.is_master:
            _notify("La gestión de accesos necesita tu contraseña maestra")
            return
        self._open_screen("accesos")

    # ----- Bóveda: sincronización y activación de invitado -----
    def _do_bv_sync(self, action):
        import remote
        import unlock_ui
        v = self.vault
        if v is None:
            return
        if not v.unlocked and not unlock_ui.prompt_unlock(
                v, profile=self.profile):
            return
        estado, cambios = remote.apply_sync(v, self.profile)
        if estado == "own_revoked":
            v.lock()
            dialogs.ok(
                "PalAntriX",
                "Tu acceso ha sido retirado por el administrador. "
                "Este dispositivo ya no puede abrir la bóveda.")
        elif estado == "offline":
            dialogs.ok(
                "PalAntriX",
                "Sin conexión: no se ha podido sincronizar. Este "
                "dispositivo sigue con sus accesos actuales.")
        elif estado == "invalid":
            dialogs.ok(
                "PalAntriX",
                "La lista de accesos recibida no es válida y se ha "
                "ignorado. Este dispositivo sigue con sus accesos "
                "actuales.")
        else:
            dialogs.ok(
                "PalAntriX",
                "Accesos sincronizados%s."
                % (" · %d cambio%s aplicado%s"
                   % (cambios, "s" if cambios != 1 else "",
                      "s" if cambios != 1 else "") if cambios else ""))

    def _do_bv_activate(self, action):
        import remote
        import unlock_ui
        v = self.vault
        if v is None:
            return
        code = unlock_ui._ask(
            "Escribe el código de activación que te han dado",
            hidden=False)
        if not code:
            return
        ok, msg = remote.activate_guest(v, self.profile, code)
        if not ok:
            dialogs.ok("PalAntriX", msg)
            return
        dialogs.ok("PalAntriX", msg)
        # Confirmación inmediata con su PIN (+ primera sincronización,
        # que ocurre dentro del desbloqueo con perfil).
        unlock_ui.prompt_unlock(v, profile=self.profile)

    # ----- Accesos -----
    def _do_acc_new(self, action):
        v = self.vault
        if v is None or not (v.unlocked and v.is_master):
            return
        tipo = dialogs.select(
            "¿Dónde valdrá el acceso nuevo?",
            ["En este dispositivo (local)",
             "En el dispositivo de un familiar (remoto)"])
        if tipo == 0:
            self._acc_new_local()
        elif tipo == 1:
            self._acc_new_remote()

    def _acc_new_local(self):
        import unlock_ui
        v = self.vault
        name = dialogs.ask_text("Nombre del acceso (p. ej. Marta · Tele comedor)")
        if not name:
            return
        pin = unlock_ui._ask("PIN para «%s» (mínimo 4; mejor 6 o más)" % name)
        if not pin:
            return
        if len(pin) < 4:
            _notify("El PIN necesita al menos 4 caracteres")
            return
        pin2 = unlock_ui._ask("Repite el PIN de «%s»" % name)
        if pin2 != pin:
            _notify("Las dos entradas no coinciden")
            return
        new_id = v.add_slot(name, pin)
        if new_id:
            # Metadatos sellados por ID de ranura (sup5-M4), no por
            # nombre: los nombres duplicados ya no se pisan.
            meta = _meta_load(self.profile)
            meta[str(new_id)] = {"creado": _hoy()}
            _meta_save(self.profile, meta)
            dialogs.ok("PalAntriX",
                   "Acceso creado. Dale este PIN a %s: solo abre esta "
                   "tele y solo para ver." % name)

    def _acc_new_remote(self):
        import remote
        import unlock_ui
        v = self.vault
        name = dialogs.ask_text("Nombre del acceso (p. ej. Marta)")
        if not name:
            return
        aparato = dialogs.ask_text(
            "¿En qué dispositivo? (opcional, p. ej. Móvil de Marta)")
        pin = unlock_ui._ask(
            "PIN para «%s»: 6 cifras o más (este PIN viaja cifrado "
            "a su dispositivo)" % name)
        if not pin:
            return
        if len(pin) < 6 or not pin.isdigit():
            _notify("El PIN remoto necesita al menos 6 cifras")
            return
        pin2 = unlock_ui._ask("Repite el PIN de «%s»" % name)
        if pin2 != pin:
            _notify("Las dos entradas no coinciden")
            return
        ok, info = remote.create_remote_access(v, self.profile, name,
                                               pin, aparato or "")
        if not ok:
            dialogs.ok("PalAntriX", info)
            return
        code = remote.code_display(info["codigo"])
        extra = "" if info["publicado"] else (
            "\n\nOJO: la lista no se ha podido publicar ahora (sin "
            "conexión o servidor no disponible). El código vale igual "
            "en cuanto se publique en la próxima sincronización.")
        dialogs.ok("PalAntriX",
               "Acceso remoto creado para «%s».\n\n"
               "Pásale este código de activación (por WhatsApp vale):\n"
               "[B]%s[/B]\n\n"
               "Lo escribe una sola vez en su dispositivo, en "
               "Servicios → Bóveda → «Tengo un código de activación». "
               "Caduca en %d días. Después, en su aparato solo usará "
               "su PIN.%s" % (name, code, remote.ACT_DIAS, extra))

    def _do_accrem(self, action):
        import remote
        v = self.vault
        if v is None or not (v.unlocked and v.is_master):
            return
        rid = action.split(":", 1)[1] if ":" in action else ""
        slot = None
        for s in remote.registry_slots(self.profile):
            if s["rid"] == rid:
                slot = s
                break
        if slot is None:
            return
        sel = dialogs.select("Acceso remoto «%s»" % slot["name"],
                         ["Revocar este acceso",
                          "Nuevo código de activación",
                          "Cancelar"])
        if sel == 0:
            if dialogs.confirm(
                    "PalAntriX",
                    "¿Revocar el acceso remoto «%s»?\n"
                    "Su PIN dejará de funcionar en cada aparato cuando "
                    "sincronice al abrir la app (no es instantáneo si "
                    "el aparato está apagado o sin conexión)."
                    % slot["name"]):
                ok, msg = remote.revoke_remote(v, self.profile, rid)
                if not ok:
                    dialogs.ok("PalAntriX", msg)
                else:
                    _notify("Acceso remoto revocado")
        elif sel == 1:
            ok, info = remote.reissue_activation(v, self.profile, rid)
            if not ok:
                dialogs.ok("PalAntriX", info)
                return
            code = remote.code_display(info["codigo"])
            extra = "" if info["publicado"] else (
                "\n\nOJO: no se ha podido publicar ahora; valdrá en "
                "cuanto se publique en la próxima sincronización.")
            dialogs.ok("PalAntriX",
                   "Nuevo código de activación para «%s»:\n\n"
                   "[B]%s[/B]\n\n"
                   "Pásaselo y que lo escriba en su dispositivo, en "
                   "Servicios → Bóveda → «Tengo un código de "
                   "activación». Caduca en %d días.%s"
                   % (slot["name"], code, remote.ACT_DIAS, extra))

    def _do_acc_revoke(self, action):
        v = self.vault
        if v is None or not (v.unlocked and v.is_master):
            return
        try:
            slot_id = int(action.split(":", 1)[1])
        except Exception:
            return
        nombre = None
        for s in v.list_slots():
            if s["id"] == slot_id:
                nombre = s["name"]
        if nombre is None:
            return
        if dialogs.confirm(
                "PalAntriX",
                "¿Revocar el acceso «%s»?\nSu PIN dejará de funcionar en "
                "esta tele al instante." % nombre):
            v.remove_slot(slot_id)
            meta = _meta_load(self.profile)
            meta.pop(str(slot_id), None)
            _meta_save(self.profile, meta)
            _notify("Acceso revocado")

    # ----- genérico -----
    def _do_back(self, action):
        self.close()
