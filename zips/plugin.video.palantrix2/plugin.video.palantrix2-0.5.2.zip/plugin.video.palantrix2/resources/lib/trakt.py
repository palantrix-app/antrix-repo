# -*- coding: utf-8 -*-
"""Trakt — vinculación y sincronización bidireccional.

Usa la app de API de Trakt DEL PROYECTO (registrada a nombre de
PalAntriX, con su Client ID incrustado abajo, como hacían Palantir o
luc_kodi): vincular la cuenta es solo un código en la dirección de
activación que devuelve la API (auth.trakt.tv/activate), sin que el
usuario registre nada. La app del proyecto es PKCE: el portal nuevo
de Trakt ya no emite Client Secret, y el intercambio de código
funciona como cliente público, sin secreto. Quien prefiera su
propia app puede pegar sus claves en los ajustes del addon y tienen
prioridad sobre las incrustadas. Sin Client ID en ninguna de las
dos fuentes, todo el módulo es un no-op silencioso.

- Entrada: vistos + progreso + Mi lista (watchlist) → userdata.db
- Salida: al terminar de ver algo se marca en Trakt (/sync/history)
  y el progreso se envía con /scrobble.
"""
import threading
import time

import requests
import xbmc
import xbmcaddon
import xbmcgui

import dialogs

ADDON = xbmcaddon.Addon()
API = "https://api.trakt.tv"

# Claves de la app de API de Trakt del proyecto «PalAntriX»
# (developer.trakt.tv/apps; Redirect URI urn:ietf:wg:oauth:2.0:oob).
# Es la credencial pública de la app — pensada para viajar incrustada
# en el addon, como en todo addon de Kodi —, no la de ninguna cuenta
# de usuario. La app es PKCE: el portal no emite Client Secret
# («Not issued»), así que el secreto queda vacío y NUNCA se envía
# en los cuerpos OAuth (ver _oauth_body).
DEFAULT_CLIENT_ID = "U111zi5pwBPgqqwrHuDm2UCBz1t9axvL56L0Mas1vM4"
DEFAULT_CLIENT_SECRET = ""

# Dirección de activación por defecto si la API no la devolviera
# en /oauth/device/code (el dominio nuevo de Trakt).
DEFAULT_VERIFICATION_URL = "https://auth.trakt.tv/activate"

def _s(name):
    return (ADDON.getSetting(name) or "").strip()

def _client_id():
    """Client ID vigente: el del usuario si pegó el suyo; si no, el
    incrustado de la app del proyecto."""
    return _s("trakt_client_id") or DEFAULT_CLIENT_ID

def _client_secret():
    return _s("trakt_client_secret") or DEFAULT_CLIENT_SECRET

def configured():
    # Basta el Client ID: la app del proyecto es PKCE y no tiene
    # secreto; el secreto solo existe si el usuario pega el de una
    # app clásica propia.
    return bool(_client_id())

def _oauth_body(extra):
    """Cuerpo de una petición OAuth: el client_secret SOLO viaja si
    hay uno (app clásica del usuario). Con la app PKCE del proyecto
    no se envía la clave en absoluto — enviarla vacía haría que
    Trakt tratara el intercambio como el de un cliente confidencial
    y lo rechazara."""
    body = dict(extra)
    secret = _client_secret()
    if secret:
        body["client_secret"] = secret
    return body

def linked():
    return bool(_s("trakt_token"))

def _headers(auth=False):
    h = {"Content-Type": "application/json",
         "trakt-api-version": "2",
         "trakt-api-key": _client_id()}
    if auth and _s("trakt_token"):
        h["Authorization"] = "Bearer " + _s("trakt_token")
    return h

def _refresh():
    r = requests.post(API + "/oauth/token", json=_oauth_body({
        "refresh_token": _s("trakt_refresh"),
        "client_id": _client_id(),
        "redirect_uri": "urn:ietf:wg:oauth:2.0:oob",
        "grant_type": "refresh_token"}), timeout=20)
    if r.status_code == 200:
        d = r.json()
        ADDON.setSetting("trakt_token", d.get("access_token", ""))
        ADDON.setSetting("trakt_refresh", d.get("refresh_token", ""))
        return True
    return False

def _get(path, retry=True):
    r = requests.get(API + path, headers=_headers(auth=True), timeout=25)
    if r.status_code == 401 and retry and _refresh():
        return _get(path, retry=False)
    r.raise_for_status()
    return r.json()

def _get_paged(path, limit=100):
    """GET con TODAS las páginas (§6): Trakt corta cada lista larga
    en páginas y lo anuncia en la cabecera X-Pagination-Page-Count;
    pedir una sola página dejaba el historial en «100 películas,
    0 episodios». Cualquier error HTTP se PROPAGA a quien llama:
    nada de tragarlo en silencio."""
    out = []
    page = 1
    while True:
        sep = "&" if "?" in path else "?"
        url = "%s%slimit=%d&page=%d" % (path, sep, limit, page)
        r = requests.get(API + url, headers=_headers(auth=True), timeout=25)
        if r.status_code == 401 and _refresh():
            r = requests.get(API + url, headers=_headers(auth=True),
                             timeout=25)
        r.raise_for_status()
        data = r.json()
        if not isinstance(data, list):
            return out
        out.extend(data)
        try:
            total = int(r.headers.get("X-Pagination-Page-Count") or 1)
        except Exception:
            total = 1
        if page >= total or not data:
            return out
        page += 1

def _post(path, payload, retry=True):
    r = requests.post(API + path, headers=_headers(auth=True), json=payload, timeout=25)
    if r.status_code == 401 and retry and _refresh():
        return _post(path, payload, retry=False)
    return r

# ---------------- vinculación (device code) ----------------
def link_account():
    if not configured():
        dialogs.ok("Trakt",
            "No hay claves de Trakt disponibles en esta copia de la app. "
            "Si tienes tu propia app de Trakt, pega su Client ID en "
            "Servicios → Trakt (y su Client Secret, si tu app lo tiene).")
        return False
    r = requests.post(API + "/oauth/device/code",
                      json={"client_id": _client_id()}, timeout=20)
    if r.status_code != 200:
        dialogs.ok("Trakt", "Trakt no responde ahora mismo. Inténtalo en un rato.")
        return False
    d = r.json()
    code, user_code = d["device_code"], d["user_code"]
    host = (d.get("verification_url") or DEFAULT_VERIFICATION_URL)
    host = host.split("://", 1)[-1].rstrip("/")
    expires, interval = d.get("expires_in", 600), max(d.get("interval", 5), 5)
    dlg = dialogs.Busy()
    dlg.create("Vincular Trakt",
               "Entra en %s e introduce el código %s" % (host, user_code))
    waited = 0
    try:
        while waited < expires:
            if dlg.iscanceled():
                return False
            xbmc.sleep(interval * 1000)
            waited += interval
            dlg.update(int(waited * 100 / expires),
                       "Entra en %s e introduce el código %s" % (host, user_code))
            t = requests.post(API + "/oauth/device/token", json=_oauth_body({
                "code": code, "client_id": _client_id()}), timeout=20)
            if t.status_code == 200:
                tok = t.json()
                ADDON.setSetting("trakt_token", tok.get("access_token", ""))
                ADDON.setSetting("trakt_refresh", tok.get("refresh_token", ""))
                try:
                    me = _get("/users/me")
                    ADDON.setSetting("trakt_user", (me.get("username") or ""))
                except Exception:
                    pass
                dialogs.notify("Trakt · Cuenta vinculada")
                return True
            if t.status_code not in (400,):
                break
    finally:
        dlg.close()
    dialogs.ok("Trakt", "El código ha caducado. Vuelve a intentarlo.")
    return False

# ---------- vinculación por pasos (pantalla propia de Servicios) ----------
def start_link():
    """Pide un código de dispositivo. Devuelve {'device_code', 'user_code',
    'verification_url', 'expires_in', 'interval'} o None (sin
    credenciales o sin respuesta). La URL de activación es la que
    devuelve la API (auth.trakt.tv/activate); si no viniera, se usa
    la de por defecto."""
    if not configured():
        return None
    try:
        r = requests.post(API + "/oauth/device/code",
                          json={"client_id": _client_id()}, timeout=20)
    except Exception:
        return None
    if r.status_code != 200:
        return None
    d = r.json()
    return {"device_code": d["device_code"], "user_code": d["user_code"],
            "verification_url": d.get("verification_url") or DEFAULT_VERIFICATION_URL,
            "expires_in": d.get("expires_in", 600),
            "interval": max(d.get("interval", 5), 5)}


def poll_link(device_code):
    """Sondea el código: True = vinculado; None = aún pendiente;
    "denied" = el usuario denegó el acceso en trakt.tv (403);
    False = caducado o error (hay que pedir otro código).
    La causa se propaga para que el mensaje sea el verdadero
    (sup5-M3): una denegación no es una caducidad."""
    try:
        t = requests.post(API + "/oauth/device/token", json=_oauth_body({
            "code": device_code, "client_id": _client_id()}), timeout=20)
    except Exception:
        return None
    if t.status_code == 200:
        tok = t.json()
        ADDON.setSetting("trakt_token", tok.get("access_token", ""))
        ADDON.setSetting("trakt_refresh", tok.get("refresh_token", ""))
        try:
            me = _get("/users/me")
            ADDON.setSetting("trakt_user", (me.get("username") or ""))
        except Exception:
            pass
        return True
    if t.status_code == 400:
        return None  # authorization_pending
    if t.status_code == 403:
        return "denied"  # access_denied
    if t.status_code == 429:
        return None  # slow_down: se sigue esperando, sin prisa
    return False


def unlink():
    """Desvincula la cuenta. Lo ya sincronizado en local se queda."""
    for k in ("trakt_token", "trakt_refresh", "trakt_user", "trakt_last_sync"):
        ADDON.setSetting(k, "")


def last_sync():
    return _s("trakt_last_sync")


def mark_sync():
    import datetime
    ADDON.setSetting("trakt_last_sync",
                     datetime.datetime.now().strftime("%d/%m/%Y"))


# ---------------- sincronización de entrada ----------------
def sync_in(userdata):
    """Trae de Trakt vistos y watchlist y los fusiona en userdata.

    Paginación completa en las tres listas (§6) y errores a la
    vista: el resultado lleva "ok": True SOLO si las tres partes se
    ejecutaron sin error; cada parte que falla anota su nombre en
    "errors" y quien sella la fecha de sincronización NO debe
    sellarla (la sincronización no fue completa)."""
    if not linked():
        return {"movies": 0, "episodes": 0, "watchlist": 0, "ok": False,
                "errors": ["sin vincular"]}
    out = {"movies": 0, "episodes": 0, "watchlist": 0, "ok": False,
           "errors": []}
    try:
        pelis = _get_paged("/sync/watched/movies")
        for m in pelis:
            tmdb = ((m.get("movie") or {}).get("ids") or {}).get("tmdb")
            if tmdb:
                userdata.save_movie(int(tmdb), 0, finished=True)
                out["movies"] += 1
    except Exception as e:
        out["errors"].append("las películas")
        xbmc.log("PalAntriX trakt movies: %s" % e, xbmc.LOGWARNING)
    try:
        series = _get_paged("/sync/watched/shows")
        for s in series:
            tmdb = ((s.get("show") or {}).get("ids") or {}).get("tmdb")
            if not tmdb:
                continue
            for season in s.get("seasons") or []:
                for ep in season.get("episodes") or []:
                    userdata.save_episode(int(tmdb), int(season["number"]),
                                          int(ep["number"]), 0, finished=True)
                    out["episodes"] += 1
    except Exception as e:
        out["errors"].append("los episodios")
        xbmc.log("PalAntriX trakt shows: %s" % e, xbmc.LOGWARNING)
    try:
        lista = _get_paged("/users/me/watchlist")
        for w in lista:
            kind = "pelicula" if w.get("type") == "movie" else "serie"
            obj = w.get("movie") or w.get("show") or {}
            tmdb = (obj.get("ids") or {}).get("tmdb")
            if tmdb and not userdata.is_fav(kind, int(tmdb)):
                userdata.toggle_fav(kind, int(tmdb))
                out["watchlist"] += 1
    except Exception as e:
        out["errors"].append("tu lista")
        xbmc.log("PalAntriX trakt watchlist: %s" % e, xbmc.LOGWARNING)
    out["ok"] = not out["errors"]
    return out

# ---------------- salida (scrobble / historial) ----------------
def _push(payload, path="/sync/history"):
    def run():
        try:
            _post(path, payload)
        except Exception:
            pass
    threading.Thread(target=run, daemon=True).start()

def mark_watched(kind, tmdb, temporada=None, episodio=None):
    if not linked():
        return
    if kind == "pelicula":
        _push({"movies": [{"ids": {"tmdb": int(tmdb)}}]})
    elif temporada is not None and episodio is not None:
        _push({"shows": [{"ids": {"tmdb": int(tmdb)},
                          "seasons": [{"number": int(temporada),
                                       "episodes": [{"number": int(episodio)}]}]}]})

def _scrobble_body(kind, tmdb, temporada, episodio, pct):
    body = {"progress": float(pct)}
    if kind == "pelicula":
        body["movie"] = {"ids": {"tmdb": int(tmdb)}}
    else:
        body["show"] = {"ids": {"tmdb": int(tmdb)}}
        body["episode"] = {"season": int(temporada or 1), "number": int(episodio or 1)}
    return body

def scrobble_start(kind, tmdb, temporada, episodio, pct=0.0):
    """Scrobble de inicio (Fase 4). Sin vincular, no-op silencioso."""
    if not linked():
        return
    _push(_scrobble_body(kind, tmdb, temporada, episodio, pct),
          path="/scrobble/start")

def scrobble_progress(kind, tmdb, temporada, episodio, pct):
    if not linked():
        return
    _push(_scrobble_body(kind, tmdb, temporada, episodio, pct),
          path="/scrobble/pause")

def scrobble_stop(kind, tmdb, temporada, episodio, pct):
    """Scrobble de fin (Fase 4): con progreso >= 80 %, Trakt lo cuenta
    como visto. Sin vincular, no-op silencioso."""
    if not linked():
        return
    _push(_scrobble_body(kind, tmdb, temporada, episodio, pct),
          path="/scrobble/stop")
