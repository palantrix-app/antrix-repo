# -*- coding: utf-8 -*-
"""Ventanas de la cadena de reproducción (Fase 4).

- LoadingWindow (1311): la pantalla de carga de la casa — fanart del
  título y UN solo texto de fase («Preparando…», «Resolviendo enlace…»,
  «Buscando en vivo…», «Sin enlaces disponibles»). La cadena corre en un
  hilo y esta ventana es su interfaz: cambio de fase, desbloqueo de la
  bóveda DENTRO del flujo y selector por excepción.
- SelectorWindow (1312): selector por excepción, filas agrupadas por
  origen (Palantir / En vivo) con encabezados NO enfocables, como los
  menús de la casa. Atrás sale sin elegir.
- NextEpWindow (1313): diálogo propio de siguiente episodio, con el
  botón de reproducir enfocado y SIN cuenta atrás que reproduzca sola
  (decisión del debate).
"""
import threading

import xbmc
import xbmcgui

from db import img

ATRAS = (9, 10, 92)          # back / previous menu / nav back
MOVE_UP, MOVE_DOWN = 3, 4    # acciones de flecha en listas


# ---------------------------------------------------------------------------
# Carga de la casa
# ---------------------------------------------------------------------------
class LoadingWindow(xbmcgui.WindowXML):
    IMG_FANART = 9000
    LBL_TITULO = 920
    LBL_FASE = 9100
    BTN_CANCELAR = 940

    def __init__(self, *args, **kwargs):
        super(LoadingWindow, self).__init__(*args)
        self.playback = kwargs.get("playback")
        self.job = kwargs.get("job") or {}
        self.outcome = None            # ("play", url) / ("abort",) / ("fail", txt) / ("error", txt)
        self.user_canceled = False
        self._cancel = threading.Event()
        self._started = False

    # ---------- interfaz que usa la cadena (hilo de trabajo) ----------
    def set_phase(self, text):
        try:
            self.getControl(self.LBL_FASE).setLabel(text)
        except Exception:
            pass

    def is_canceled(self):
        return self._cancel.is_set()

    def ask_unlock(self):
        """El teclado de desbloqueo aparece como parte del flujo de
        carga: la ventana de carga queda detrás y, si el usuario
        cancela, la cadena aborta y se vuelve al origen."""
        import unlock_ui
        return unlock_ui.prompt_unlock(self.playback.vault,
                                       profile=self.playback.profile)

    def ask_selector(self, rows, titulo, subtitulo):
        w = SelectorWindow("selector.xml", self.playback.addon_path,
                           "Default", "1080i",
                           rows=rows, titulo=titulo, subtitulo=subtitulo,
                           fondo=(self.job.get("row") or {}).get("fondo"))
        w.doModal()
        choice = w.choice
        del w
        return choice

    # ---------- ventana ----------
    def onInit(self):
        if self._started:
            return
        self._started = True
        row = self.job.get("row") or {}
        try:
            self.getControl(self.IMG_FANART).setImage(
                img(row.get("fondo"), "w1280"), False)
            self.getControl(self.LBL_TITULO).setLabel(
                self.job.get("titulo_display") or row.get("titulo") or "")
        except Exception:
            pass
        self.set_phase("Preparando…")
        try:
            self.setFocusId(self.BTN_CANCELAR)
        except Exception:
            pass
        t = threading.Thread(target=self._run)
        t.daemon = True
        t.start()

    def _run(self):
        outcome = ("abort",)
        try:
            outcome = self.playback._run_chain(self.job, self)
        except Exception as e:
            # Solo el TIPO (sup2-B2): el texto de una excepción de
            # transporte podría llevar una URL con secretos.
            xbmc.log("PalAntriX cadena: error inesperado (%s)"
                     % type(e).__name__, xbmc.LOGERROR)
            outcome = ("error", "Ha fallado la reproducción")
        self.outcome = outcome
        if outcome and outcome[0] == "fail":
            # El mensaje honesto se lee en la propia carga antes de salir.
            self.set_phase(outcome[1] or "Sin enlaces disponibles")
            mon = xbmc.Monitor()
            for _ in range(25):
                if self._cancel.is_set() or mon.waitForAbort(0.1):
                    break
        try:
            self.close()
        except Exception:
            pass

    def _cancelar(self):
        self.user_canceled = True
        self._cancel.set()
        try:
            self.close()
        except Exception:
            pass

    def onAction(self, action):
        aid = action.getId() if hasattr(action, "getId") else 0
        if aid in ATRAS:
            self._cancelar()
            return
        super(LoadingWindow, self).onAction(action)

    def onClick(self, control_id):
        if control_id == self.BTN_CANCELAR:
            self._cancelar()


# ---------------------------------------------------------------------------
# Selector por excepción (agrupado por origen)
# ---------------------------------------------------------------------------
class SelectorWindow(xbmcgui.WindowXML):
    LIST_ID = 300
    LBL_TITULO = 920
    LBL_SUB = 930
    IMG_FANART = 9000

    def __init__(self, *args, **kwargs):
        super(SelectorWindow, self).__init__(*args)
        self.rows = kwargs.get("rows") or []   # [{dest: header|row, titulo, nota, payload}]
        self.titulo = kwargs.get("titulo") or ""
        self.subtitulo = kwargs.get("subtitulo") or ""
        self.fondo = kwargs.get("fondo")
        self.choice = None
        self._pos = 0

    def _first_actionable(self):
        for i, r in enumerate(self.rows):
            if r.get("dest") != "header":
                return i
        return 0

    def onInit(self):
        try:
            if self.fondo:
                self.getControl(self.IMG_FANART).setImage(
                    img(self.fondo, "w1280"), False)
            self.getControl(self.LBL_TITULO).setLabel(self.titulo)
            self.getControl(self.LBL_SUB).setLabel(self.subtitulo)
        except Exception:
            pass
        lst = self.getControl(self.LIST_ID)
        lst.reset()
        items = []
        for r in self.rows:
            li = xbmcgui.ListItem(label=r.get("titulo") or "")
            if r.get("dest") == "header":
                li.setProperty("header", "1")
            else:
                li.setLabel2(r.get("nota") or "")
            items.append(li)
        lst.addItems(items)
        self._pos = self._first_actionable()
        if self.rows:
            lst.selectItem(self._pos)
        try:
            self.setFocusId(self.LIST_ID)
        except Exception:
            pass

    def onAction(self, action):
        aid = action.getId() if hasattr(action, "getId") else 0
        if aid in ATRAS:
            self.choice = None
            self.close()
            return
        super(SelectorWindow, self).onAction(action)
        # Encabezados no enfocables y sin wrap: mismo corrector que los
        # menús de la casa (menus.corregir_posicion).
        try:
            from menus import corregir_posicion
            lst = self.getControl(self.LIST_ID)
            pos = lst.getSelectedPosition()
            if 0 <= pos < len(self.rows):
                buena = corregir_posicion(self.rows, pos, self._pos, aid)
                if buena != pos:
                    lst.selectItem(buena)
                    pos = buena
                self._pos = pos
        except Exception:
            pass

    def onClick(self, control_id):
        if control_id != self.LIST_ID:
            return
        lst = self.getControl(self.LIST_ID)
        pos = lst.getSelectedPosition()
        if 0 <= pos < len(self.rows):
            r = self.rows[pos]
            if r.get("dest") == "header":
                return
            self.choice = r.get("payload")
            self.close()


# ---------------------------------------------------------------------------
# Siguiente episodio
# ---------------------------------------------------------------------------
class NextEpWindow(xbmcgui.WindowXML):
    IMG_FANART = 9000
    LBL_ETIQUETA = 920
    LBL_TITULO = 930
    LBL_NOTA = 935
    BTN_PLAY = 940
    BTN_NO = 941

    def __init__(self, *args, **kwargs):
        super(NextEpWindow, self).__init__(*args)
        self.etiqueta = kwargs.get("etiqueta") or ""
        self.titulo = kwargs.get("titulo") or ""
        self.nota = kwargs.get("nota") or ""
        self.fondo = kwargs.get("fondo")
        self.result = False

    def onInit(self):
        try:
            if self.fondo:
                self.getControl(self.IMG_FANART).setImage(
                    img(self.fondo, "w1280"), False)
            self.getControl(self.LBL_ETIQUETA).setLabel(self.etiqueta)
            self.getControl(self.LBL_TITULO).setLabel(self.titulo)
            self.getControl(self.LBL_NOTA).setLabel(self.nota)
            self.setFocusId(self.BTN_PLAY)
        except Exception:
            pass

    def onAction(self, action):
        aid = action.getId() if hasattr(action, "getId") else 0
        if aid in ATRAS:
            self.close()
            return
        super(NextEpWindow, self).onAction(action)

    def onClick(self, control_id):
        if control_id == self.BTN_PLAY:
            self.result = True
            self.close()
        elif control_id == self.BTN_NO:
            self.close()
