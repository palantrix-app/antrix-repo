# -*- coding: utf-8 -*-
"""Gestión remota de accesos (0.4.0, modelo aprobado por Àngel).

Dos clases de aparatos:
- Administradores: tienen wrap maestra; con la sesión de maestra abierta
  crean/revocan accesos (locales, como siempre, o REMOTOS).
- Invitados: se dan de alta con un código de activación de un solo uso;
  al activarse muere también su wrap de instalación y el aparato queda
  en modo invitado (sin administración local: solo su PIN para ver).

La lista de accesos compartida viaja como un sobre cifrado (AES-256-GCM)
y firmado (HMAC-SHA256) con claves derivadas de la DEK en memoria
(vault.derive_key): solo un aparato que puede abrir la bóveda puede
leerla o producirla; una lista manipulada se rechaza por firma y se
conserva la última buena. En la lista SOLO viajan wraps de ranura (la
DEK envuelta con el PIN de cada familiar, el mismo formato de
vault.add_slot): los PIN nunca aparecen ni se derivan.

La sincronización se aplica cuando la bóveda se desbloquea (es cuando
existe la DEK para verificar la firma) y NUNCA bloquea la apertura:
sin red o con lista inválida se sigue con el estado local.

Puerta de publicación: POST a {base}/api/accesos y {base}/api/
activaciones con la cabecera X-Upload-Token. El token solo protege
contra basura (la integridad la da la firma); su valor vive en
UPLOAD_TOKEN y debe coincidir con el secreto del servidor (Worker /
Pages Function + KV). La base se puede cambiar con el ajuste oculto
`remote_base_url` (banco de pruebas).
"""
import base64
import hashlib
import hmac
import json
import os
import time
import uuid

import xbmc
import xbmcaddon

# pycryptodome NO se importa en cabecera (corrección 0.4.0-C1, como en
# vault.py): se resuelve de forma perezosa con vault._crypto() dentro
# de cada función que lo usa — todos los usos de este módulo son
# posteriores al desbloqueo (sellado/apertura del sobre de accesos y
# del blob de activación), así que si el módulo de cifrado no carga en
# el aparato, la app abre igual y solo falla esa operación.
from vault import _crypto

ADDON = xbmcaddon.Addon()

DEFAULT_BASE = "https://antrix.pages.dev"
LIST_PATH = "/api/accesos"
ACT_PATH = "/api/activaciones"
# Token de subida (solo anti-basura; la integridad es la firma con la
# DEK). Debe coincidir con el secreto configurado en el servidor.
UPLOAD_TOKEN = "px2-upl-7f3a9c51d2e84b06a1f5c39d72e8b460"

REG_FILE = "accesos_remotos.json"      # registro del administrador
STATE_FILE = "remoto_state.json"       # estado de invitado / mapa
LIST_CACHE = "remoto_lista_cache.json"  # último sobre descargado
ACT_CACHE = "remoto_act_cache.json"    # últimas activaciones descargadas

ACT_DIAS = 7                            # caducidad del código de activación
_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"  # sin caracteres ambiguos
_SCRYPT = dict(N=32768, r=8, p=1)


def _log(msg):
    xbmc.log("PalAntriX remoto: %s" % msg, xbmc.LOGINFO)


def base_url():
    try:
        v = (ADDON.getSetting("remote_base_url") or "").strip()
    except Exception:
        v = ""
    return (v or DEFAULT_BASE).rstrip("/")


# ---------------------------------------------------------------------------
# Ficheros del perfil
# ---------------------------------------------------------------------------
def _load_json(profile, name, default):
    try:
        with open(os.path.join(profile, name)) as f:
            return json.load(f)
    except Exception:
        return default


def _save_json(profile, name, data):
    try:
        with open(os.path.join(profile, name), "w") as f:
            json.dump(data, f)
        return True
    except Exception:
        return False


def load_registry(profile):
    reg = _load_json(profile, REG_FILE,
                     {"version": 0, "slots": [], "pendientes": [],
                      "retirados": []})
    reg.setdefault("version", 0)
    reg.setdefault("slots", [])
    reg.setdefault("pendientes", [])
    reg.setdefault("retirados", [])
    return reg


def load_state(profile):
    st = _load_json(profile, STATE_FILE,
                    {"invitado": False, "own_rid": None, "nombre": "",
                     "mapa": {}, "revocado_aviso": False,
                     "lista_version": 0})
    st.setdefault("mapa", {})
    return st


def is_guest(profile):
    return bool(load_state(profile).get("invitado"))


def take_revocado_aviso(profile):
    """Lee y limpia la marca «tu acceso fue revocado» del estado."""
    st = load_state(profile)
    if st.get("revocado_aviso"):
        st["revocado_aviso"] = False
        _save_json(profile, STATE_FILE, st)
        return True
    return False


# ---------------------------------------------------------------------------
# Sobre de la lista: cifrado + firma derivados de la DEK
# ---------------------------------------------------------------------------
def _b64(b):
    return base64.b64encode(b).decode("ascii")


def _ub64(s):
    return base64.b64decode(s.encode("ascii"))


def _wrap_out(w):
    return {"salt": _b64(w["salt"]), "n": int(w["n"]), "r": int(w["r"]),
            "p": int(w["p"]), "nonce": _b64(w["nonce"]),
            "wrapped": _b64(w["wrapped"])}


def _wrap_in(d):
    return {"salt": _ub64(d["salt"]), "n": int(d["n"]), "r": int(d["r"]),
            "p": int(d["p"]), "nonce": _ub64(d["nonce"]),
            "wrapped": _ub64(d["wrapped"])}


def seal_list(vault, plain):
    """(sobre dict) o None si la bóveda está bloqueada."""
    enc = vault.derive_key("palantrix2/accesos/enc")
    mac = vault.derive_key("palantrix2/accesos/mac")
    if enc is None or mac is None:
        return None
    data = json.dumps(plain, separators=(",", ":")).encode("utf-8")
    nonce = _crypto()["grb"](12)
    c = _crypto()["AES"].new(enc, _crypto()["AES"].MODE_GCM, nonce=nonce)
    ct, tag = c.encrypt_and_digest(data)
    body = nonce + ct + tag
    sig = hmac.new(mac, body, hashlib.sha256).hexdigest()
    return {"v": 1, "body": _b64(body), "sig": sig}


def open_list(vault, sobre):
    """(dict de la lista) o None: firma inválida, formato roto o
    bóveda bloqueada. Una lista ajena (otra DEK) también da None:
    su HMAC no puede casar."""
    enc = vault.derive_key("palantrix2/accesos/enc")
    mac = vault.derive_key("palantrix2/accesos/mac")
    if enc is None or mac is None or not isinstance(sobre, dict):
        return None
    try:
        body = _ub64(sobre["body"])
        sig = hmac.new(mac, body, hashlib.sha256).hexdigest()
        if not hmac.compare_digest(sig, str(sobre.get("sig") or "")):
            return None
        nonce, rest = body[:12], body[12:]
        c = _crypto()["AES"].new(enc, _crypto()["AES"].MODE_GCM,
                                 nonce=nonce)
        data = c.decrypt_and_verify(rest[:-16], rest[-16:])
        plain = json.loads(data.decode("utf-8"))
        if not isinstance(plain, dict) or "slots" not in plain:
            return None
        return plain
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Red (descargas silenciosas; la subida exige el token)
# ---------------------------------------------------------------------------
def _fetch(path, timeout=8):
    import requests
    r = requests.get(base_url() + path, timeout=timeout,
                     headers={"User-Agent": "PalAntriX/0.4"})
    if r.status_code != 200:
        return None
    return r.json()


def _post(path, payload):
    import requests
    r = requests.post(base_url() + path, json=payload, timeout=15,
                      headers={"User-Agent": "PalAntriX/0.4",
                               "X-Upload-Token": UPLOAD_TOKEN})
    return r.status_code in (200, 201, 204)


def prefetch(profile):
    """Descarga el sobre de la lista y las activaciones a la caché del
    perfil (sin descifrar nada: para eso hace falta la DEK). Pensado
    para un hilo en segundo plano al abrir la app: jamás lanza."""
    try:
        data = _fetch(LIST_PATH, timeout=10)
        if isinstance(data, dict) and data.get("body"):
            _save_json(profile, LIST_CACHE, data)
    except Exception:
        pass
    try:
        data = _fetch(ACT_PATH, timeout=10)
        if isinstance(data, dict) and "pending" in data:
            _save_json(profile, ACT_CACHE, data)
    except Exception:
        pass


def _fetch_list_sobre(profile):
    """Sobre de la lista: red primero; si falla, la caché de esta
    sesión (la que dejó el prefetch al abrir) si es reciente."""
    try:
        data = _fetch(LIST_PATH)
        if isinstance(data, dict) and data.get("body"):
            _save_json(profile, LIST_CACHE, data)
            return data
    except Exception:
        pass
    path = os.path.join(profile, LIST_CACHE)
    try:
        if time.time() - os.path.getmtime(path) < 3600:
            return _load_json(profile, LIST_CACHE, None)
    except Exception:
        pass
    return None


# ---------------------------------------------------------------------------
# Publicación (solo administrador, con la DEK en memoria)
# ---------------------------------------------------------------------------
def _merged_slots(vault, profile, reg):
    """Slots a publicar: los de la lista vigente (verificada) menos los
    retirados localmente, unidos con los del registro (que mandan)."""
    retirados = set(reg.get("retirados") or [])
    merged = {}
    sobre = None
    try:
        sobre = _fetch(LIST_PATH)
    except Exception:
        sobre = None
    lista = open_list(vault, sobre) if sobre else None
    base_version = 0
    if lista:
        base_version = int(lista.get("version") or 0)
        for s in lista.get("slots") or []:
            if s.get("rid") and s["rid"] not in retirados:
                merged[s["rid"]] = s
    for s in reg.get("slots") or []:
        if s.get("rid") in retirados:
            continue
        merged[s["rid"]] = s
    version = max(base_version, int(reg.get("version") or 0)) + 1
    return list(merged.values()), version


def _publish_activations(profile, reg, extra=None, drop_rids=()):
    """Republica el fichero de activaciones: conserva las vigentes no
    retiradas y añade/sustituye `extra` ({act_id, rid, exp, blob})."""
    ahora = time.time()
    keep = {}
    try:
        data = _fetch(ACT_PATH)
    except Exception:
        data = None
    if isinstance(data, dict):
        for e in data.get("pending") or []:
            try:
                if float(e.get("exp") or 0) > ahora \
                        and e.get("rid") not in drop_rids:
                    keep[e["act_id"]] = e
            except Exception:
                continue
    # Las pendientes del registro que ya no constan (p. ej. generadas
    # sin conexión) se conservan si su blob se guardó en el registro.
    for p in reg.get("pendientes") or []:
        if p.get("blob") and float(p.get("exp") or 0) > ahora \
                and p.get("rid") not in drop_rids:
            keep[p["act_id"]] = {"act_id": p["act_id"], "rid": p["rid"],
                                 "exp": p["exp"], "blob": p["blob"]}
    if extra:
        keep[extra["act_id"]] = extra
    payload = {"v": 1, "pending": list(keep.values())}
    ok = False
    try:
        ok = _post(ACT_PATH, payload)
    except Exception:
        ok = False
    if ok:
        _save_json(profile, ACT_CACHE, payload)
    return ok


def publish(vault, profile):
    """Publica la lista (y depura las activaciones) desde el registro
    del administrador. (ok, mensaje)."""
    if vault is None or not vault.unlocked or not vault.is_master:
        return False, "Necesitas tu contraseña maestra."
    reg = load_registry(profile)
    slots, version = _merged_slots(vault, profile, reg)
    plain = {"v": 1, "version": version, "updated": int(time.time()),
             "slots": slots}
    sobre = seal_list(vault, plain)
    if sobre is None:
        return False, "La bóveda está bloqueada."
    try:
        ok = _post(LIST_PATH, sobre)
    except Exception:
        ok = False
    if not ok:
        return False, ("No se ha podido publicar la lista de accesos "
                       "(sin conexión o servidor no disponible). Queda "
                       "guardada en este dispositivo y se publicará en "
                       "la próxima sincronización.")
    reg["slots"] = slots
    reg["version"] = version
    reg["retirados"] = [r for r in (reg.get("retirados") or [])
                        if r not in {s["rid"] for s in slots}]
    _save_json(profile, REG_FILE, reg)
    _save_json(profile, LIST_CACHE, sobre)
    # Las activaciones de accesos que ya no viven (revocados) se
    # retiran de la puerta: su código deja de valer al momento.
    vivos = {s["rid"] for s in slots}
    caidos = {p.get("rid") for p in (reg.get("pendientes") or [])}
    reg["pendientes"] = [p for p in (reg.get("pendientes") or [])
                         if p.get("rid") in vivos]
    _save_json(profile, REG_FILE, reg)
    _publish_activations(profile, reg,
                         drop_rids=(caidos - vivos)
                         | set(reg.get("retirados") or []))
    _log("lista publicada: v%d, %d accesos" % (version, len(slots)))
    return True, "Lista de accesos publicada."


# ---------------------------------------------------------------------------
# Altas remotas y códigos de activación
# ---------------------------------------------------------------------------
def _new_code():
    raw = "".join(_ALPHABET[b % len(_ALPHABET)]
                  for b in _crypto()["grb"](20))
    return raw


def code_display(raw):
    return "-".join(raw[i:i + 5] for i in range(0, len(raw), 5))


def code_norm(code):
    return (code or "").replace("-", "").replace(" ", "").strip().upper()


def _act_blob(code_raw, payload):
    salt = _crypto()["grb"](16)
    kek = _crypto()["scrypt"](code_raw.encode("utf-8"), salt, 32, **_SCRYPT)
    nonce = _crypto()["grb"](12)
    c = _crypto()["AES"].new(kek, _crypto()["AES"].MODE_GCM, nonce=nonce)
    ct, tag = c.encrypt_and_digest(
        json.dumps(payload, separators=(",", ":")).encode("utf-8"))
    return _b64(salt + nonce + ct + tag)


def _act_open(code_raw, blob_b64):
    try:
        blob = _ub64(blob_b64)
        salt, nonce, rest = blob[:16], blob[16:28], blob[28:]
        kek = _crypto()["scrypt"](code_raw.encode("utf-8"), salt, 32,
                                  **_SCRYPT)
        c = _crypto()["AES"].new(kek, _crypto()["AES"].MODE_GCM,
                                 nonce=nonce)
        data = c.decrypt_and_verify(rest[:-16], rest[-16:])
        return json.loads(data.decode("utf-8"))
    except Exception:
        return None


def _issue_activation(vault, profile, reg, slot):
    """Genera un código de activación nuevo para `slot` y lo publica.
    Devuelve (código_en_claro, publicado_bool)."""
    raw = _new_code()
    act_id = raw[:6]
    exp = int(time.time()) + ACT_DIAS * 86400
    blob = _act_blob(raw, {"rid": slot["rid"], "name": slot["name"],
                           "wrap": slot["wrap"]})
    entry = {"act_id": act_id, "rid": slot["rid"], "exp": exp,
             "blob": blob}
    # La pendiente queda en el registro (con su blob) para poder
    # republicarla aunque la primera subida falle.
    reg["pendientes"] = [p for p in (reg.get("pendientes") or [])
                         if p.get("rid") != slot["rid"]]
    reg["pendientes"].append(entry)
    _save_json(profile, REG_FILE, reg)
    ok = _publish_activations(profile, reg, extra=entry)
    return raw, ok


def create_remote_access(vault, profile, name, pin, aparato=""):
    """Crea un acceso remoto: la wrap viaja en la lista; NO se instala
    en este dispositivo. Devuelve (ok, info) con info = {"rid",
    "codigo", "publicado"} o mensaje de error."""
    if vault is None or not vault.unlocked or not vault.is_master:
        return False, "Necesitas tu contraseña maestra."
    w = vault.make_wrap(pin)
    if not w:
        return False, "La bóveda está bloqueada."
    reg = load_registry(profile)
    import datetime
    slot = {"rid": uuid.uuid4().hex, "name": name,
            "wrap": _wrap_out(w),
            "creado": datetime.datetime.now().strftime("%d/%m/%Y"),
            "aparato": aparato or ""}
    reg["slots"].append(slot)
    _save_json(profile, REG_FILE, reg)
    ok_pub, _msg = publish(vault, profile)
    reg = load_registry(profile)
    raw, ok_act = _issue_activation(vault, profile, reg, slot)
    return True, {"rid": slot["rid"], "codigo": raw,
                  "publicado": bool(ok_pub and ok_act)}


def reissue_activation(vault, profile, rid):
    """Nuevo código de activación para un acceso remoto existente."""
    reg = load_registry(profile)
    for s in reg.get("slots") or []:
        if s.get("rid") == rid:
            raw, ok = _issue_activation(vault, profile, reg, s)
            return True, {"codigo": raw, "publicado": ok}
    return False, "Ese acceso ya no existe."


def revoke_remote(vault, profile, rid):
    """Revoca un acceso remoto: sale del registro, queda retirado y se
    publica. Surte efecto en cada aparato cuando sincronice."""
    reg = load_registry(profile)
    reg["slots"] = [s for s in (reg.get("slots") or [])
                    if s.get("rid") != rid]
    reg["pendientes"] = [p for p in (reg.get("pendientes") or [])
                         if p.get("rid") != rid]
    ret = reg.get("retirados") or []
    if rid not in ret:
        ret.append(rid)
    reg["retirados"] = ret
    _save_json(profile, REG_FILE, reg)
    return publish(vault, profile)


def registry_slots(profile):
    """Accesos remotos del registro con su estado de activación."""
    reg = load_registry(profile)
    ahora = time.time()
    pend = {}
    for p in reg.get("pendientes") or []:
        if float(p.get("exp") or 0) > ahora:
            pend[p["rid"]] = p
    out = []
    for s in reg.get("slots") or []:
        d = dict(s)
        d["pendiente"] = s["rid"] in pend
        out.append(d)
    return out


# ---------------------------------------------------------------------------
# Alta de invitado
# ---------------------------------------------------------------------------
def activate_guest(vault, profile, code):
    """Instala en ESTE aparato el acceso del código de activación.
    (ok, mensaje). Sin código válido no cambia nada."""
    if vault is None:
        return False, "La bóveda no está disponible."
    if vault.has_master():
        return False, ("Este dispositivo ya tiene contraseña maestra: "
                       "es un administrador, no necesita activación.")
    raw = code_norm(code)
    if len(raw) < 10:
        return False, "Ese código no parece válido."
    act_id = raw[:6]
    data = None
    try:
        data = _fetch(ACT_PATH)
    except Exception:
        data = None
    if not (isinstance(data, dict) and "pending" in data):
        data = _load_json(profile, ACT_CACHE, None)
    if not (isinstance(data, dict) and "pending" in data):
        return False, ("No se ha podido comprobar el código "
                       "(sin conexión). Inténtalo de nuevo.")
    entry = None
    for e in data.get("pending") or []:
        if e.get("act_id") == act_id:
            entry = e
            break
    if entry is None:
        return False, "Ese código no existe o ya se retiró."
    if float(entry.get("exp") or 0) <= time.time():
        return False, "Ese código ha caducado. Pide uno nuevo."
    payload = _act_open(raw, entry.get("blob") or "")
    if payload is None:
        return False, "Ese código no es correcto."
    try:
        w = _wrap_in(payload["wrap"])
    except Exception:
        return False, "El código es válido pero el acceso está dañado."
    local_id = vault.install_guest_wrap(payload["name"], w["salt"],
                                        w["n"], w["r"], w["p"],
                                        w["nonce"], w["wrapped"])
    if not local_id:
        return False, "No se ha podido instalar el acceso."
    st = load_state(profile)
    st["invitado"] = True
    st["own_rid"] = payload["rid"]
    st["nombre"] = payload["name"]
    st["mapa"] = {payload["rid"]: local_id}
    st["revocado_aviso"] = False
    _save_json(profile, STATE_FILE, st)
    _log("aparato activado como invitado: %s" % payload["name"])
    return True, ("Dispositivo activado. Escribe ahora el PIN de "
                  "«%s» para confirmar." % payload["name"])


# ---------------------------------------------------------------------------
# Sincronización (con la DEK en memoria; nunca bloquea)
# ---------------------------------------------------------------------------
def apply_sync(vault, profile):
    """Aplica la lista compartida sobre este aparato.
    Devuelve (estado, cambios): estado en
    "ok" | "offline" | "invalid" | "own_revoked" | "skip".
    - Invitado: sus wraps remotas quedan ESPEJO de la lista (altas
      entran, revocadas salen; maestra/bootstrap jamás se tocan).
    - Administrador: adopta en su registro lo publicado por sus otros
      aparatos y conserva lo local aún no publicado."""
    if vault is None or not vault.unlocked:
        return "skip", 0
    sobre = _fetch_list_sobre(profile)
    if sobre is None:
        return "offline", 0
    lista = open_list(vault, sobre)
    if lista is None:
        _log("lista recibida con firma inválida: se ignora")
        return "invalid", 0
    slots = {}
    for s in lista.get("slots") or []:
        if s.get("rid"):
            slots[s["rid"]] = s
    version = int(lista.get("version") or 0)
    st = load_state(profile)
    cambios = 0
    if st.get("invitado"):
        mapa = dict(st.get("mapa") or {})
        # Bajas: lo que ya no está en la lista sale del aparato.
        for rid, local_id in list(mapa.items()):
            if rid not in slots:
                vault.sync_delete_slot(local_id)
                del mapa[rid]
                cambios += 1
        # Altas y cambios: la wrap de la lista manda.
        for rid, s in slots.items():
            try:
                w = _wrap_in(s["wrap"])
            except Exception:
                continue
            local_id = mapa.get(rid)
            cur = vault.slot_wrap(local_id) if local_id else None
            if cur is None:
                mapa[rid] = vault.insert_slot_wrap(
                    s["name"], w["salt"], w["n"], w["r"], w["p"],
                    w["nonce"], w["wrapped"])
                cambios += 1
            elif (cur["salt"] != w["salt"] or cur["nonce"] != w["nonce"]
                    or cur["wrapped"] != w["wrapped"]):
                vault.sync_delete_slot(local_id)
                mapa[rid] = vault.insert_slot_wrap(
                    s["name"], w["salt"], w["n"], w["r"], w["p"],
                    w["nonce"], w["wrapped"])
                cambios += 1
        own_revoked = bool(st.get("own_rid")) \
            and st["own_rid"] not in slots
        if own_revoked:
            st["revocado_aviso"] = True
        st["mapa"] = mapa
        st["lista_version"] = version
        _save_json(profile, STATE_FILE, st)
        if cambios:
            _log("sincronización de invitado: %d cambios (lista v%d)"
                 % (cambios, version))
        return ("own_revoked" if own_revoked else "ok"), cambios
    if vault.is_master:
        reg = load_registry(profile)
        retirados = set(reg.get("retirados") or [])
        conocidos = {s["rid"] for s in reg.get("slots") or []}
        for rid, s in slots.items():
            if rid not in conocidos and rid not in retirados:
                reg["slots"].append(s)
                cambios += 1
        if version > int(reg.get("version") or 0):
            reg["version"] = version
        _save_json(profile, REG_FILE, reg)
        return "ok", cambios
    return "ok", 0


def post_unlock_sync(vault, profile):
    """Tras un desbloqueo correcto: sincroniza en silencio. Si el
    acceso propio de un invitado fue revocado, bloquea la sesión y
    devuelve "own_revoked" para que la UI avise con honestidad."""
    try:
        estado, _c = apply_sync(vault, profile)
    except Exception as e:
        _log("sincronización fallida sin bloquear: %s" % e)
        return "ok"
    if estado == "own_revoked":
        vault.lock()
        return "own_revoked"
    return estado
