# -*- coding: utf-8 -*-
"""Capa 2 — búsqueda en vivo cuando el enlace original está caído.

Fuente de texto (sin claves): apibay (TPB). Zilean se retiró en la
corrección post-revisión: su endpoint devuelve 404 permanente y solo
añadía su timeout a cada búsqueda (sup4-H6).
Filtro: castellano primero; el latino SOLO queda excluido (regla de Àngel;
los duales castellano+latino se conservan). Entrega: magnet → AllDebrid
(caché instantánea si está) → archivo de vídeo mayor → enlace desbloqueado.
"""
import re
import time

import requests
import xbmc
import xbmcaddon
import xbmcgui

from alldebrid import AllDebrid, AllDebridError
import dialogs

ADDON = xbmcaddon.Addon()
UA = {"User-Agent": "PalAntriX/0.1"}
VIDEO_EXT = (".mkv", ".mp4", ".avi", ".m2ts", ".ts", ".mov", ".wmv")

def _quality_rank(name):
    """Escalones espejo de player._tier (sup4-H8): DV > HDR10+ > HDR >
    4K > 1080p > HD > SD. «DV» se exige como TOKEN: dentro de «DVDRip»
    no cuenta (un DVDRip es un SD, no un Dolby Vision)."""
    n = (name or "").upper()
    if re.search(r"(?<![A-Z])DV(?![A-Z])", n) or "DOLBY" in n:
        return 0
    if "HDR10+" in n or "HDR10 PLUS" in n:
        return 1
    if "HDR" in n:
        return 2
    if "2160" in n or "4K" in n or "UHD" in n:
        return 3
    if "1080" in n:
        return 4
    if "720" in n or " HD" in n or n.strip().endswith("HD"):
        return 5
    return 6

def _is_latino_only(name):
    n = (name or "").lower()
    toks = set(t for t in re.split(r"[^a-záéíóúñ]+", n) if t)
    # «lat» como token caza también «[LAT]» y «.LAT.» (sup4-H9).
    if "latino" not in n and "lat" not in toks:
        return False
    return not any(k in n for k in ("castellano", "spanish", "espanol", "español", "spa ", "[spa", "dual"))

def _is_spanish(name):
    n = name.lower()
    return any(k in n for k in ("castellano", "spanish", "espanol", "español", "[spa", " spa", "dual", "vose"))

def search_candidates(query):
    out = []
    try:
        r = requests.get("https://apibay.org/q.php", params={"q": query},
                         headers=UA, timeout=20)
        for it in r.json():
            if it.get("info_hash") in (None, "0" * 40):
                continue
            out.append({
                "name": it.get("name", ""),
                "magnet": "magnet:?xt=urn:btih:%s&dn=%s" % (it["info_hash"],
                          requests.utils.quote(it.get("name", ""))),
                "seeders": int(it.get("seeders") or 0),
                "size": int(it.get("size") or 0),
            })
    except Exception as e:
        xbmc.log("PalAntriX live apibay: %s" % type(e).__name__, xbmc.LOGWARNING)
    seen, uniq = set(), []
    for c in out:
        key = c["magnet"].split("btih:")[-1].split("&")[0].lower()
        if key in seen or _is_latino_only(c["name"]):
            continue
        seen.add(key)
        uniq.append(c)
    uniq.sort(key=lambda c: (0 if _is_spanish(c["name"]) else 1,
                             _quality_rank(c["name"]), -c["seeders"]))
    return uniq

def _flatten_files(nodes, out=None):
    if out is None:
        out = []
    for node in nodes or []:
        if node.get("e"):
            _flatten_files(node["e"], out)
        elif node.get("l"):
            out.append({"filename": node.get("n") or "",
                        "size": node.get("s") or 0,
                        "link": node["l"]})
    return out

def _magnet_to_stream(ad, magnet, dlg=None, tries=20):
    mid = ad.magnet_upload(magnet)
    for i in range(tries):
        st = ad.magnet_status(mid)
        status = (st.get("status") or "").lower()
        code = st.get("statusCode")
        if "error" in status or code in (7, 8, 9, 10):
            return None
        if code == 4 or status == "ready":
            files = _flatten_files(ad.magnet_files(mid))
            videos = [f for f in files if f["filename"].lower().endswith(VIDEO_EXT)]
            pool = videos or files
            if not pool:
                return None
            pool.sort(key=lambda f: -f["size"])
            return ad.unlock(pool[0]["link"])
        if dlg is not None and dlg.iscanceled():
            return None
        time.sleep(3)
    return None

def resolve_magnet(ad, magnet, cancel=None):
    """Magnet → stream desbloqueado (o None). Como _magnet_to_stream
    pero la cancelación es un callable: lo usa la cadena de la Fase 4
    desde su pantalla de carga, sin DialogProgress."""
    mid = ad.magnet_upload(magnet)
    for _i in range(20):
        st = ad.magnet_status(mid)
        status = (st.get("status") or "").lower()
        code = st.get("statusCode")
        if "error" in status or code in (7, 8, 9, 10):
            return None
        if code == 4 or status == "ready":
            files = _flatten_files(ad.magnet_files(mid))
            videos = [f for f in files if f["filename"].lower().endswith(VIDEO_EXT)]
            pool = videos or files
            if not pool:
                return None
            pool.sort(key=lambda f: -f["size"])
            return ad.unlock(pool[0]["link"])
        if cancel is not None and cancel():
            return None
        time.sleep(3)
    return None

def search_and_play(live_args):
    titulo = live_args.get("titulo") or ""
    if live_args.get("kind") == "serie":
        query = "%s S%02dE%02d" % (titulo, live_args.get("temporada") or 1,
                                   live_args.get("episodio") or 1)
    else:
        # Con el año, apibay responde; con el título solo, a los de una
        # palabra les devuelve cero (sup4-H7).
        ano = (live_args.get("fecha") or "")[:4]
        query = ("%s %s" % (titulo, ano)) if ano else titulo
    apikey = (ADDON.getSetting("alldebrid_apikey") or "").strip()
    if not apikey:
        dialogs.ok("PalAntriX", "Falta tu clave de AllDebrid para la búsqueda en vivo.")
        return False
    dlg = dialogs.Busy()
    dlg.create("PalAntriX", "Buscando en vivo…")
    try:
        cands = search_candidates(query)
        if not cands and query != titulo:
            cands = search_candidates(titulo)
        if not cands:
            dlg.close()
            dialogs.ok("PalAntriX",
                "Sin resultados en vivo para «%s» ahora mismo." % query)
            return False
        ad = AllDebrid(apikey)
        for cand in cands[:4]:
            if dlg.iscanceled():
                return False
            dlg.update(0, "Probando: %s" % cand["name"][:60])
            try:
                got = _magnet_to_stream(ad, cand["magnet"], dlg=dlg)
            except AllDebridError:
                got = None
            if got and got.get("link"):
                dlg.close()
                ad.delete_history()
                li = xbmcgui.ListItem(label=titulo)
                xbmc.Player().play(got["link"], li)
                return True
        dlg.close()
        dialogs.ok("PalAntriX",
            "Los resultados en vivo no están en caché ahora mismo; inténtalo más tarde.")
        return False
    finally:
        try:
            dlg.close()
        except Exception:
            pass
