# -*- coding: utf-8 -*-
"""Ventana Buscar (1304) — teclado propio + resultados del catálogo local.

Fase 2: sobre el teclado, la fila de «Búsquedas recientes» de la casa
(guardadas en userdata al confirmar una búsqueda abriendo una ficha;
clicables y borrables) ocupa el panel de resultados mientras no se
teclea, y los resultados con ámbito global van agrupados con rótulo
«Películas» y «Series».
"""
import xbmc
import xbmcaddon
import xbmcgui

from db import img
import dialogs

KEYS_ID = 400
RESULTS_ID = 410
LBL_QUERY = 950
LBL_COUNT = 960
IMG_FANART = 9000
BTN_ESPACIO = 420
BTN_BORRAR = 421
BTN_LIMPIAR = 422
BTN_VOZ = 423
BTN_BUSCAR = 810
BTN_AJUSTES = 811
BTN_CASA = 812

ACTION_MOVE_LEFT = 1
ACTION_MOVE_RIGHT = 2
ACTION_MOVE_UP = 3
ACTION_MOVE_DOWN = 4

KEYS = list("ABCDEFGHIJKLMNOPQRSTUVWXYZ") + list("0123456789") + ["Á", "É", "Í", "Ó", "Ú", "Ñ"]

class SearchWindow(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        super(SearchWindow, self).__init__(*args)
        self.catalog = kwargs.get("catalog")
        self.userdata = kwargs.get("userdata")
        self.playback = kwargs.get("playback")
        self.vault = kwargs.get("vault")
        self.addon_path = kwargs.get("addon_path")
        self.profile = kwargs.get("profile", "")
        self.ambito = kwargs.get("ambito")  # None | 'pelicula' | 'serie'
        self.query = ""
        self._inited = False
        self._items = []          # ítems del panel, en orden (para M4)
        self._last_focus = KEYS_ID
        self._res_pos = 0

    def onInit(self):
        if self._inited:
            from nav import unwind_home
            if unwind_home(self):
                return
            # Reactivación tras una ficha o una ventana de la barra
            # superior (sup1-M3): NO se reconstruye nada; el texto, los
            # resultados, su posición y el foco vuelven como estaban.
            try:
                if self._last_focus == RESULTS_ID and self._items:
                    self.getControl(RESULTS_ID).selectItem(
                        min(self._res_pos, len(self._items) - 1))
                self.setFocusId(self._last_focus)
            except Exception:
                pass
            return
        self._inited = True
        lst = self.getControl(KEYS_ID)
        lst.reset()
        items = []
        for k in KEYS:
            li = xbmcgui.ListItem(label=k)
            li.setProperty("key", k)
            items.append(li)
        lst.addItems(items)
        self._refresh()
        self.setFocusId(KEYS_ID)

    def onFocus(self, control_id):
        if control_id in (KEYS_ID, RESULTS_ID, BTN_ESPACIO, BTN_BORRAR,
                          BTN_LIMPIAR, BTN_VOZ, BTN_BUSCAR, BTN_AJUSTES, BTN_CASA):
            self._last_focus = control_id
        if control_id == KEYS_ID:
            # Sobre el teclado no hay miniatura concreta: fondo propio.
            try:
                self.getControl(IMG_FANART).setImage("", False)
            except Exception:
                pass

    def onAction(self, action):
        super(SearchWindow, self).onAction(action)
        aid = action.getId() if hasattr(action, "getId") else 0
        if aid not in (ACTION_MOVE_LEFT, ACTION_MOVE_RIGHT,
                       ACTION_MOVE_UP, ACTION_MOVE_DOWN):
            return
        if self.getFocusId() != RESULTS_ID or not self._items:
            return
        # Las celdas-encabezado («PELÍCULAS»/«SERIES») no son
        # enfocables (sup1-M4): si la selección cae en una, salta a la
        # celda útil más cercana en el sentido del movimiento.
        try:
            res = self.getControl(RESULTS_ID)
            pos = res.getSelectedPosition()
        except Exception:
            return
        if not (0 <= pos < len(self._items)):
            return
        if not self._items[pos].getProperty("header"):
            self._res_pos = pos
            # Regla del fondo (§1.8): sobre un resultado concreto,
            # el fondo es SU fanart.
            try:
                self.getControl(IMG_FANART).setImage(
                    self._items[pos].getArt("fanart") or "", False)
            except Exception:
                pass
            return
        step = -1 if aid in (ACTION_MOVE_LEFT, ACTION_MOVE_UP) else 1
        nxt = pos + step
        while 0 <= nxt < len(self._items) \
                and self._items[nxt].getProperty("header"):
            nxt += step
        if 0 <= nxt < len(self._items):
            res.selectItem(nxt)
            self._res_pos = nxt

    def _ambito_txt(self):
        if self.ambito:
            return "Buscar en %s" % ("Películas" if self.ambito == "pelicula"
                                     else "Series")
        return ""

    def _refresh(self):
        self.getControl(LBL_QUERY).setLabel(self.query + "|" if self.query else "|")
        res = self.getControl(RESULTS_ID)
        res.reset()
        if len(self.query) < 2:
            self._fill_recientes(res)
            return
        cat = self.catalog
        kinds = (self.ambito,) if self.ambito else ("pelicula", "serie")
        items = []
        total = 0
        for kind in kinds:
            rows = cat.grid(kind, offset=0, limit=40, query=self.query,
                            order="rating")
            if not rows:
                continue
            if not self.ambito:
                # rótulo de grupo (ámbito global): celda de texto sin póster
                cab = xbmcgui.ListItem(
                    label="[COLOR FFFF7800]%s[/COLOR]"
                          % ("PELÍCULAS" if kind == "pelicula" else "SERIES"))
                cab.setProperty("header", "1")
                items.append(cab)
            for r in rows:
                total += 1
                li = xbmcgui.ListItem(label=r.get("titulo") or "")
                li.setLabel2("%s · %s" % ((r.get("fecha") or "")[:4],
                                          "Película" if kind == "pelicula"
                                          else "Serie"))
                li.setArt({"poster": img(r.get("poster"), "w342"),
                           "fanart": img(r.get("fondo"), "w1280")})
                li.setProperty("tmdb", str(r.get("tmdb") or ""))
                li.setProperty("kind", kind)
                items.append(li)
        if not total:
            # Estado vacío con SALIDA (sup1-M8): el mapa pide «Buscar
            # en vivo» como acción enfocable, no un callejón informativo.
            vivo = xbmcgui.ListItem(
                label="[COLOR FFFF7800]Buscar en vivo[/COLOR]")
            vivo.setLabel2("«%s» fuera del catálogo" % self.query)
            vivo.setProperty("accion", "buscar_vivo")
            items.append(vivo)
        self.getControl(LBL_COUNT).setLabel(
            "%d resultados" % total if total
            else "Sin resultados en el catálogo")
        self._items = items
        res.addItems(items)

    def _fill_recientes(self, res):
        recientes = self.userdata.busquedas_recientes(10) if self.userdata else []
        if not recientes:
            self._items = []
            self.getControl(LBL_COUNT).setLabel(self._ambito_txt())
            return
        self.getControl(LBL_COUNT).setLabel("Búsquedas recientes")
        items = []
        for texto in recientes:
            li = xbmcgui.ListItem(label=texto)
            li.setLabel2("Búsqueda reciente")
            li.setProperty("reciente", texto)
            items.append(li)
        borrar = xbmcgui.ListItem(label="[COLOR FFFF7800]Borrar búsquedas recientes[/COLOR]")
        borrar.setProperty("accion", "borrar_recientes")
        items.append(borrar)
        self._items = items
        res.addItems(items)

    # ---------------- «Buscar en vivo» (sup1-M8) ----------------
    def _buscar_en_vivo(self):
        """Salida del estado vacío: candidatos de la capa en vivo con
        la consulta actual, en el selector agrupado de la casa; el
        elegido se resuelve por AllDebrid (resolve_magnet, Fase 4)."""
        import threading

        import live
        from alldebrid import AllDebrid
        apikey = (xbmcaddon.Addon().getSetting("alldebrid_apikey")
                  or "").strip()
        if not apikey:
            dialogs.ok(
                "PalAntriX",
                "Falta vincular AllDebrid. Ve a Servicios > AllDebrid "
                "y vincúlalo para poder buscar en vivo.")
            return
        query = self.query.strip()
        cands = live.search_candidates(query)
        if not cands:
            dialogs.notify("Sin resultados en vivo para «%s»" % query)
            return
        qn = {0: "DV", 1: "HDR10+", 2: "HDR", 3: "4K", 4: "1080p",
              5: "720p", 6: "SD"}
        rows = [{"dest": "header", "titulo": "En vivo"}]
        for cand in cands[:8]:
            lab = qn.get(live._quality_rank(cand["name"]), "?")
            lab += " · Castellano" if live._is_spanish(cand["name"]) \
                else " · Sin castellano"
            nota = []
            if cand.get("size"):
                nota.append("%.1f GB" % (cand["size"] / 1e9))
            if cand.get("seeders"):
                nota.append("%d semillas" % cand["seeders"])
            rows.append({"dest": "row", "titulo": lab,
                         "nota": " · ".join(nota),
                         "payload": {"origen": "vivo", "cand": cand}})
        from playui import SelectorWindow
        w = SelectorWindow("selector.xml", self.addon_path, "Default",
                           "1080i", rows=rows, titulo="Buscar en vivo",
                           subtitulo="«%s» fuera del catálogo" % query)
        w.doModal()
        choice = w.choice
        del w
        if not choice:
            return
        cand = choice["cand"]
        ad = AllDebrid(apikey)
        dlg = dialogs.Busy()
        dlg.create("PalAntriX", "Resolviendo enlace en vivo…")
        holder = {}

        def run():
            try:
                holder["stream"] = live.resolve_magnet(
                    ad, cand["magnet"], cancel=lambda: dlg.iscanceled())
            except Exception:
                holder["stream"] = None

        t = threading.Thread(target=run)
        t.daemon = True
        t.start()
        mon = xbmc.Monitor()
        while t.is_alive() and not mon.abortRequested():
            if mon.waitForAbort(0.25):
                break
        cancelado = dlg.iscanceled()
        dlg.close()
        stream = holder.get("stream")
        if stream and stream.get("link"):
            ad.delete_history()
            li = xbmcgui.ListItem(label=query)
            xbmc.Player().play(stream["link"], li)
        elif not cancelado:
            dialogs.notify("Ese enlace en vivo no está disponible ahora")

    def _restore_results(self):
        """Devuelve selección y foco al panel de resultados tras cerrar
        una ventana hija. Se llama desde onClick AL VOLVER de la hija
        (patrón del Inicio): la rama de reactivación de onInit no basta,
        porque al reactivarse la ventana Kodi dispara onFocus sobre el
        teclado y pisa _last_focus antes de que onInit lo lea."""
        if not self._items:
            return
        try:
            pos = min(self._res_pos, len(self._items) - 1)
            if pos >= 0:
                self.getControl(RESULTS_ID).selectItem(pos)
            self.setFocusId(RESULTS_ID)
        except Exception:
            pass

    def onClick(self, control_id):
        from nav import topbar_click
        if topbar_click(self, control_id):
            if self._last_focus == RESULTS_ID:
                self._restore_results()
            return
        if control_id == KEYS_ID:
            item = self.getControl(KEYS_ID).getSelectedItem()
            if item:
                self.query += item.getProperty("key")
                self._refresh()
            return
        if control_id == BTN_ESPACIO:
            self.query += " "
            self._refresh()
            return
        if control_id == BTN_BORRAR:
            self.query = self.query[:-1]
            self._refresh()
            return
        if control_id == BTN_LIMPIAR:
            self.query = ""
            self._refresh()
            return
        if control_id == BTN_VOZ:
            # Búsqueda por voz (§5): la API de Kodi NO ofrece
            # reconocimiento de voz a los addons; la única vía real
            # es la entrada de texto del sistema, que en Android TV
            # puede ofrecer el micrófono/dictado del teclado del
            # aparato. Se abre esa entrada; sin dictado disponible,
            # sirve como teclado normal. Es lo más cercano honesto:
            # no se finge un motor de voz propio.
            texto = xbmcgui.Dialog().input("Di el título o escríbelo")
            if texto and texto.strip():
                self.query = texto.strip()
                self._refresh()
                self.setFocusId(RESULTS_ID if self._items else KEYS_ID)
            return
        if control_id == RESULTS_ID:
            item = self.getControl(RESULTS_ID).getSelectedItem()
            if item is None or item.getProperty("header"):
                return
            if item.getProperty("accion") == "borrar_recientes":
                if self.userdata:
                    self.userdata.clear_busquedas()
                self._refresh()
                return
            if item.getProperty("accion") == "buscar_vivo":
                self._res_pos = self.getControl(
                    RESULTS_ID).getSelectedPosition()
                self._buscar_en_vivo()
                self._restore_results()
                return
            if item.getProperty("reciente"):
                self.query = item.getProperty("reciente")
                self._refresh()
                return
            if item.getProperty("tmdb"):
                # búsqueda confirmada: se guarda en las recientes de la casa
                if self.userdata and self.query.strip():
                    self.userdata.add_busqueda(self.query.strip())
                # posición exacta para la vuelta de la ficha (sup1-M3)
                self._res_pos = self.getControl(
                    RESULTS_ID).getSelectedPosition()
                self._last_focus = RESULTS_ID
                from detail import DetailWindow
                win = DetailWindow("detail.xml", self.addon_path, "Default", "1080i",
                                   catalog=self.catalog, userdata=self.userdata,
                                   playback=self.playback, vault=self.vault, addon_path=self.addon_path,
                                   profile=self.profile,
                                   kind=item.getProperty("kind") or "pelicula",
                                   tmdb=int(item.getProperty("tmdb")))
                win.doModal()
                del win
                # Al volver de la ficha, selección y foco al resultado
                # exacto (sup1-M3; ver _restore_results).
                self._restore_results()
