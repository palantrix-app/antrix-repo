# -*- coding: utf-8 -*-
"""Motor de menús de texto (Fase 1 del mapa aprobado).

El árbol completo de Palantir vive aquí COMO DATOS: cada nodo dice a dónde
lleva (otro menú, una rejilla con su especificación de consulta, el buscador
con ámbito, un estado de Trakt o Servicios). Una sola ventana genérica
(MenuWindow, 1306) pinta cualquier menú; las hojas de rejilla las consume la
ventana Sección existente a través de la «spec» del nodo (db.spec_rows).

Reglas del mapa que se cumplen aquí:
- Encabezados de grupo NO enfocables (ítems deshabilitados + salto en onAction).
- Un nodo de rejilla sin contenido (conteo 0) no se pinta; un grupo que se
  queda vacío tampoco.
- Memoria de foco exacta: al volver de una ventana hija se restaura el ítem.
- «Más vistas» no existe sin Trakt: el nodo se llama «Populares» (D2).
"""
import xbmc
import xbmcgui

from db import img

LIST_ID = 300
BTN_BUSCAR = 810
BTN_AJUSTES = 811
BTN_CASA = 812
IMG_FANART = 9000
IMG_POSTER = (961, 962, 963)
LBL_TITULO = 920
LBL_NOTA = 970

ACTION_MOVE_UP = 3
ACTION_MOVE_DOWN = 4

LETRAS = [chr(c) for c in range(ord("A"), ord("Z") + 1)] + ["Ñ", "0-9"]


def fmt_num(n):
    return "{:,}".format(n).replace(",", ".")


def _n(id_, titulo, dest, grupo=None, **kw):
    d = {"id": id_, "titulo": titulo, "dest": dest, "grupo": grupo}
    d.update(kw)
    return d


def _grid(id_, titulo, spec, grupo=None, unidad="títulos", **kw):
    return _n(id_, titulo, "grid", grupo, spec=spec, unidad=unidad, **kw)


def _spec(kind, order="updated", **filtros):
    s = {"tipo": "grid", "kind": kind, "order": order}
    s.update(filtros)
    return s


# Categorías con suciedad conocida de la base rescatada: hay 1 película con
# la categoría mal escrita «Ducumental»; el nodo Documentales la incluye.
def _cats_peli(cat):
    return [cat, "Ducumental"] if cat == "Documental" else [cat]


# ---------------------------------------------------------------------------
# Árbol estático
# ---------------------------------------------------------------------------
def _root():
    """Principal (§1, 2026-11-22): SOLO Películas, Series y «Más».
    «Seguir viendo» ya no vive en la principal; el seguimiento está
    dentro de Series/Películas, y el resto del árbol cuelga de «Más»."""
    return "PalAntriX", [
        _n("peliculas", "Películas", "hub", kind="pelicula",
           sample=_spec("pelicula", "fecha", novedad=True)),
        _n("series", "Series", "hub", kind="serie",
           sample=_spec("serie", "updated")),
        _n("mas", "Más", "menu", menu="mas",
           sample={"tipo": "novedades"}),
    ]


def _mas():
    """El cajón «Más» de la Principal (§1): Mi lista primero."""
    return "Más", [
        _grid("mi_lista", "Mi lista", {"tipo": "favoritos"},
              unidad="títulos", siempre=True),
        _grid("novedades", "Novedades", {"tipo": "novedades"},
              unidad="títulos", siempre=True),
        _n("telenovelas", "Telenovelas", "menu", menu="telenovelas",
           sample=_spec("serie", categorias=["Novela"])),
        _n("documentales", "Documentales", "menu", menu="cat:Documental",
           sample=_spec("pelicula", categorias=_cats_peli("Documental"))),
        _n("dibujos", "Dibujos", "menu", menu="cat:Dibujo",
           sample=_spec("pelicula", categorias=["Dibujo"])),
        _n("anime", "Anime", "menu", menu="cat:Anime",
           sample=_spec("pelicula", categorias=["Anime"])),
        _n("musica", "Música", "menu", menu="musica",
           sample=_spec("pelicula", categorias=["Música"])),
        _n("seleccion", "Nuestra Selección", "menu", menu="seleccion"),
        _n("buscar", "Buscar por título", "search", amb=None),
        _n("listas_trakt", "Listas Trakt.tv", "trakt_state", motivo="listas"),
        _n("servicios", "Servicios", "servicios"),
    ]


def _peliculas():
    g1, g2, g3 = "Descubrir", "Explorar", "Buscar por"
    return "Películas", [
        _grid("pel:novedades", "Novedades", _spec("pelicula", "fecha", novedad=True), g1),
        _grid("pel:anadidas", "Últimas añadidas", _spec("pelicula", "updated"), g1),
        _grid("pel:recomendadas", "Recomendadas", _spec("pelicula", "recomendadas"), g1),
        _grid("pel:populares", "Populares", _spec("pelicula", "populares"), g1),
        _grid("pel:populares_mes", "Populares este mes",
              _spec("pelicula", "populares", novedad=True), g1),
        _grid("pel:sagas", "Por sagas", {"tipo": "colecciones"}, g2, unidad="sagas"),
        _grid("pel:especial", "Especial", {"tipo": "colecciones", "especiales": True},
              g2, unidad="sagas"),
        _n("pel:titulo", "Título", "search", g3, amb="pelicula"),
        _n("pel:generos", "Géneros", "menu", g3, menu="generos",
           params={"titulo": "Géneros · Películas", "base": {"kind": "pelicula"}}),
        _n("pel:az", "Orden alfabético (A–Z)", "menu", g3, menu="letras",
           params={"titulo": "A–Z · Películas", "base": {"kind": "pelicula"}}),
        _n("pel:ano", "Año", "menu", g3, menu="anos",
           params={"titulo": "Año · Películas", "base": {"kind": "pelicula"}}),
        _n("pel:calidad", "Calidad", "menu", g3, menu="calidades",
           params={"titulo": "Calidad · Películas", "base": {"kind": "pelicula"}}),
    ]


def _series():
    g1, g2, g3 = "Descubrir", "Explorar", "Buscar por"
    return "Series", [
        _grid("ser:actualizaciones", "Últimas actualizaciones", _spec("serie", "updated"), g1),
        _grid("ser:nuevas", "Series nuevas", _spec("serie", "fecha", novedad=True), g1),
        _grid("ser:seguimiento", "En seguimiento", {"tipo": "seguimiento"}, g1,
              unidad="series"),
        _grid("ser:recomendadas", "Recomendadas", _spec("serie", "recomendadas"), g1),
        _grid("ser:populares", "Populares", _spec("serie", "populares"), g1),
        _grid("ser:populares_mes", "Populares este mes",
              _spec("serie", "populares", novedad=True), g1),
        _grid("ser:clasicas", "Clásicas", _spec("serie", "updated", categorias=["Retro"]), g2),
        _grid("ser:reality", "Reality", _spec("serie", "updated", categorias=["Reality"]), g2),
        _n("ser:titulo", "Título", "search", g3, amb="serie"),
        _n("ser:generos", "Géneros", "menu", g3, menu="generos",
           params={"titulo": "Géneros · Series", "base": {"kind": "serie"}}),
        _n("ser:ano", "Año", "menu", g3, menu="anos",
           params={"titulo": "Año · Series", "base": {"kind": "serie"}}),
        _n("ser:az", "Orden alfabético (A–Z)", "menu", g3, menu="letras",
           params={"titulo": "A–Z · Series", "base": {"kind": "serie"}}),
        _n("ser:calidad", "Calidad", "menu", g3, menu="calidades",
           params={"titulo": "Calidad · Series", "base": {"kind": "serie"}}),
    ]


def _telenovelas():
    base = {"kind": "serie", "categorias": ["Novela"]}
    return "Telenovelas", [
        _grid("tel:actualizaciones", "Últimas actualizaciones",
              _spec("serie", "updated", categorias=["Novela"])),
        _grid("tel:nuevas", "Series nuevas",
              _spec("serie", "fecha", categorias=["Novela"], novedad=True)),
        _n("tel:titulo", "Buscar por título", "search", amb="serie"),
        _n("tel:az", "Orden alfabético (A–Z)", "menu", menu="letras",
           params={"titulo": "A–Z · Telenovelas", "base": base}),
    ]


def _musica():
    return "Música", [
        _grid("mus:novedades", "Novedades",
              _spec("pelicula", "fecha", categorias=["Música"], novedad=True)),
        _grid("mus:anadidas", "Últimas añadidas",
              _spec("pelicula", "updated", categorias=["Música"])),
        _n("mus:titulo", "Buscar por título", "search", amb="pelicula"),
    ]


def _categoria(cat):
    """Plantilla mixta de Palantir: un solo menú, dos grupos (pelis/series)."""
    titulo = {"Dibujo": "Dibujos", "Anime": "Anime",
              "Documental": "Documentales"}[cat]
    cats_p = _cats_peli(cat)
    gp, gs = "Películas", "Series"
    cid = "cat" + cat
    nodes = [
        _grid(cid + ":p_novedades", "Novedades",
              _spec("pelicula", "fecha", categorias=cats_p, novedad=True), gp),
        _grid(cid + ":p_anadidas", "Últimas añadidas",
              _spec("pelicula", "updated", categorias=cats_p), gp),
        _grid(cid + ":p_sagas", "Por sagas", {"tipo": "colecciones"}, gp, unidad="sagas"),
        _grid(cid + ":p_especial", "Especial",
              {"tipo": "colecciones", "especiales": True}, gp, unidad="sagas"),
        _n(cid + ":p_titulo", "Buscar por título", "search", gp, amb="pelicula"),
        _n(cid + ":p_calidad", "Por calidad", "menu", gp, menu="calidades",
           params={"titulo": "Calidad · %s" % titulo,
                   "base": {"kind": "pelicula", "categorias": cats_p}}),
        _n(cid + ":p_az", "Orden alfabético (A–Z)", "menu", gp, menu="letras",
           params={"titulo": "A–Z · %s" % titulo,
                   "base": {"kind": "pelicula", "categorias": cats_p}}),
        _grid(cid + ":s_actualizaciones", "Últimas actualizaciones",
              _spec("serie", "updated", categorias=[cat]), gs),
        _grid(cid + ":s_nuevas", "Series nuevas",
              _spec("serie", "fecha", categorias=[cat], novedad=True), gs),
        _n(cid + ":s_titulo", "Buscar por título", "search", gs, amb="serie"),
        _n(cid + ":s_az", "Orden alfabético (A–Z)", "menu", gs, menu="letras",
           params={"titulo": "A–Z · %s" % titulo,
                   "base": {"kind": "serie", "categorias": [cat]}}),
    ]
    return titulo, nodes


# Listas de Nuestra Selección (menú 110 de Palantir): (usuario, lista, tabla)
_SELECCION_PELIS = [
    ("Lo mejor de Amazon", "bluntmankush", "amazon-prime-video"),
    ("Lo mejor de Netflix", "hdlists", "best-movies-on-netflix"),
    ("Lo mejor de Disney", "mdatum", "disney"),
    ("Lo mejor de HBO", "shaunatkins11", "hbo-movies"),
    ("Basado en una historia real", "hdlists", "based-on-or-inspired-by-a-true-story"),
]
_SELECCION_SERIES = [
    ("Lo mejor de Amazon", "garycrawfordgc", "amazon-prime-shows"),
    ("Lo mejor de Netflix", "hdlists", "netflix-tv-shows-series-2021-2025"),
    ("Lo mejor de Disney", "hdlists", "disney-tv-shows-series-2021-2025"),
    ("Lo mejor de HBO", "garycrawfordgc", "hbo-shows"),
    ("Lo mejor de Apple TV", "hdlists", "apple-tv-shows-series-2021-2025"),
]


def _seleccion():
    nodes = []
    for i, (titulo, user, lista) in enumerate(_SELECCION_PELIS):
        nodes.append(_n("sel:p%d" % i, titulo, "trakt_state", "Películas",
                        motivo="seleccion"))
    for i, (titulo, user, lista) in enumerate(_SELECCION_SERIES):
        nodes.append(_n("sel:s%d" % i, titulo, "trakt_state", "Series",
                        motivo="seleccion"))
    return "Nuestra Selección", nodes


def _favoritos():
    cats = [("General", ""), ("Dibujo", " de dibujos"), ("Documental", " documentales"),
            ("Anime", " de anime")]
    nodes = []
    for cat, suf in cats:
        nodes.append(_n("fav:p:" + cat, "Películas favoritas" + suf,
                        "trakt_state", "Películas", motivo="favoritos"))
    for cat, suf in cats:
        nodes.append(_n("fav:s:" + cat, "Series favoritas" + suf,
                        "trakt_state", "Series", motivo="favoritos"))
    nodes.append(_n("fav:s:todas", "Todas las series", "trakt_state", "Series",
                    motivo="favoritos"))
    return "Favoritos", nodes


# ---------------------------------------------------------------------------
# Menús dinámicos (hijos de «Buscar por»): se construyen desde los datos
# ---------------------------------------------------------------------------
def _dyn_letras(catalog, params):
    base = params.get("base") or {}
    conteos = catalog.letras_con_conteo(base.get("kind", "pelicula"),
                                        base.get("categorias"))
    nodes = []
    for letra in LETRAS:
        n = conteos.get(letra, 0)
        if not n:
            continue
        spec = {"tipo": "grid", "kind": base.get("kind", "pelicula"),
                "order": "titulo", "letra": letra}
        if base.get("categorias"):
            spec["categorias"] = base["categorias"]
        nodes.append(_grid("letra:" + letra, letra, spec, nota="%s títulos" % fmt_num(n), contado=True))
    return params.get("titulo", "A–Z"), nodes


def _dyn_generos(catalog, params):
    base = params.get("base") or {}
    conteos = catalog.generos_con_conteo(base.get("kind", "pelicula"),
                                         base.get("categorias"))
    nodes = []
    for genero in sorted(conteos):
        spec = {"tipo": "grid", "kind": base.get("kind", "pelicula"),
                "order": "updated", "genero": genero}
        if base.get("categorias"):
            spec["categorias"] = base["categorias"]
        nodes.append(_grid("genero:" + genero, genero, spec,
                           nota="%s títulos" % fmt_num(conteos[genero]), contado=True))
    return params.get("titulo", "Géneros"), nodes


def _dyn_anos(catalog, params):
    base = params.get("base") or {}
    nodes = []
    for year, n in catalog.anos_con_conteo(base.get("kind", "pelicula"),
                                           base.get("categorias")):
        spec = {"tipo": "grid", "kind": base.get("kind", "pelicula"),
                "order": "fecha", "year": year}
        if base.get("categorias"):
            spec["categorias"] = base["categorias"]
        nodes.append(_grid("ano:" + str(year), str(year), spec,
                           nota="%s títulos" % fmt_num(n), contado=True))
    return params.get("titulo", "Año"), nodes


def _dyn_calidades(catalog, params):
    base = params.get("base") or {}
    kind = base.get("kind", "pelicula")
    conteos = catalog.calidades_con_conteo(kind)
    nodes = []
    for cubo in ("DV", "4K", "1080p", "HD", "SD"):
        n = conteos.get(cubo, 0)
        if not n:
            continue
        spec = {"tipo": "grid", "kind": kind, "order": "updated", "calidad": cubo}
        if base.get("categorias"):
            spec["categorias"] = base["categorias"]
        nodes.append(_grid("calidad:" + cubo, cubo, spec,
                           nota="%s títulos" % fmt_num(n), contado=True))
    return params.get("titulo", "Calidad"), nodes


_BUILDERS = {
    "root": lambda cat, ud, params: _root(),
    "mas": lambda cat, ud, params: _mas(),
    "peliculas": lambda cat, ud, params: _peliculas(),
    "series": lambda cat, ud, params: _series(),
    "telenovelas": lambda cat, ud, params: _telenovelas(),
    "musica": lambda cat, ud, params: _musica(),
    "seleccion": lambda cat, ud, params: _seleccion(),
    "favoritos": lambda cat, ud, params: _favoritos(),
    "letras": lambda cat, ud, params: _dyn_letras(cat, params or {}),
    "generos": lambda cat, ud, params: _dyn_generos(cat, params or {}),
    "anos": lambda cat, ud, params: _dyn_anos(cat, params or {}),
    "calidades": lambda cat, ud, params: _dyn_calidades(cat, params or {}),
}


def build_menu(menu_id, catalog, userdata=None, params=None):
    """Devuelve (título, [nodos]) del menú pedido."""
    if menu_id.startswith("cat:"):
        return _categoria(menu_id[4:])
    builder = _BUILDERS.get(menu_id)
    if builder is None:
        return "", []
    return builder(catalog, userdata, params)


# ---------------------------------------------------------------------------
# Trakt: estado y pantalla de estado (el flujo completo es la Fase 3)
# ---------------------------------------------------------------------------
def trakt_state():
    import trakt
    if not trakt.configured():
        return "sin_configurar"
    if not trakt.linked():
        return "sin_vincular"
    return "vinculado"


_TRAKT_TEXTOS = {
    "favoritos": (
        "Favoritos",
        "Tus Favoritos viven en Trakt, como en Palantir.\n\n"
        "%s\n\n"
        "Mientras tanto, tu historial y tu «Seguir viendo» siguen "
        "funcionando aquí, en local."),
    "seleccion": (
        "Nuestra Selección",
        "Estas listas («Lo mejor de Netflix», «Lo mejor de HBO»…) viven "
        "en Trakt.\n\n%s"),
    "listas": (
        "Listas Trakt.tv",
        "El explorador de listas de Trakt necesita tu cuenta de Trakt "
        "vinculada.\n\n%s"),
}

_TRAKT_PASO = {
    "sin_configurar": ("Falta configurar Trakt: la app ya trae las "
                       "claves del proyecto; si ves este mensaje, esta "
                       "copia está incompleta."),
    "sin_vincular": ("Falta vincular tu cuenta: entra en Ajustes › "
                     "Trakt y sigue el código de activación."),
    "vinculado": "Tu cuenta de Trakt está vinculada; esta parte llega con "
                 "la sincronización completa.",
}


def open_trakt_state(win, motivo):
    titulo, plantilla = _TRAKT_TEXTOS.get(motivo, _TRAKT_TEXTOS["favoritos"])
    texto = plantilla % _TRAKT_PASO[trakt_state()]
    w = TraktStateWindow("trakt_state.xml", win.addon_path, "Default", "1080i",
                         catalog=win.catalog, userdata=getattr(win, "userdata", None),
                         playback=getattr(win, "playback", None),
                         vault=getattr(win, "vault", None),
                         addon_path=win.addon_path,
                         profile=getattr(win, "profile", ""),
                         titulo=titulo, texto=texto)
    w.doModal()
    del w


# ---------------------------------------------------------------------------
# Apertura de nodos y menús (compartido por Inicio y MenuWindow)
# ---------------------------------------------------------------------------
def corregir_posicion(display, pos, prev, action_id):
    """Corrige la selección tras un movimiento de Kodi en una lista con
    encabezados de grupo:

    - Los encabezados NO son desactivables (ListItem no tiene setEnabled
      en Kodi 20): si la selección cae en uno, salta al accionable más
      cercano en el sentido del movimiento; si ese sentido se agota
      (borde), prueba el contrario. Nunca deja el foco en un encabezado.
    - Sin wrap vertical (contrato del mapa): si Kodi dio la vuelta
      (abajo desde el final → primera fila, o al revés), vuelve al
      extremo del que se venía.
    """
    if not (0 <= pos < len(display)):
        return pos
    if display[pos].get("dest") == "header":
        step = -1 if action_id == ACTION_MOVE_UP else 1
        for st in (step, -step):
            nxt = pos + st
            while 0 <= nxt < len(display) and display[nxt].get("dest") == "header":
                nxt += st
            if 0 <= nxt < len(display):
                return nxt
        return pos
    if prev is not None and pos != prev:
        if action_id == ACTION_MOVE_DOWN and pos < prev:
            for nxt in range(len(display) - 1, -1, -1):
                if display[nxt].get("dest") != "header":
                    return nxt
        if action_id == ACTION_MOVE_UP and pos > prev:
            for nxt in range(len(display)):
                if display[nxt].get("dest") != "header":
                    return nxt
    return pos


def open_menu(win, menu_id, params=None, focus_id=None):
    if menu_id in ("favoritos", "seleccion"):
        if trakt_state() != "vinculado":
            open_trakt_state(win, menu_id)
            return
        if menu_id == "seleccion":
            # Con Trakt vinculado el menú se abre; cada lista es Fase 3.
            pass
    titulo, nodes = build_menu(menu_id, win.catalog, getattr(win, "userdata", None),
                               params)
    if not nodes:
        return
    w = MenuWindow("menu.xml", win.addon_path, "Default", "1080i",
                   catalog=win.catalog, userdata=getattr(win, "userdata", None),
                   playback=getattr(win, "playback", None),
                   vault=getattr(win, "vault", None),
                   addon_path=win.addon_path,
                   profile=getattr(win, "profile", ""),
                   nodes=nodes, titulo=titulo, focus_id=focus_id)
    w.doModal()
    del w


def open_node(win, node):
    dest = node.get("dest")
    if dest == "menu":
        open_menu(win, node.get("menu"), node.get("params"))
    elif dest == "hub":
        from hub import HubWindow
        w = HubWindow("hub.xml", win.addon_path, "Default", "1080i",
                      catalog=win.catalog, userdata=getattr(win, "userdata", None),
                      playback=getattr(win, "playback", None),
                      vault=getattr(win, "vault", None),
                      addon_path=win.addon_path,
                      profile=getattr(win, "profile", ""),
                      kind=node.get("kind", "serie"))
        w.doModal()
        del w
    elif dest == "grid":
        from section import SectionWindow
        w = SectionWindow("section.xml", win.addon_path, "Default", "1080i",
                          catalog=win.catalog, userdata=getattr(win, "userdata", None),
                          playback=getattr(win, "playback", None),
                          vault=getattr(win, "vault", None),
                          addon_path=win.addon_path,
                          profile=getattr(win, "profile", ""),
                          kind=(node.get("spec") or {}).get("kind", "pelicula"),
                          spec=node.get("spec"), titulo=node.get("titulo"))
        w.doModal()
        del w
    elif dest == "search":
        from nav import open_search
        open_search(win, amb=node.get("amb"))
    elif dest == "servicios":
        # Fase 3: Servicios es ventana propia (1308), nodo de la raíz (D3).
        from nav import open_services
        open_services(win)
    elif dest == "trakt_state":
        open_trakt_state(win, node.get("motivo", "favoritos"))


def visible_nodes(nodes, catalog):
    """Aplica la regla del mapa: rejilla sin contenido no se pinta, y un
    grupo que se queda sin ítems pierde también su encabezado.
    Devuelve la lista a pintar, con los encabezados intercalados."""
    out = []
    for node in nodes:
        if node.get("dest") == "grid" and node.get("spec") is not None:
            if node.get("contado") or node.get("siempre"):
                # «contado»: el constructor dinámico ya contó y descartó
                # los ceros. «siempre» (§1): Mi lista y Novedades se
                # ofrecen aunque estén vacías — son destinos fijos
                # del mapa, no descubrimientos.
                out.append(node)
                continue
            if node["spec"].get("tipo") == "colecciones":
                out.append(node)  # las sagas siempre se ofrecen
                continue
            try:
                n = catalog.spec_count(node["spec"])
            except Exception:
                n = 1
            if n <= 0:
                continue
            node = dict(node)
            if not node.get("nota"):
                node["nota"] = "%s %s" % (fmt_num(n), node.get("unidad", "títulos"))
        out.append(node)
    display = []
    grupos_vistos = set()
    for node in out:
        g = node.get("grupo")
        if g and g not in grupos_vistos:
            display.append({"id": "__h__" + g, "titulo": g.upper(),
                            "dest": "header", "grupo": g})
            grupos_vistos.add(g)
        display.append(node)
    return display


# ---------------------------------------------------------------------------
# Ventana de menú genérica (1306)
# ---------------------------------------------------------------------------
class MenuWindow(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        super(MenuWindow, self).__init__(*args)
        self.catalog = kwargs.get("catalog")
        self.userdata = kwargs.get("userdata")
        self.playback = kwargs.get("playback")
        self.vault = kwargs.get("vault")
        self.addon_path = kwargs.get("addon_path")
        self.profile = kwargs.get("profile", "")
        self.nodes = kwargs.get("nodes") or []
        self.titulo = kwargs.get("titulo") or ""
        self.focus_id = kwargs.get("focus_id")
        self.display = []        # nodos visibles (con encabezados intercalados)
        self._pos = 0
        self._fanart_actual = ""
        self._samples = {}

    # ---------- construcción de la lista visible ----------
    def _fill(self):
        self.display = visible_nodes(self.nodes, self.catalog)
        lst = self.getControl(LIST_ID)
        lst.reset()
        items = []
        for node in self.display:
            li = xbmcgui.ListItem(label=node.get("titulo") or "")
            if node.get("dest") == "header":
                # Ojo: ListItem no tiene setEnabled en Kodi 20; el salto
                # de encabezados lo garantiza corregir_posicion().
                li.setProperty("header", "1")
            else:
                li.setLabel2(node.get("nota") or "")
                li.setProperty("node_id", node.get("id") or "")
            items.append(li)
        lst.addItems(items)

    def _first_actionable(self):
        for i, node in enumerate(self.display):
            if node.get("dest") != "header":
                return i
        return 0

    def _index_of(self, node_id):
        for i, node in enumerate(self.display):
            if node.get("id") == node_id:
                return i
        return self._first_actionable()

    # ---------- vista previa ----------
    def _node_samples(self, node):
        key = node.get("id")
        if key in self._samples:
            return self._samples[key]
        rows = []
        spec = node.get("sample") or node.get("spec")
        if spec is not None:
            try:
                rows = self.catalog.spec_sample(spec, 3)
            except Exception:
                rows = []
        self._samples[key] = rows
        return rows

    def _preview(self, pos):
        if not (0 <= pos < len(self.display)):
            return
        node = self.display[pos]
        if node.get("dest") == "header":
            return
        rows = self._node_samples(node)
        for i, ctl in enumerate(IMG_POSTER):
            img_ctl = self.getControl(ctl)
            if i < len(rows):
                img_ctl.setImage(img(rows[i].get("poster"), "w500"), False)
                img_ctl.setVisible(True)
            else:
                img_ctl.setVisible(False)
        # Regla del fondo (§1.8): un ítem de menú NO es una miniatura
        # concreta; el fondo se queda en el propio de PalAntriX.
        if self._fanart_actual:
            self._fanart_actual = ""
            self.getControl(IMG_FANART).setImage("", False)
        nota = node.get("nota") or ""
        self.getControl(LBL_NOTA).setLabel(nota)

    # ---------- ventana ----------
    def onInit(self):
        self.getControl(LBL_TITULO).setLabel(self.titulo)
        if getattr(self, "_inited", False):
            from nav import unwind_home
            if unwind_home(self):
                return
            # Reactivación al cerrarse una ventana hija: la lista sigue
            # cargada y _pos guarda la posición exacta; solo se reaplica.
            # (Sin esta guarda, onInit pisaba _pos con la primera fila.)
            try:
                lst = self.getControl(LIST_ID)
                if self.display:
                    lst.selectItem(self._pos)
                self.setFocusId(LIST_ID)
                self._preview(self._pos)
            except Exception:
                pass
            return
        self._inited = True
        self._fill()
        pos = self._index_of(self.focus_id) if self.focus_id else self._first_actionable()
        self._pos = pos
        lst = self.getControl(LIST_ID)
        if self.display:
            lst.selectItem(pos)
        self.setFocusId(LIST_ID)
        self._preview(pos)

    def onAction(self, action):
        super(MenuWindow, self).onAction(action)
        try:
            lst = self.getControl(LIST_ID)
            pos = lst.getSelectedPosition()
        except Exception:
            return
        if not (0 <= pos < len(self.display)):
            return
        aid = action.getId() if hasattr(action, "getId") else 0
        buena = corregir_posicion(self.display, pos, self._pos, aid)
        if buena != pos:
            lst.selectItem(buena)
            pos = buena
        if pos != self._pos:
            self._pos = pos
            self._preview(pos)

    def onClick(self, control_id):
        from nav import topbar_click
        if topbar_click(self, control_id):
            return
        if control_id != LIST_ID:
            return
        lst = self.getControl(LIST_ID)
        pos = lst.getSelectedPosition()
        if not (0 <= pos < len(self.display)):
            return
        node = self.display[pos]
        if node.get("dest") == "header":
            return
        self._pos = pos
        open_node(self, node)
        # memoria de foco exacta al volver de la ventana hija
        try:
            lst.selectItem(self._pos)
            self.setFocusId(LIST_ID)
            self._preview(self._pos)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Pantalla de estado Trakt (1307)
# ---------------------------------------------------------------------------
class TraktStateWindow(xbmcgui.WindowXML):
    BTN_VINCULAR = 940
    LBL_TITULO = 920
    TXT_TEXTO = 930

    def __init__(self, *args, **kwargs):
        super(TraktStateWindow, self).__init__(*args)
        self.catalog = kwargs.get("catalog")
        self.userdata = kwargs.get("userdata")
        self.playback = kwargs.get("playback")
        self.vault = kwargs.get("vault")
        self.addon_path = kwargs.get("addon_path")
        self.profile = kwargs.get("profile", "")
        self.titulo = kwargs.get("titulo") or ""
        self.texto = kwargs.get("texto") or ""

    def onInit(self):
        if getattr(self, "_inited", False):
            from nav import unwind_home
            if unwind_home(self):
                return
        self._inited = True
        self.getControl(self.LBL_TITULO).setLabel(self.titulo)
        self.getControl(self.TXT_TEXTO).setText(self.texto)
        self.setFocusId(self.BTN_VINCULAR)

    def onClick(self, control_id):
        from nav import topbar_click
        if topbar_click(self, control_id):
            return
        if control_id == self.BTN_VINCULAR:
            # Fase 3: el flujo de vinculación vive en Servicios › Trakt
            # (asistente si falta configurar; código si falta vincular).
            from nav import open_services
            open_services(self)
