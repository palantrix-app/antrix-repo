# -*- coding: utf-8 -*-
"""Ventana Detalle (1302) — la Ficha (§3 del repaso, 2026-11-22).

Título grande; se quedan la línea de datos (con géneros clicables),
la sinopsis, el fanart de fondo y el póster grande a la derecha.
Botones: «Reproducir» y, en series, «Temporadas», con «Mi lista» y
el menú «Más» al lado — ese menú (marcar visto/no visto por título
o temporada, ver tráiler, Enlaces) se despliega con el selector
VISUAL de la casa, no con el menú de Kodi (§7). Relacionados ha
desaparecido: abajo va una barra con los últimos capítulos como
miniaturas con su número (series) o el reparto como miniaturas
con foto y nombre (películas; el reparto y los fotogramas vienen
de TMDB en tiempo real, tmdb.py). La marca NUEVO (§2) se pinta
sobre el título si el título tiene entradas recientes.
"""
import xbmc
import xbmcgui

import dialogs
from db import img

BTN_PLAY = 300
BTN_LISTA = 301
BTN_TEMP = 302
BTN_MAS = 303
LIST_EPS = 330
LIST_CAST = 331
BTN_BUSCAR = 810
BTN_AJUSTES = 811
BTN_CASA = 812
IMG_FANART = 9000
IMG_POSTER = 9030
TXT_TITULO = 9020
LBL_META = 9021
TXT_PLOT = 9022
LBL_QUEDAN = 9060
IMG_NUEVO = 9070
LBL_NUEVO = 9071
LBL_BAR = 9210
CHIP_IMG = (9040, 9041, 9042, 9043)
CHIP_LBL = (9050, 9051, 9052, 9053)

class DetailWindow(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        super(DetailWindow, self).__init__(*args)
        self.catalog = kwargs.get("catalog")
        self.userdata = kwargs.get("userdata")
        self.playback = kwargs.get("playback")
        self.vault = kwargs.get("vault")
        self.addon_path = kwargs.get("addon_path")
        self.profile = kwargs.get("profile", "")
        self.kind = kwargs.get("kind", "pelicula")
        self.tmdb = kwargs.get("tmdb")
        self.row = None
        self.next_ep = None     # (temporada, episodio, progress) para series
        self.eps_bar = []       # [(temporada, episodio)] de la barra (§3)
        self.cast_bar = []      # [{id, nombre, foto}] de la barra (§3)
        self._bar_id = None     # LIST_EPS | LIST_CAST | None
        self._inited = False
        self._last_focus = BTN_PLAY

    def _meta(self, row):
        parts = []
        fecha = row.get("fecha") or ""
        if fecha:
            parts.append(fecha[:4])
        if self.kind == "pelicula" and row.get("duration"):
            d = row["duration"]
            try:
                # duration viene en SEGUNDOS en el catálogo (6120 = 102 min)
                mins = int(d) // 60
                parts.append("%d h %02d min" % (mins // 60, mins % 60) if mins >= 60 else "%d min" % mins)
            except Exception:
                parts.append(str(d))
        parts.append("Película" if self.kind == "pelicula" else "Serie")
        gen = (row.get("genero") or "").replace("#", ", ")
        if gen:
            parts.append(gen)
        rating = (row.get("rating") or "").split("/")[0].strip()
        if rating:
            parts.append("Nota " + rating.replace(".", ","))
        return "  ·  ".join(parts)

    def _compute_next_ep(self):
        cat = self.catalog
        if self.vault is None:
            return None
        last = cat.ultimo_visto_ep(self.tmdb)
        seasons = self.vault.seasons(self.tmdb)
        if not seasons:
            return None
        if last:
            t, e, prog = last["temporada"], last["episodio"], last.get("progress") or 0
            if 1 < prog < 97:
                return (t, e, prog)
            eps = [x["episodio"] for x in self.vault.episodes(self.tmdb, t)]
            nxt = [x for x in eps if x > e]
            if nxt:
                return (t, nxt[0], 0)
            later = [s["temporada"] for s in seasons if s["temporada"] > t]
            if later:
                t2 = later[0]
                eps2 = self.vault.episodes(self.tmdb, t2)
                if eps2:
                    return (t2, eps2[0]["episodio"], 0)
            return (t, e, 0)
        t0 = seasons[0]["temporada"]
        eps0 = self.vault.episodes(self.tmdb, t0)
        return (t0, eps0[0]["episodio"], 0) if eps0 else None

    def _refresh_play(self):
        play = self.getControl(BTN_PLAY)
        quedan = self.getControl(LBL_QUEDAN)
        quedan.setLabel("")
        play.setLabel("▶ Reproducir")
        if self.kind == "serie":
            self.next_ep = self._compute_next_ep()
            if self.next_ep:
                t, e, prog = self.next_ep
                if prog:
                    play.setLabel("Seguir · T%d E%d" % (t, e))
                    quedan.setLabel("a medias — se reanuda donde ibas")
                else:
                    play.setLabel("Reproducir · T%d E%d" % (t, e))
        else:
            prog = self.catalog.progreso_peli(self.tmdb)
            if prog and 1 < (prog.get("progress") or 0) < 97:
                play.setLabel("Seguir viendo")
                quedan.setLabel("a medias — se reanuda donde ibas")

    def _fill_barra(self):
        """La barra inferior de la ficha (§3): en series, los últimos
        capítulos como miniaturas con su número (fotograma de TMDB si
        lo hay; si no, el fondo de la serie); en películas, el reparto
        como miniaturas con foto y nombre."""
        import tmdb as tmdb_api
        eps_list = self.getControl(LIST_EPS)
        cast_list = self.getControl(LIST_CAST)
        eps_list.setVisible(False)
        cast_list.setVisible(False)
        self._bar_id = None
        if self.kind == "serie":
            if self.vault is None:
                self.getControl(LBL_BAR).setVisible(False)
                return
            estructura = []
            for s in self.vault.seasons(self.tmdb):
                t = s["temporada"]
                for ep in self.vault.episodes(self.tmdb, t):
                    estructura.append((t, ep["episodio"]))
            self.eps_bar = list(reversed(estructura[-14:]))
            if not self.eps_bar:
                self.getControl(LBL_BAR).setVisible(False)
                return
            stills = {}
            for t in {t for t, _e in self.eps_bar}:
                stills[t] = tmdb_api.season_episodes(self.tmdb, t)
            items = []
            for t, e in self.eps_bar:
                info = stills.get(t, {}).get(e, {})
                li = xbmcgui.ListItem(
                    label=info.get("nombre") or "Episodio %d" % e)
                li.setLabel2("T%d E%d" % (t, e))
                li.setArt({"thumb": info.get("still")
                           or img(self.row.get("fondo"), "w300")})
                li.setProperty("t", str(t))
                li.setProperty("e", str(e))
                li.setProperty("num", "%d" % e)
                if self.catalog.episodio_nuevo(self.tmdb, t, e):
                    li.setProperty("nuevo", "1")
                items.append(li)
            eps_list.reset()
            eps_list.addItems(items)
            eps_list.setVisible(True)
            self.getControl(LBL_BAR).setLabel("Últimos capítulos")
            self.getControl(LBL_BAR).setVisible(True)
            self._bar_id = LIST_EPS
        else:
            self.cast_bar = tmdb_api.movie_cast(self.tmdb)
            if not self.cast_bar:
                self.getControl(LBL_BAR).setVisible(False)
                return
            items = []
            for c in self.cast_bar:
                li = xbmcgui.ListItem(label=c["nombre"])
                li.setLabel2(c.get("personaje") or "")
                li.setArt({"thumb": c.get("foto") or ""})
                if c.get("id"):
                    li.setProperty("person", str(c["id"]))
                items.append(li)
            cast_list.reset()
            cast_list.addItems(items)
            cast_list.setVisible(True)
            self.getControl(LBL_BAR).setLabel("Reparto")
            self.getControl(LBL_BAR).setVisible(True)
            self._bar_id = LIST_CAST

    def onInit(self):
        if self._inited:
            from nav import unwind_home
            if unwind_home(self):
                return
            # Reactivación tras una ventana hija (otra ficha, episodios):
            # no se reconstruye nada; se devuelve el foco a su sitio.
            try:
                self.setFocusId(self._last_focus)
            except Exception:
                pass
            return
        self._inited = True
        cat = self.catalog
        row = cat.detail(self.kind, self.tmdb)
        self.row = row
        if not row:
            self.close()
            return
        self.getControl(IMG_FANART).setImage(img(row.get("fondo"), "w1280"), False)
        self.getControl(IMG_POSTER).setImage(img(row.get("poster"), "w500"), False)
        self.getControl(TXT_TITULO).setText(row.get("titulo") or "")
        self.getControl(LBL_META).setLabel(self._meta(row))
        self.getControl(TXT_PLOT).setText(row.get("plot") or "")
        cals = (self.vault.calidades(self.kind, self.tmdb) if self.vault else [])[:4]
        for i in range(4):
            vis = i < len(cals)
            self.getControl(CHIP_IMG[i]).setVisible(vis)
            lbl = self.getControl(CHIP_LBL[i])
            lbl.setVisible(vis)
            if vis:
                lbl.setLabel(cals[i])
        self.getControl(BTN_TEMP).setVisible(self.kind == "serie")
        nuevo = self.catalog.es_nuevo(self.kind, self.tmdb)
        self.getControl(IMG_NUEVO).setVisible(nuevo)
        self.getControl(LBL_NUEVO).setVisible(nuevo)
        self._refresh_play()
        self._refresh_lista()
        self._fill_barra()
        self._rewire_nav()

    def _rewire_nav(self):
        """Navegación condicional según lo visible: en una película
        «Temporadas» (302) está OCULTO y la cadena no debe pasar por
        él; el ↓ de la fila de botones baja a la barra inferior
        (capítulos o reparto) solo si la barra existe."""
        try:
            ids = (BTN_PLAY, BTN_LISTA, BTN_TEMP, BTN_MAS,
                   LIST_EPS, LIST_CAST, LBL_META)
            c = {i: self.getControl(i) for i in ids}
            bar = c[self._bar_id] if self._bar_id else None
            if bar is not None:
                bar.setNavigation(c[BTN_LISTA], bar, bar, bar)
            down_lista = bar or c[BTN_LISTA]
            if self.kind == "serie":
                c[BTN_LISTA].setNavigation(
                    c[BTN_PLAY], down_lista, c[BTN_LISTA], c[BTN_TEMP])
                c[BTN_TEMP].setNavigation(
                    c[BTN_PLAY], bar or c[BTN_TEMP],
                    c[BTN_LISTA], c[BTN_MAS])
                c[BTN_MAS].setNavigation(
                    c[BTN_PLAY], bar or c[BTN_MAS],
                    c[BTN_TEMP], c[BTN_MAS])
            else:
                # Sin 302: 301 ↔ 303 directos.
                c[BTN_LISTA].setNavigation(
                    c[BTN_PLAY], down_lista, c[BTN_LISTA], c[BTN_MAS])
                c[BTN_MAS].setNavigation(
                    c[BTN_PLAY], bar or c[BTN_MAS],
                    c[BTN_LISTA], c[BTN_MAS])
        except Exception:
            pass

    def onAction(self, action):
        aid = action.getId() if hasattr(action, "getId") else 0
        if aid in (79, 229) and self.playback:
            # Tecla Play (sup1-M7): reproduce directo, como el botón.
            if self.kind == "pelicula":
                self.playback.play_movie(self.tmdb)
            elif self.next_ep:
                t, e, _ = self.next_ep
                self.playback.play_episode(self.tmdb, t, e)
            return
        super(DetailWindow, self).onAction(action)

    def onFocus(self, control_id):
        if control_id in (BTN_PLAY, BTN_LISTA, BTN_TEMP, BTN_MAS,
                          LIST_EPS, LIST_CAST, LBL_META):
            self._last_focus = control_id

    def _refresh_lista(self):
        fav = self.userdata.is_fav(self.kind, self.tmdb) if self.userdata else False
        self.getControl(BTN_LISTA).setLabel("En tu lista" if fav else "+ Mi lista")

    # ---------------- acciones de la ficha-puerta ----------------
    def _generos(self):
        return [p.strip() for p in (self.row.get("genero") or "").split("#")
                if p.strip()] if self.row else []

    def _click_meta(self):
        gens = self._generos()
        if not gens:
            return
        if len(gens) == 1:
            self._abrir_genero(gens[0])
            return
        sel = dialogs.select("Géneros", gens)
        if sel >= 0:
            self._abrir_genero(gens[sel])

    def _abrir_genero(self, genero):
        from section import SectionWindow
        win = SectionWindow("section.xml", self.addon_path, "Default", "1080i",
                            catalog=self.catalog, userdata=self.userdata,
                            playback=self.playback, vault=self.vault,
                            addon_path=self.addon_path, profile=self.profile,
                            kind=self.kind,
                            spec={"tipo": "grid", "kind": self.kind,
                                  "order": "updated", "genero": genero},
                            titulo=genero)
        win.doModal()
        del win

    def _click_enlaces(self):
        """«Enlaces» de la ficha (§9): TODOS los enlaces del contenido
        —en series, los del capítulo que toca (el que reproduciría el
        botón Reproducir); en películas, los de la película—,
        ordenados por calidad con el mejor primero (links_meta ya los
        devuelve en el orden de reproducción) y con el CONTEO en el
        título de la lista. La estructura (calidad/audio) se ve sin
        desbloquear; al elegir, player reproduce ESE enlace por rowid.
        Se despliega con el selector visual de la casa (§7)."""
        if self.vault is None:
            dialogs.notify("Sin bóveda en este dispositivo")
            return
        if self.kind == "pelicula":
            meta = self.vault.links_meta("pelicula", self.tmdb)
            destino = ("pelicula", None, None)
            sub = self.row.get("titulo") if self.row else ""
        else:
            if not self.next_ep:
                dialogs.notify("Sin episodios en la bóveda")
                return
            t, e, _prog = self.next_ep
            meta = self.vault.links_meta("serie", self.tmdb, t, e)
            destino = ("serie", t, e)
            sub = "%s · T%d E%d" % (
                self.row.get("titulo") if self.row else "", t, e)
        if not meta:
            dialogs.notify("Sin enlaces en la bóveda")
            return
        labels = []
        for m in meta:
            lab = m.get("calidad") or "?"
            extras = " · ".join(x for x in (m.get("audio"), m.get("info")) if x)
            labels.append("%s · %s" % (lab, extras) if extras else lab)
        sel = dialogs.select("Enlaces · %d" % len(meta), labels,
                             subtitulo=sub)
        if sel < 0 or not self.playback:
            return
        rowid = meta[sel]["rowid"]
        if destino[0] == "pelicula":
            self.playback.play_movie(self.tmdb, link_rowid=rowid)
        else:
            self.playback.play_episode(self.tmdb, destino[1], destino[2],
                                       link_rowid=rowid)

    def _marcar_serie(self, temporada=None):
        """Marca vista la serie entera o una temporada (userdata local)."""
        if not (self.userdata and self.vault):
            return
        for s in self.vault.seasons(self.tmdb):
            t = s["temporada"]
            if temporada is not None and t != temporada:
                continue
            for ep in self.vault.episodes(self.tmdb, t):
                self.userdata.save_episode(self.tmdb, t, ep["episodio"], 0,
                                           finished=True)

    def _click_mas(self):
        """El menú «Más» de la ficha (§3): desplegable VISUAL propio
        de la app (el selector de la casa), junto a los botones."""
        opts, actos = [], []
        if self.kind == "pelicula":
            prog = self.catalog.progreso_peli(self.tmdb)
            visto = bool(prog and (prog.get("playcount") or 0) > 0)
            if visto:
                opts.append("Marcar como no visto"); actos.append("desvisto")
            else:
                opts.append("Marcar como visto"); actos.append("visto")
        else:
            opts.append("Marcar serie vista"); actos.append("serie_vista")
            if self.next_ep:
                opts.append("Marcar temporada %d vista" % self.next_ep[0])
                actos.append("temp_vista")
            opts.append("Marcar como no visto"); actos.append("desvisto")
        if self.row and self.row.get("trailer"):
            opts.append("Ver tráiler"); actos.append("trailer")
        opts.append("Enlaces"); actos.append("enlaces")
        sel = dialogs.select("Más", opts,
                             subtitulo=self.row.get("titulo") if self.row else "")
        if sel < 0:
            return
        acto = actos[sel]
        if acto == "enlaces":
            self._click_enlaces()
            return
        if acto == "visto" and self.userdata:
            self.userdata.save_movie(self.tmdb, 0, finished=True)
        elif acto == "desvisto" and self.userdata:
            if self.kind == "pelicula":
                self.userdata.unwatch_movie(self.tmdb)
            else:
                self.userdata.unwatch_serie(self.tmdb)
        elif acto == "serie_vista":
            self._marcar_serie()
        elif acto == "temp_vista":
            self._marcar_serie(temporada=self.next_ep[0])
        elif acto == "trailer":
            xbmc.executebuiltin("PlayMedia(plugin://plugin.video.youtube/play/?video_id=%s)"
                                % self.row["trailer"])
            return
        dialogs.notify("Hecho")
        self._refresh_play()

    def onClick(self, control_id):
        from nav import topbar_click
        if topbar_click(self, control_id):
            return
        if control_id == LBL_META:
            self._click_meta()
            return
        if control_id == BTN_PLAY and self.playback:
            if self.kind == "pelicula":
                self.playback.play_movie(self.tmdb)
            elif self.next_ep:
                t, e, _ = self.next_ep
                self.playback.play_episode(self.tmdb, t, e)
            return
        if control_id == BTN_LISTA and self.userdata:
            self.userdata.toggle_fav(self.kind, self.tmdb)
            self._refresh_lista()
            return
        if control_id == LIST_EPS and self.playback:
            # Barra de capítulos (§3): clic = reproducir ESE capítulo.
            item = self.getControl(LIST_EPS).getSelectedItem()
            if item and item.getProperty("t"):
                self.playback.play_episode(
                    self.tmdb, int(item.getProperty("t")),
                    int(item.getProperty("e")))
            return
        if control_id == LIST_CAST:
            # Barra de reparto (§3): clic en un actor = su filmografía
            # cruzada con el catálogo (solo lo que está en la base).
            item = self.getControl(LIST_CAST).getSelectedItem()
            if item and item.getProperty("person"):
                import tmdb as tmdb_api
                ids = tmdb_api.person_movie_ids(
                    int(item.getProperty("person")))
                if ids:
                    from section import SectionWindow
                    win = SectionWindow(
                        "section.xml", self.addon_path, "Default", "1080i",
                        catalog=self.catalog, userdata=self.userdata,
                        playback=self.playback, vault=self.vault,
                        addon_path=self.addon_path, profile=self.profile,
                        kind="pelicula",
                        spec={"tipo": "ids", "kind": "pelicula",
                              "ids": ids},
                        titulo=item.getLabel())
                    win.doModal()
                    del win
            return
        if control_id == BTN_TEMP and self.kind == "serie":
            from episodes import EpisodesWindow
            win = EpisodesWindow("episodes.xml", self.addon_path, "Default", "1080i",
                                 catalog=self.catalog, userdata=self.userdata,
                                 playback=self.playback, vault=self.vault, addon_path=self.addon_path,
                                 profile=self.profile,
                                 tmdb=self.tmdb)
            win.doModal()
            del win
            self.next_ep = self._compute_next_ep()
            self._refresh_play()
            return
        if control_id == BTN_MAS:
            self._click_mas()
