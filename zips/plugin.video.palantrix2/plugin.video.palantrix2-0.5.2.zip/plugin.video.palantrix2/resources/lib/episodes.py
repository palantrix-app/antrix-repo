# -*- coding: utf-8 -*-
"""Ventana Temporadas / Episodios (1303).

Fase 2: el foco inicial cae en el episodio de «seguir viendo» de la
temporada en curso (el que está a medias; si no, el primer no visto) y
el menú contextual de la casa permite marcar visto/no visto el episodio,
la temporada entera o la serie entera (todo en el userdata local).
"""
import xbmc
import xbmcgui

from db import img
import dialogs

CHIPS_ID = 300
EPS_ID = 310
LBL_TITULO = 920
TXT_PLOT = 940
IMG_FANART = 9000
BTN_BUSCAR = 810
BTN_AJUSTES = 811
BTN_CASA = 812
ACTION_CONTEXT = 117

class EpisodesWindow(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        super(EpisodesWindow, self).__init__(*args)
        self.catalog = kwargs.get("catalog")
        self.userdata = kwargs.get("userdata")
        self.playback = kwargs.get("playback")
        self.vault = kwargs.get("vault")
        self.addon_path = kwargs.get("addon_path")
        self.profile = kwargs.get("profile", "")
        self.tmdb = kwargs.get("tmdb")
        self.row = None
        self.season = None
        self._inited = False

    def onInit(self):
        if self._inited:
            from nav import unwind_home
            if unwind_home(self):
                return
            # Reactivación (vuelve una ventana hija modal): NO se
            # reconstruye nada (sup1-M2) — la temporada explorada con
            # los chips y la selección de episodios se conservan tal
            # cual; solo se devuelve el foco a la lista.
            try:
                self.setFocusId(EPS_ID)
            except Exception:
                pass
            return
        self._inited = True
        cat = self.catalog
        row = cat.detail("serie", self.tmdb)
        self.row = row
        if not row:
            self.close()
            return
        self.getControl(LBL_TITULO).setLabel(row.get("titulo") or "")
        self.getControl(IMG_FANART).setImage(img(row.get("fondo"), "w1280"), False)
        self.getControl(TXT_PLOT).setText(row.get("plot") or "")
        seasons = self.vault.seasons(self.tmdb) if self.vault else []
        last = cat.ultimo_visto_ep(self.tmdb)
        start = last["temporada"] if last else (seasons[0]["temporada"] if seasons else 1)
        self.season = start
        # La temporada en curso va PRIMERA en los chips: la lista no permite
        # fijar la selección por código, y así la píldora (ítem 0) coincide
        # siempre con los episodios mostrados. El resto, en orden.
        ordered = [s for s in seasons if s["temporada"] == start] + \
                  [s for s in seasons if s["temporada"] != start]
        chips = self.getControl(CHIPS_ID)
        chips.reset()
        items = []
        for s in ordered:
            li = xbmcgui.ListItem(label="Temporada %d" % s["temporada"])
            li.setProperty("temporada", str(s["temporada"]))
            items.append(li)
        chips.addItems(items)
        self._fill_episodes(start)
        self.setFocusId(EPS_ID)

    def _foco_episodio(self, temporada, episodios):
        """Índice del episodio de «seguir viendo» de esta temporada: el que
        está a medias; si no hay, el primer no visto; si todos, el 0."""
        vistos = self.catalog.vistos_de_serie(self.tmdb)
        primero_libre = None
        for i, ep in enumerate(episodios):
            v = vistos.get((temporada, ep["episodio"])) or {}
            prog = v.get("progress") or 0
            if 1 < prog < 97:
                return i
            if primero_libre is None and not (v.get("playcount") or 0) > 0 \
                    and prog < 97:
                primero_libre = i
        return primero_libre if primero_libre is not None else 0

    def _fill_episodes(self, temporada, foco=None):
        cat = self.catalog
        self.season = temporada
        vistos = cat.vistos_de_serie(self.tmdb)
        eps = self.vault.episodes(self.tmdb, temporada) if self.vault else []
        lst = self.getControl(EPS_ID)
        lst.reset()
        items = []
        for ep in eps:
            e = ep["episodio"]
            li = xbmcgui.ListItem(label="%dx%02d · Episodio %d" % (temporada, e, e))
            v = vistos.get((temporada, e)) or {}
            prog = v.get("progress") or 0
            if (v.get("playcount") or 0) > 0:
                li.setLabel2("Visto")
            elif 1 < prog < 97:
                li.setLabel2("A medias · %d%%" % int(prog))
            li.setArt({"fanart": img(self.row.get("fondo"), "w780"),
                       "poster": img(self.row.get("poster"), "w500")})
            li.setProperty("temporada", str(temporada))
            li.setProperty("episodio", str(e))
            items.append(li)
        lst.addItems(items)
        if items:
            idx = foco if foco is not None else self._foco_episodio(temporada, eps)
            lst.selectItem(max(0, min(idx, len(items) - 1)))

    # ---------------- menú contextual (Fase 2) ----------------
    def _marcar_temporada(self, temporada, visto=True):
        if not (self.userdata and self.vault):
            return
        for ep in self.vault.episodes(self.tmdb, temporada):
            if visto:
                self.userdata.save_episode(self.tmdb, temporada,
                                           ep["episodio"], 0, finished=True)
            else:
                self.userdata.unwatch_episode(self.tmdb, temporada,
                                              ep["episodio"])

    def _marcar_serie(self, visto=True):
        if not (self.userdata and self.vault):
            return
        for s in self.vault.seasons(self.tmdb):
            self._marcar_temporada(s["temporada"], visto)

    def _contexto(self):
        item = self.getControl(EPS_ID).getSelectedItem()
        if item is None or not self.userdata:
            return
        t = int(item.getProperty("temporada"))
        e = int(item.getProperty("episodio"))
        pos = self.getControl(EPS_ID).getSelectedPosition()
        v = (self.catalog.vistos_de_serie(self.tmdb).get((t, e)) or {})
        visto = (v.get("playcount") or 0) > 0
        opts = ["Marcar como no visto" if visto else "Marcar visto",
                "Marcar temporada vista", "Marcar serie vista"]
        sel = dialogs.select("%dx%02d · Episodio %d" % (t, e, e), opts)
        if sel == 0:
            if visto:
                self.userdata.unwatch_episode(self.tmdb, t, e)
            else:
                self.userdata.save_episode(self.tmdb, t, e, 0, finished=True)
        elif sel == 1:
            self._marcar_temporada(t)
        elif sel == 2:
            self._marcar_serie()
        else:
            return
        self._fill_episodes(self.season, foco=pos)
        self.setFocusId(EPS_ID)

    def onAction(self, action):
        aid = action.getId() if hasattr(action, "getId") else 0
        if aid == ACTION_CONTEXT and self.getFocusId() == EPS_ID:
            self._contexto()
            return
        if aid in (79, 229) and self.getFocusId() == EPS_ID:
            # Tecla Play (sup1-M7): reproduce el episodio enfocado.
            item = self.getControl(EPS_ID).getSelectedItem()
            if item and self.playback:
                pos = self.getControl(EPS_ID).getSelectedPosition()
                self.playback.play_episode(
                    self.tmdb, int(item.getProperty("temporada")),
                    int(item.getProperty("episodio")))
                self._fill_episodes(self.season, foco=pos)
                self.setFocusId(EPS_ID)
            return
        super(EpisodesWindow, self).onAction(action)

    def onClick(self, control_id):
        from nav import topbar_click
        if topbar_click(self, control_id):
            return
        if control_id == CHIPS_ID:
            item = self.getControl(CHIPS_ID).getSelectedItem()
            if item:
                self._fill_episodes(int(item.getProperty("temporada")))
                self.setFocusId(EPS_ID)
            return
        if control_id == EPS_ID:
            item = self.getControl(EPS_ID).getSelectedItem()
            if item and self.playback:
                # La posición lanzada se conserva al rellenar (sup1-M2):
                # sin foco=, la lista saltaba al episodio de reanudación.
                pos = self.getControl(EPS_ID).getSelectedPosition()
                self.playback.play_episode(self.tmdb,
                                           int(item.getProperty("temporada")),
                                           int(item.getProperty("episodio")))
                self._fill_episodes(self.season, foco=pos)
                self.setFocusId(EPS_ID)
