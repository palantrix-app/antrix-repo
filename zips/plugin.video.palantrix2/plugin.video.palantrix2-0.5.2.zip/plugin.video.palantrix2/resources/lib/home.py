# -*- coding: utf-8 -*-
"""Ventana Inicio (1300) — Principal según §1 (2026-11-22).

SOLO tres entradas: Películas, Series y «Más». A la derecha, las
miniaturas de avance de la entrada enfocada (las novedades), que
SON clicables y abren la ficha. «Seguir viendo» ya no vive aquí:
el seguimiento está dentro de Series y de Películas.

Regla del fondo (§1.8): fondo propio de PalAntriX mientras el foco
está en el menú o en la barra superior; al posarse en una miniatura
concreta del avance, el fondo pasa a ser SU fanart, y vuelve al
salir de ella. La memoria de foco entre bloques es exacta.
"""
import xbmc
import xbmcaddon
import xbmcgui

from db import img
import menus

ADDON = xbmcaddon.Addon()

MENU_ID = 300
PREV_ID = 150
BTN_BUSCAR = 810
BTN_AJUSTES = 811
BTN_CASA = 812
IMG_FANART = 9000
LBL_NOTA = 970
LBL_PREV = 971

PREV_TITULOS = {"peliculas": "Novedades", "series": "Actualizaciones",
                "mas": "Novedades"}


class HomeWindow(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        super(HomeWindow, self).__init__(*args)
        self.catalog = kwargs.get("catalog")
        self.userdata = kwargs.get("userdata")
        self.playback = kwargs.get("playback")
        self.vault = kwargs.get("vault")
        self.addon_path = kwargs.get("addon_path")
        self.profile = kwargs.get("profile", "")
        self.display = []
        self.previews = []       # filas del avance de la entrada enfocada
        self._block = "menu"     # 'menu' | 'preview'
        self._menu_pos = 0
        self._prev_pos = 0
        self._restore_target = None
        self._fanart_actual = ""
        self._samples = {}

    # ---------------- aviso de servicios ----------------
    def _aviso(self):
        """Un solo aviso, el más importante, si falta algo esencial."""
        if not (ADDON.getSetting("alldebrid_apikey") or "").strip():
            return ("Falta vincular AllDebrid", "sin reproducción")
        if self.vault is not None and not self.vault.has_master():
            return ("Crea tu contraseña maestra", "bóveda sin maestra")
        try:
            import trakt
            if not trakt.configured():
                return ("Falta configurar Trakt", "Favoritos vacíos")
            if not trakt.linked():
                return ("Falta vincular Trakt", "Favoritos vacíos")
        except Exception:
            pass
        return None

    # ---------------- menú (3 entradas) ----------------
    def _fill_menu(self):
        _titulo, nodes = menus.build_menu("root", self.catalog, self.userdata)
        aviso = self._aviso()
        if aviso:
            nodes = [{"id": "aviso", "titulo": aviso[0], "dest": "servicios",
                      "grupo": None, "nota": aviso[1]}] + nodes
        self.display = menus.visible_nodes(nodes, self.catalog)
        lst = self.getControl(MENU_ID)
        lst.reset()
        items = []
        for node in self.display:
            li = xbmcgui.ListItem(label=node.get("titulo") or "")
            if node.get("dest") == "header":
                li.setProperty("header", "1")
            else:
                li.setLabel2(node.get("nota") or "")
                li.setProperty("node_id", node.get("id") or "")
            items.append(li)
        lst.addItems(items)

    def _menu_index(self, node_id):
        for i, node in enumerate(self.display):
            if node.get("id") == node_id:
                return i
        return 0

    # ---------------- avance (miniaturas clicables) ----------------
    def _preview_item(self, row):
        li = xbmcgui.ListItem(label=row.get("titulo") or "")
        li.setLabel2(row.get("label2") or (row.get("fecha") or "")[:4])
        li.setArt({
            "poster": img(row.get("poster"), "w500"),
            "fanart": img(row.get("fondo"), "w1280"),
            "thumb": img(row.get("poster"), "w500"),
        })
        li.setProperty("tmdb", str(row.get("tmdb") or ""))
        li.setProperty("kind", row.get("kind") or "")
        li.setProperty("fondo", img(row.get("fondo"), "w1280"))
        if row.get("nuevo"):
            li.setProperty("nuevo", "1")
        return li

    def _preview_menu(self, pos):
        """Rellena el avance con las novedades de la entrada enfocada.
        El fondo NO cambia aquí: el foco está en el menú, no en una
        miniatura (§1.8)."""
        if not (0 <= pos < len(self.display)):
            return
        node = self.display[pos]
        if node.get("dest") == "header":
            return
        key = node.get("id")
        if key not in self._samples:
            rows = []
            spec = node.get("sample") or node.get("spec")
            if spec is not None:
                try:
                    rows = self.catalog.spec_sample(spec, 6)
                except Exception:
                    rows = []
            self._samples[key] = rows
        self.previews = self._samples[key]
        lst = self.getControl(PREV_ID)
        lst.reset()
        lst.addItems([self._preview_item(r) for r in self.previews])
        self._prev_pos = 0
        self.getControl(LBL_PREV).setLabel(
            PREV_TITULOS.get(key, "Novedades") if self.previews else "")
        self.getControl(LBL_NOTA).setLabel(node.get("nota") or "")
        self._set_fanart("")

    def _preview_focus(self, pos):
        """El foco entra en una miniatura concreta: su fanart manda."""
        if 0 <= pos < len(self.previews):
            self._prev_pos = pos
            self._set_fanart(img(self.previews[pos].get("fondo"), "w1280"))

    def _set_fanart(self, fondo):
        if (fondo or "") != self._fanart_actual:
            self._fanart_actual = fondo or ""
            self.getControl(IMG_FANART).setImage(self._fanart_actual, False)

    def _open_detail(self, row):
        from detail import DetailWindow
        win = DetailWindow("detail.xml", self.addon_path, "Default", "1080i",
                           catalog=self.catalog, userdata=self.userdata,
                           playback=self.playback, vault=self.vault,
                           addon_path=self.addon_path, profile=self.profile,
                           kind=row.get("kind") or "pelicula",
                           tmdb=int(row["tmdb"]))
        win.doModal()
        del win

    def _next_ep(self, tmdb):
        """Siguiente episodio a reproducir (la misma regla que la ficha)."""
        if self.vault is None:
            return None
        last = self.catalog.ultimo_visto_ep(tmdb)
        seasons = self.vault.seasons(tmdb)
        if not seasons:
            return None
        if last:
            t, e, prog = last["temporada"], last["episodio"], \
                last.get("progress") or 0
            if 1 < prog < 97:
                return (t, e)
            eps = [x["episodio"] for x in self.vault.episodes(tmdb, t)]
            nxt = [x for x in eps if x > e]
            if nxt:
                return (t, nxt[0])
            later = [s["temporada"] for s in seasons if s["temporada"] > t]
            if later:
                eps2 = self.vault.episodes(tmdb, later[0])
                if eps2:
                    return (later[0], eps2[0]["episodio"])
            return (t, e)
        t0 = seasons[0]["temporada"]
        eps0 = self.vault.episodes(tmdb, t0)
        return (t0, eps0[0]["episodio"]) if eps0 else None

    def _play_preview(self, pos):
        if not (0 <= pos < len(self.previews)) or not self.playback:
            return
        row = self.previews[pos]
        kind = row.get("kind") or "pelicula"
        if kind == "pelicula":
            self.playback.play_movie(int(row["tmdb"]))
        else:
            nxt = self._next_ep(int(row["tmdb"]))
            if nxt:
                self.playback.play_episode(int(row["tmdb"]), nxt[0], nxt[1])

    # ---------------- ventana ----------------
    def onInit(self):
        if getattr(self, "_inited", False):
            # La principal es el destino de la orden de la casa (§1.10):
            # al reactivarse la consume y se queda.
            from nav import clear_home
            clear_home()
            self._restore_focus()
            return
        self._inited = True
        self._fill_menu()
        xbmc.sleep(200)
        self._block = "menu"
        self._menu_pos = self._menu_index("peliculas")
        self.getControl(MENU_ID).selectItem(self._menu_pos)
        self.setFocusId(MENU_ID)
        self._preview_menu(self._menu_pos)

    def onFocus(self, control_id):
        if control_id == PREV_ID:
            self._block = "preview"
        elif control_id == MENU_ID:
            self._block = "menu"
            self._set_fanart("")
        elif control_id in (BTN_BUSCAR, BTN_AJUSTES, BTN_CASA):
            self._set_fanart("")

    def onAction(self, action):
        aid = action.getId() if hasattr(action, "getId") else 0
        if aid in (79, 229) and self.getFocusId() == PREV_ID and self.playback:
            # Tecla Play sobre una miniatura del avance: directo.
            self._restore_target = ("preview", self._prev_pos)
            self._play_preview(self._prev_pos)
            self._restore_focus()
            return
        super(HomeWindow, self).onAction(action)
        fid = self.getFocusId()
        if fid == PREV_ID:
            self._block = "preview"
            pos = self.getControl(PREV_ID).getSelectedPosition()
            if 0 <= pos and pos != self._prev_pos:
                self._preview_focus(pos)
        elif fid == MENU_ID:
            self._block = "menu"
            lst = self.getControl(MENU_ID)
            pos = lst.getSelectedPosition()
            if 0 <= pos < len(self.display):
                buena = menus.corregir_posicion(self.display, pos,
                                                self._menu_pos, aid)
                if buena != pos:
                    lst.selectItem(buena)
                    pos = buena
            if pos != self._menu_pos and 0 <= pos:
                self._menu_pos = pos
                self._preview_menu(pos)

    def _restore_focus(self):
        tgt = getattr(self, "_restore_target", None)
        if tgt is None:
            tgt = (self._block, self._prev_pos if self._block == "preview"
                   else self._menu_pos)
        try:
            if tgt[0] == "preview" and self.previews:
                lst = self.getControl(PREV_ID)
                lst.selectItem(min(tgt[1], len(self.previews) - 1))
                self.setFocusId(PREV_ID)
                self._preview_focus(tgt[1])
            else:
                lst = self.getControl(MENU_ID)
                lst.selectItem(self._menu_pos)
                self.setFocusId(MENU_ID)
                self._set_fanart("")
        except Exception:
            pass

    def onClick(self, control_id):
        if control_id == BTN_CASA:
            # Ya estamos en la principal: la casa solo devuelve el
            # foco al menú.
            self._block = "menu"
            try:
                self.getControl(MENU_ID).selectItem(self._menu_pos)
            except Exception:
                pass
            self.setFocusId(MENU_ID)
            self._preview_menu(self._menu_pos)
            return
        from nav import topbar_click
        if topbar_click(self, control_id):
            self._restore_target = (self._block,
                                    self._prev_pos if self._block == "preview"
                                    else self._menu_pos)
            self._restore_focus()
            return
        if control_id == PREV_ID:
            pos = self.getControl(PREV_ID).getSelectedPosition()
            if 0 <= pos < len(self.previews):
                self._block = "preview"
                self._prev_pos = pos
                self._restore_target = ("preview", pos)
                self._open_detail(self.previews[pos])
                self._restore_focus()
            return
        if control_id == MENU_ID:
            lst = self.getControl(MENU_ID)
            pos = lst.getSelectedPosition()
            if not (0 <= pos < len(self.display)):
                return
            node = self.display[pos]
            if node.get("dest") == "header":
                return
            self._block = "menu"
            self._menu_pos = pos
            self._restore_target = ("menu", pos)
            menus.open_node(self, node)
            self._restore_focus()
